﻿$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:version = '3.2.0'
$script:projectId = 'backrooms-low-frequency-local'
$script:source = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:chosen = $null
$script:busy = $false
$script:cancelRequested = $false
$script:downloader = $null
$script:pythonArchive = 'python-3.12.10-embed-amd64.zip'
$script:pygameWheel = 'pygame-2.6.1-cp312-cp312-win_amd64.whl'
$script:pythonSha = '4acbed6dd1c744b0376e3b1cf57ce906f9dc9e95e68824584c8099a63025a3c3'
$script:pygameSha = '3a9e7396be0d9633831c3f8d5d82dd63ba373ad65599628294b7a4f8a5a01a65'

Add-Type -ReferencedAssemblies @('System.dll','System.Core.dll') -TypeDefinition @'
using System;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

public sealed class BackroomsDownloader {
    private volatile bool cancelled;
    private long bytes;
    private long total;
    private volatile string state = "准备连接";
    public long Bytes { get { return Interlocked.Read(ref bytes); } }
    public long Total { get { return Interlocked.Read(ref total); } }
    public string State { get { return state; } }
    public void Cancel() { cancelled = true; }
    private void Check() { if (cancelled) throw new OperationCanceledException("已取消下载"); }

    private static bool Valid(string file, long minimum, string hash) {
        if (!File.Exists(file) || new FileInfo(file).Length < minimum) return false;
        using (FileStream stream = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.Read))
        using (SHA256 sha = SHA256.Create()) {
            byte[] digest = sha.ComputeHash(stream);
            return BitConverter.ToString(digest).Replace("-", "").Equals(hash, StringComparison.OrdinalIgnoreCase);
        }
    }

    private string[] Rank(string[] urls) {
        List<Tuple<string,long>> ranked = new List<Tuple<string,long>>();
        foreach (string url in urls) {
            Check();
            long millis = 20000;
            Stopwatch timer = Stopwatch.StartNew();
            HttpWebResponse response = null;
            try {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "HEAD";
                request.Timeout = 2600;
                request.ReadWriteTimeout = 2600;
                request.AllowAutoRedirect = true;
                request.UserAgent = "BackroomsLocalSetup/1.4";
                request.Proxy = WebRequest.GetSystemWebProxy();
                if (request.Proxy != null) request.Proxy.Credentials = CredentialCache.DefaultCredentials;
                response = (HttpWebResponse)request.GetResponse();
                millis = timer.ElapsedMilliseconds;
            } catch (WebException) { }
            finally { if (response != null) response.Close(); }
            ranked.Add(Tuple.Create(url,millis));
        }
        ranked.Sort((a,b) => a.Item2.CompareTo(b.Item2));
        List<string> result = new List<string>();
        foreach (Tuple<string,long> item in ranked) result.Add(item.Item1);
        return result.ToArray();
    }

    public Task<bool> Start(string[] mirrors, string destination, long minimum, string hash) {
        cancelled = false;
        Interlocked.Exchange(ref bytes,0L);
        Interlocked.Exchange(ref total,0L);
        return Task.Factory.StartNew<bool>(() => Download(mirrors,destination,minimum,hash),
            CancellationToken.None,TaskCreationOptions.LongRunning,TaskScheduler.Default);
    }

    private bool Download(string[] mirrors, string destination, long minimum, string hash) {
        if (Valid(destination,minimum,hash)) { state = "已验证本地缓存"; return true; }
        if (File.Exists(destination)) File.Delete(destination);
        string part = destination + ".part";
        if (Valid(part,minimum,hash)) {
            File.Move(part,destination);
            state = "已恢复完整缓存";
            return true;
        }
        state = "探测可用镜像";
        string[] ranked = Rank(mirrors);
        Exception lastError = null;
        foreach (string url in ranked) {
            for (int attempt=0;attempt<2;attempt++) {
                Check();
                HttpWebResponse response = null;
                try {
                    long offset = File.Exists(part) ? new FileInfo(part).Length : 0;
                    if (offset > 125000000L) { File.Delete(part); offset = 0; }
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                    request.Timeout = 14000;
                    request.ReadWriteTimeout = 22000;
                    request.AllowAutoRedirect = true;
                    request.UserAgent = "BackroomsLocalSetup/1.4";
                    request.Proxy = WebRequest.GetSystemWebProxy();
                    if (request.Proxy != null) request.Proxy.Credentials = CredentialCache.DefaultCredentials;
                    if (offset > 0) request.AddRange(offset);
                    state = "连接下载镜像";
                    response = (HttpWebResponse)request.GetResponse();
                    bool partial = response.StatusCode == HttpStatusCode.PartialContent;
                    string range = response.Headers["Content-Range"];
                    if (offset > 0 && partial && (range == null || !range.StartsWith("bytes " + offset + "-")))
                        throw new IOException("续传范围与本地文件不一致");
                    if (!partial) offset=0;
                    Interlocked.Exchange(ref bytes,offset);
                    Interlocked.Exchange(ref total,response.ContentLength > 0 ? offset + response.ContentLength : 0);
                    state = "正在下载";
                    using (Stream input = response.GetResponseStream())
                    using (FileStream output = File.Open(part,partial ? FileMode.Append : FileMode.Create,
                                                            FileAccess.Write,FileShare.None)) {
                        byte[] buffer = new byte[65536];
                        int count;
                        while ((count = input.Read(buffer,0,buffer.Length)) > 0) {
                            Check();
                            output.Write(buffer,0,count);
                            Interlocked.Add(ref bytes,count);
                        }
                    }
                    response.Close();
                    response=null;
                    Check();
                    state = "核对 SHA-256";
                    if (!Valid(part,minimum,hash)) {
                        File.Delete(part);
                        throw new IOException("文件 SHA-256 校验失败");
                    }
                    File.Move(part,destination);
                    state = "校验通过";
                    return true;
                } catch (OperationCanceledException) { throw; }
                  catch (Exception e) {
                    lastError = e;
                    state = "镜像不可用，尝试其他节点";
                    if (e is WebException) {
                        HttpWebResponse responseError = ((WebException)e).Response as HttpWebResponse;
                        if (responseError != null && responseError.StatusCode == HttpStatusCode.RequestedRangeNotSatisfiable
                            && File.Exists(part)) File.Delete(part);
                    }
                } finally { if (response != null) response.Close(); }
            }
        }
        throw new IOException("所有下载节点均不可用。请检查网络/代理，随后重试（已下载的部分会保留）。" +
                              (lastError != null ? " 原因：" + lastError.Message : ""));
    }
}
'@

function Color([int]$r, [int]$g, [int]$b) { return [System.Drawing.Color]::FromArgb($r, $g, $b) }
function Make-Label($value, $size, $color, $bold = $false) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $value
    $label.AutoEllipsis = $true
    $label.ForeColor = $color
    $label.BackColor = [System.Drawing.Color]::Transparent
    $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    $label.Font = [System.Drawing.Font]::new('Microsoft YaHei UI', [float]$size, $style)
    return $label
}
function Make-Button($value, $background, $foreground) {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $value
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.FlatAppearance.BorderSize = 0
    $button.BackColor = $background
    $button.ForeColor = $foreground
    $button.Font = [System.Drawing.Font]::new('Microsoft YaHei UI', 11, [System.Drawing.FontStyle]::Bold)
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    return $button
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'THE BACKROOMS | 初始化'
$form.ClientSize = [System.Drawing.Size]::new(790, 485)
$form.MinimumSize = [System.Drawing.Size]::new(680, 465)
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Sizable
$form.MaximizeBox = $true
$form.BackColor = Color 13 23 23
$form.ForeColor = Color 226 214 178
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

$top = Make-Label 'B / R' 22 (Color 224 203 142) $true
$topRight = Make-Label 'LOW FREQUENCY   /   LOCAL SETUP' 10 (Color 134 161 147)
$line = New-Object System.Windows.Forms.Panel
$line.BackColor = Color 107 116 92
$title = Make-Label '选择游戏所在的文件夹' 23 (Color 239 233 216) $true
$subtitle = Make-Label '游戏、运行环境与存档将统一存入这个位置下的 The Backrooms 目录。' 11 (Color 151 164 152)
$pathInfo = Make-Label '尚未选择文件夹' 12 (Color 229 217 176)
$choose = Make-Button '选择文件夹' (Color 46 74 68) (Color 221 239 224)
$start = Make-Button '安装并进入' (Color 180 157 103) (Color 15 24 23)
$start.Enabled = $false
$leave = Make-Button '退出' (Color 36 46 44) (Color 185 192 183)
$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
$bar.Minimum = 0
$bar.Maximum = 100
$bar.Value = 0
$status = Make-Label '等待选择安装位置' 10 (Color 142 174 151)
$tooltip = New-Object System.Windows.Forms.ToolTip
$form.Controls.AddRange([System.Windows.Forms.Control[]]@($top, $topRight, $line, $title, $subtitle, $pathInfo, $choose, $start, $leave, $bar, $status))

function Layout-Window {
    $w, $h = $form.ClientSize.Width, $form.ClientSize.Height
    $p = [Math]::Max(25, [Math]::Min(49, [int]($w * .055)))
    $top.SetBounds($p, 22, 110, 38)
    $topRight.SetBounds([Math]::Max($p + 135, $w - $p - 325), 32, 325, 23)
    $line.SetBounds($p, 77, $w - 2 * $p, 1)
    $title.SetBounds($p, 106, $w - 2 * $p, 50)
    $subtitle.SetBounds($p, 162, $w - 2 * $p, 30)
    $pathY = [int]($h * .49)
    $choose.SetBounds($w - $p - 157, $pathY, 157, 45)
    $pathInfo.SetBounds($p + 10, $pathY + 4, $w - 2 * $p - 185, 37)
    $start.SetBounds($p, $h - 167, 232, 53)
    $leave.SetBounds($p + 248, $h - 167, 119, 53)
    $bar.SetBounds($p, $h - 74, $w - 2 * $p, 8)
    $status.SetBounds($p, $h - 57, $w - 2 * $p, 35)
}
$form.Add_Resize({ Layout-Window })
Layout-Window

function Update-Status([string]$message, [int]$percent) {
    $bar.Value = [Math]::Max(0, [Math]::Min(100, $percent))
    $status.Text = $message
    [System.Windows.Forms.Application]::DoEvents()
}
function Check-Cancel {
    if ($script:cancelRequested) {
        if ($script:downloader) { $script:downloader.Cancel() }
        throw '用户已取消部署。'
    }
}
function Note([string]$root, [string]$message) {
    try {
        $data = Join-Path $root 'data'
        [System.IO.Directory]::CreateDirectory($data) | Out-Null
        $clean = ($message -replace '[\r\n]+', ' ')
        [System.IO.File]::AppendAllText((Join-Path $data 'install.log'), "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $clean`r`n", [System.Text.Encoding]::UTF8)
    } catch {}
}
function Destination-For([string]$selection) {
    $folder = [System.IO.Path]::GetFullPath($selection)
    if ((Split-Path -Leaf $folder) -ieq 'The Backrooms') {
        if ((Test-Path -LiteralPath (Join-Path $folder '.backrooms-owned')) -or
            (Test-Path -LiteralPath (Join-Path $folder 'install.json'))) {
            return $folder
        }
    }
    return (Join-Path $folder 'The Backrooms')
}
function Verify-File([string]$path, [int64]$minimum, [string]$hash) {
    if (-not [System.IO.File]::Exists($path)) { return $false }
    if ((Get-Item -LiteralPath $path).Length -lt $minimum) { return $false }
    return ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ieq $hash)
}
function Download-File([string]$name, [string]$destination, [string[]]$mirrors, [int64]$minimum, [string]$hash, [int]$startPercent, [int]$endPercent) {
    $local = Join-Path $script:source ([System.IO.Path]::GetFileName($destination))
    if ((-not (Verify-File $destination $minimum $hash)) -and (Verify-File $local $minimum $hash)) {
        Copy-Item -LiteralPath $local -Destination $destination -Force
    }
    if (Verify-File $destination $minimum $hash) {
        Update-Status "$name / 已复用经校验的本地缓存" $endPercent
        return
    }
    $script:downloader = New-Object BackroomsDownloader
    $task = $script:downloader.Start($mirrors, $destination, $minimum, $hash)
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $lastBytes = [int64]0
    $lastStamp = [double]0
    $speed = [double]0
    try {
        while (-not $task.IsCompleted) {
            if ($script:cancelRequested) { $script:downloader.Cancel() }
            $received = [int64]$script:downloader.Bytes
            $total = [int64]$script:downloader.Total
            $seconds = $watch.Elapsed.TotalSeconds
            if ($seconds - $lastStamp -ge .32) {
                $speed = [Math]::Max(0, ($received - $lastBytes) / [Math]::Max(.001, $seconds - $lastStamp))
                $lastBytes = $received
                $lastStamp = $seconds
            }
            $fraction = if ($total -gt 0) { [Math]::Min(1., $received / $total) } else { 0. }
            $fraction = [Math]::Min(.95, $fraction)
            $percent = $startPercent + [int](($endPercent - $startPercent) * $fraction)
            $sizeText = if ($total -gt 0) { "$([Math]::Round($received / 1MB, 1)) / $([Math]::Round($total / 1MB, 1)) MB" } else { "$([Math]::Round($received / 1MB, 1)) MB" }
            Update-Status "$name / $($script:downloader.State) · $sizeText · $([Math]::Round($speed / 1MB, 2)) MB/s" $percent
            Start-Sleep -Milliseconds 64
        }
        try {
            $task.GetAwaiter().GetResult() | Out-Null
        } catch {
            Check-Cancel
            $choice = [System.Windows.Forms.MessageBox]::Show(
                "$name 的自动下载暂时不可用。若已从可信渠道取得原始依赖文件，可选择本地文件并进行 SHA-256 校验。现在导入吗？",
                '下载失败 / 本地恢复', [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question)
            if ($choice -ne [System.Windows.Forms.DialogResult]::Yes) { throw }
            $filePicker = New-Object System.Windows.Forms.OpenFileDialog
            $filePicker.Title = "选择 $name 原始安装包"
            $filePicker.Filter = '原始 Python / Pygame 文件 (*.zip;*.whl)|*.zip;*.whl|所有文件 (*.*)|*.*'
            try {
                if ($filePicker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { throw '已取消本地导入。' }
                if (-not (Verify-File $filePicker.FileName $minimum $hash)) { throw '本地文件 SHA-256 与官方安装包不匹配。' }
                Copy-Item -LiteralPath $filePicker.FileName -Destination $destination -Force
            } finally { $filePicker.Dispose() }
        }
        Check-Cancel
        Update-Status "$name / SHA-256 校验通过" $endPercent
    } finally {
        $watch.Stop()
        $script:downloader = $null
    }
}
function Verify-Installation([string]$folder) {
    $manifestPath = Join-Path $folder 'install.json'
    if (-not (Test-Path -LiteralPath $manifestPath)) { return $false }
    try {
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($manifest.project_id -ne $script:projectId -or $manifest.version -ne $script:version) { return $false }
        $indexed = @{}
        foreach ($item in $manifest.files) {
            if ($item.path -notmatch '^(app|runtime)/[^\x00-\x1f:]+$' -or $item.path -match '(^|/)\.\.(/|$)') { return $false }
            if ($indexed.ContainsKey([string]$item.path)) { return $false }
            $indexed[[string]$item.path] = [string]$item.sha256
            $target = Join-Path $folder ($item.path -replace '/', '\')
            if (-not (Verify-File $target 1 $item.sha256)) { return $false }
        }
        $sourceApp = Join-Path $script:source 'app'
        foreach ($file in @(Get-ChildItem -LiteralPath $sourceApp -File -Recurse | Where-Object { $_.FullName -notmatch '\\__pycache__\\' -and $_.Extension -ne '.pyc' })) {
            $relative = 'app/' + ($file.FullName.Substring($sourceApp.Length).TrimStart([char]'\') -replace '\\', '/')
            if (-not $indexed.ContainsKey($relative)) { return $false }
            if ($indexed[$relative] -ne (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()) { return $false }
        }
        return ($indexed.Count -ge 30 -and (Verify-Runtime $folder))
    } catch { return $false }
}
function Verify-Runtime([string]$folder) {
    $manifestPath = Join-Path $folder 'install.json'
    if (-not (Test-Path -LiteralPath $manifestPath)) { return $false }
    try {
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($manifest.project_id -ne $script:projectId) { return $false }
        $files = @($manifest.files | Where-Object { $_.path -like 'runtime/*' })
        if ($files.Count -lt 20) { return $false }
        $required = @('runtime/python/python.exe', 'runtime/python/pythonw.exe',
                      'runtime/python/python312.dll', 'runtime/python/python312._pth')
        foreach ($name in $required) {
            if (@($files | Where-Object { $_.path -eq $name }).Count -eq 0) { return $false }
        }
        foreach ($file in $files) {
            if ($file.path -notmatch '^runtime/python/[^\x00-\x1f:]+$' -or $file.path -match '(^|/)\.\.(/|$)') { return $false }
            $target = Join-Path $folder ($file.path -replace '/', '\')
            if (-not (Verify-File $target 1 $file.sha256)) { return $false }
        }
        return $true
    } catch { return $false }
}
function Test-SourcePackage([string]$folder) {
    $requiredCode = @('main.py', 'game.py', 'controls.py', 'renderer.py', 'interface.py',
                      'sound.py', 'world.py', 'storage.py', 'config.py', 'horror.py', 'gpu.py',
                      'effects.py', 'verify.py', 'procedural.py', 'weapon3d.py', 'audio_synth.py')
    foreach ($name in $requiredCode) {
        if (-not (Test-Path -LiteralPath (Join-Path $folder $name) -PathType Leaf)) { throw "安装包缺少代码：$name" }
    }
    $unwanted = @(Get-ChildItem -LiteralPath $folder -File -Recurse | Where-Object { $_.Extension -ne '.py' })
    if ($unwanted.Count -gt 0) { throw "源代码目录包含非代码文件：$($unwanted[0].Name)" }
}
function Smoke-Test([string]$python, [string]$app, [string]$root, [bool]$safe = $true) {
    $previousErrorPreference = $ErrorActionPreference
    $arguments = @((Join-Path $app 'verify.py'), '--root', $root)
    try {
        $ErrorActionPreference = 'Continue'
        $output = & $python @arguments 2>&1
    } finally { $ErrorActionPreference = $previousErrorPreference }
    if ($LASTEXITCODE -ne 0 -or (($output | Out-String) -notmatch 'VERIFY_OK')) {
        throw ('无窗口资源验证失败：' + ($output | Out-String).Trim())
    }
    return ($output | Out-String).Trim()
}
function Startup-Probe([string]$python, [string]$app, [string]$root, [bool]$safe = $false) {
    $options = New-Object System.Diagnostics.ProcessStartInfo
    $options.FileName = $python
    $flag = if ($safe) { ' --safe-mode' } else { '' }
    $options.Arguments = ('"{0}" --root "{1}" --startup-probe{2}' -f (Join-Path $app 'main.py'), $root, $flag)
    $options.WorkingDirectory = $root
    $options.RedirectStandardOutput = $true
    $options.RedirectStandardError = $true
    $options.UseShellExecute = $false
    $options.CreateNoWindow = $true
    $options.EnvironmentVariables['PYTHONDONTWRITEBYTECODE'] = '1'
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $options
    try {
        if (-not $process.Start()) { throw '无法启动图形兼容性测试。' }
        $watch = [System.Diagnostics.Stopwatch]::StartNew()
        while (-not $process.HasExited) {
            Check-Cancel
            if ($watch.Elapsed.TotalSeconds -gt 120) { throw '图形兼容性测试超时。' }
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 125
        }
        $result = $process.StandardOutput.ReadToEnd()
        $errors = $process.StandardError.ReadToEnd()
        if ($process.ExitCode -ne 0 -or $result -notmatch 'STARTUP_PROBE_(GPU|CPU)_OK') {
            throw ('实际启动测试失败：' + ($result + ' ' + $errors).Trim().Substring(0, [Math]::Min(420, ($result + ' ' + $errors).Trim().Length)))
        }
        return $result.Trim()
    } finally {
        if ($process -and -not $process.HasExited) {
            try { $process.Kill(); $process.WaitForExit(2000) | Out-Null } catch {}
        }
        if ($process) { $process.Dispose() }
    }
}

function ExistingRuntime-Test([string]$python, [string]$app, [string]$root) {
    try {
        return ((Smoke-Test $python $app $root $true) -match 'VERIFY_OK')
    } catch { return $false }
}
function Save-Manifest([string]$folder) {
    $entries = @()
    foreach ($relative in @('app', 'runtime\python')) {
        $base = Join-Path $folder $relative
        Get-ChildItem -LiteralPath $base -File -Recurse | Where-Object { $_.FullName -notmatch '\\__pycache__\\' -and $_.Extension -ne '.pyc' } | ForEach-Object {
            $name = $_.FullName.Substring($folder.Length).TrimStart([char]'\') -replace '\\', '/'
            $entries += [PSCustomObject]@{ path = $name; sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
        }
    }
    $manifest = [PSCustomObject]@{ project_id = $script:projectId; version = $script:version; installed = (Get-Date).ToString('o'); files = @($entries) }
    $temp = Join-Path $folder 'install.json.pending'
    [System.IO.File]::WriteAllText($temp, ($manifest | ConvertTo-Json -Depth 5 -Compress), ([System.Text.UTF8Encoding]::new($false)))
    Move-Item -LiteralPath $temp -Destination (Join-Path $folder 'install.json') -Force
}

$choose.Add_Click({
    if ($script:busy) { return }
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = '选择安装位置。游戏内容会放在其中的 The Backrooms 文件夹内。'
    $dialog.ShowNewFolderButton = $true
    if ($script:chosen) { $dialog.SelectedPath = $script:chosen }
    try {
        if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
            $script:chosen = $dialog.SelectedPath
            $destination = Destination-For $script:chosen
            $pathInfo.Text = $destination
            $tooltip.SetToolTip($pathInfo, $destination)
            $start.Enabled = $true
            $start.Text = if (Verify-Installation $destination) { '验证并进入' } else { '安装并进入' }
            Update-Status '已选择安装位置' 7
        }
    } finally { $dialog.Dispose() }
})
$leave.Add_Click({
    if ($script:busy) {
        $script:cancelRequested = $true
        if ($script:downloader) { $script:downloader.Cancel() }
        $leave.Enabled = $false
        $status.Text = '正在取消当前操作…'
    } else { $form.Close() }
})
$form.Add_FormClosing({
    if ($script:busy) {
        $_.Cancel = $true
        $script:cancelRequested = $true
        if ($script:downloader) { $script:downloader.Cancel() }
    }
})

$start.Add_Click({
    if ($script:busy -or -not $script:chosen) { return }
    $script:busy = $true
    $script:cancelRequested = $false
    $start.Enabled = $false
    $choose.Enabled = $false
    $leave.Enabled = $true
    $leave.Text = '取消'
    $dest = $null
    $stage = $null
    $oldApp = $false
    $oldRuntime = $false
    $newApp = $false
    $newRuntime = $false
    $manifestWritten = $false
    $launcherWritten = $false
    $safeLauncherWritten = $false
    try {
        if (-not [Environment]::Is64BitOperatingSystem) { throw '仅支持 Windows x64。' }
        $parent = [System.IO.Path]::GetFullPath($script:chosen)
        $dest = Destination-For $parent
        $dest = [System.IO.Path]::GetFullPath($dest)
        $windowsPath = [System.IO.Path]::GetFullPath($env:windir).TrimEnd('\')
        if ($dest.StartsWith($windowsPath + '\', [StringComparison]::OrdinalIgnoreCase) -or
            $dest.StartsWith(([System.IO.Path]::GetPathRoot($dest) + 'Program Files'), [StringComparison]::OrdinalIgnoreCase)) {
            throw '请不要安装到 Windows 或 Program Files 等系统目录。'
        }
        $root = [System.IO.Path]::GetPathRoot($dest)
        $drive = [System.IO.DriveInfo]::new($root)
        if (-not $drive.IsReady -or $drive.AvailableFreeSpace -lt 350MB) { throw '所选磁盘剩余空间不足 350 MB，或磁盘不可访问。' }
        if (Test-Path -LiteralPath $dest) {
            $existingManifest = Join-Path $dest 'install.json'
            if (-not (Test-Path -LiteralPath $existingManifest)) {
                $existing = @(Get-ChildItem -LiteralPath $dest -Force)
                $ownerFile = Join-Path $dest '.backrooms-owned'
                if ($existing.Count -gt 0 -and ((-not (Test-Path -LiteralPath $ownerFile)) -or ((Get-Content -LiteralPath $ownerFile -Raw) -ne $script:projectId))) {
                    throw '目标游戏目录已有其他文件且没有安装记录。为避免覆盖，请改用空文件夹。'
                }
            } else {
                $info = Get-Content -LiteralPath $existingManifest -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($info.project_id -ne $script:projectId) { throw '目录属于另一个项目，已阻止覆盖。' }
            }
        }
        [System.IO.Directory]::CreateDirectory($dest) | Out-Null
        [System.IO.File]::WriteAllText((Join-Path $dest '.backrooms-owned'), $script:projectId, [System.Text.Encoding]::ASCII)
        $stage = Join-Path $dest '.staging'
        $cache = Join-Path $dest 'cache'
        $sourceApp = Join-Path $script:source 'app'
        $activeApp = Join-Path $dest 'app'
        $sourceFull = [System.IO.Path]::GetFullPath($sourceApp).TrimEnd('\')
        if ($dest.StartsWith($sourceFull + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw '请不要选择启动包内部的 app 源码目录作为安装位置。'
        }
        $activePython = Join-Path $dest 'runtime\python'
        $ready = Verify-Runtime $dest
        [System.IO.Directory]::CreateDirectory($cache) | Out-Null
        [System.IO.Directory]::CreateDirectory((Join-Path $dest 'runtime')) | Out-Null
        Note $dest 'INSTALL_BEGIN'
        Check-Cancel
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
        [System.IO.Directory]::CreateDirectory($stage) | Out-Null
        Update-Status '正在准备游戏内容与离线资源' 13
        Test-SourcePackage $sourceApp
        Copy-Item -LiteralPath $sourceApp -Destination (Join-Path $stage 'app') -Recurse -Force
        $stagedApp = Join-Path $stage 'app'
        Get-ChildItem -LiteralPath $stagedApp -Directory -Recurse -Filter '__pycache__' -ErrorAction SilentlyContinue |
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        if ($ready -and -not (ExistingRuntime-Test (Join-Path $activePython 'python.exe') $stagedApp $stage)) {
            Note $dest 'RUNTIME_INTEGRITY_TEST_FAILED_AUTO_REPAIR'
            $ready = $false
            Update-Status '已发现运行环境异常：尝试离线缓存修复' 17
        }
        if ($ready) {
            Update-Status '本地运行环境完整，无需再次下载' 72
        } else {
            $pythonMirrors = @(
                "https://mirror.nju.edu.cn/python/3.12.10/$script:pythonArchive",
                "https://repo.huaweicloud.com/python/3.12.10/$script:pythonArchive",
                "https://www.python.org/ftp/python/3.12.10/$script:pythonArchive"
            )
            $packagePath = "5f/90/7d766d54bb95939725e9a9361f9c06b0cfbe3fe100aa35400f0a461a278a/$script:pygameWheel"
            $pygameMirrors = @(
                "https://mirrors.aliyun.com/pypi/packages/$packagePath",
                "https://mirrors.huaweicloud.com/repository/pypi/packages/$packagePath",
                "https://files.pythonhosted.org/packages/$packagePath"
            )
            Download-File 'Python 运行环境' (Join-Path $cache $script:pythonArchive) $pythonMirrors 10000000 $script:pythonSha 20 45
            Download-File 'Pygame 图形引擎' (Join-Path $cache $script:pygameWheel) $pygameMirrors 9500000 $script:pygameSha 46 70
            Check-Cancel
            $stagePython = Join-Path $stage 'runtime\python'
            $packages = Join-Path $stagePython 'Lib\site-packages'
            [System.IO.Directory]::CreateDirectory($stagePython) | Out-Null
            Update-Status '正在准备完全独立的离线运行环境' 75
            [System.IO.Compression.ZipFile]::ExtractToDirectory((Join-Path $cache $script:pythonArchive), $stagePython)
            $pth = Join-Path $stagePython 'python312._pth'
            if (-not (Test-Path -LiteralPath $pth)) { throw 'Python 压缩包缺少关键路径配置。' }
            [System.IO.File]::WriteAllText($pth, "python312.zip`r`n.`r`nLib\site-packages`r`n..\..\app`r`nimport site`r`n", [System.Text.Encoding]::ASCII)
            [System.IO.Directory]::CreateDirectory($packages) | Out-Null
            [System.IO.Compression.ZipFile]::ExtractToDirectory((Join-Path $cache $script:pygameWheel), $packages)
            Update-Status '依赖已解压，即将进行兼容性验证' 84
        }
        Check-Cancel
        if (-not $ready) {
            Smoke-Test (Join-Path $stage 'runtime\python\python.exe') $stagedApp $stage $true | Out-Null
        }
        Update-Status '初始化通过，正在安全更新游戏内容' 90
        Check-Cancel
        $manifestPath = Join-Path $dest 'install.json'
        $launch = Join-Path $dest '进入后室.cmd'
        if (Test-Path -LiteralPath $manifestPath) {
            Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $stage 'previous_install.json')
        }
        if (Test-Path -LiteralPath $launch) {
            Copy-Item -LiteralPath $launch -Destination (Join-Path $stage 'previous_launcher.cmd')
        }
        $safeLauncher = Join-Path $dest '兼容模式.cmd'
        if (Test-Path -LiteralPath $safeLauncher) {
            Copy-Item -LiteralPath $safeLauncher -Destination (Join-Path $stage 'previous_safe_launcher.cmd')
        }
        if (Test-Path -LiteralPath $activeApp) {
            Move-Item -LiteralPath $activeApp -Destination (Join-Path $stage 'previous_app')
            $oldApp = $true
        }
        Move-Item -LiteralPath $stagedApp -Destination $activeApp
        $newApp = $true
        if (-not $ready) {
            if (Test-Path -LiteralPath $activePython) {
                Move-Item -LiteralPath $activePython -Destination (Join-Path $stage 'previous_python')
                $oldRuntime = $true
            }
            Move-Item -LiteralPath (Join-Path $stage 'runtime\python') -Destination $activePython
            $newRuntime = $true
        }
        Update-Status '正在无窗口验证生成算法、玩法和离线环境' 95
        $smokeResult = Smoke-Test (Join-Path $activePython 'python.exe') $activeApp $dest $false
        Note $dest ('POST_INSTALL_' + ($smokeResult -replace '[\r\n]+', ' '))
        Update-Status '正在实际初始化图形窗口、资源与渲染器' 97
        try {
            $probeResult = Startup-Probe (Join-Path $activePython 'python.exe') $activeApp $dest $false
            Note $dest ('DISPLAY_PROBE ' + $probeResult)
        } catch {
            Note $dest ('DISPLAY_PROBE_RETRY_SAFE ' + $_.Exception.Message)
            Update-Status '已自动进入兼容验证，检查 CPU 后备渲染' 97
            $probeResult = Startup-Probe (Join-Path $activePython 'python.exe') $activeApp $dest $true
            Note $dest ('DISPLAY_PROBE_SAFE ' + $probeResult)
        }
        Get-ChildItem -LiteralPath $activeApp -Directory -Recurse -Filter '__pycache__' -ErrorAction SilentlyContinue |
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Save-Manifest $dest
        $manifestWritten = $true
        $launchBody = "@echo off`r`nchcp 65001 >nul`r`ncd /d `"%~dp0`"`r`nset PYGAME_HIDE_SUPPORT_PROMPT=1`r`nset PYTHONDONTWRITEBYTECODE=1`r`nstart `"`" `"%~dp0runtime\python\pythonw.exe`" `"%~dp0app\main.py`"`r`n"
        [System.IO.File]::WriteAllText($launch, $launchBody, ([System.Text.UTF8Encoding]::new($false)))
        $launcherWritten = $true
        $safeLauncher = Join-Path $dest '兼容模式.cmd'
        $safeBody = "@echo off`r`nchcp 65001 >nul`r`ncd /d `"%~dp0`"`r`nset PYGAME_HIDE_SUPPORT_PROMPT=1`r`nset PYTHONDONTWRITEBYTECODE=1`r`nstart `"`" `"%~dp0runtime\python\pythonw.exe`" `"%~dp0app\main.py`" --safe-mode`r`n"
        [System.IO.File]::WriteAllText($safeLauncher, $safeBody, ([System.Text.UTF8Encoding]::new($false)))
        $safeLauncherWritten = $true
        Note $dest 'INSTALL_READY_RENDER_VERIFIED'
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
        Update-Status '一切就绪 · 可离线运行 · 即将进入后室' 100
        $script:busy = $false
        $form.Close()
        Start-Process -FilePath (Join-Path $activePython 'pythonw.exe') -ArgumentList ('"' + (Join-Path $activeApp 'main.py') + '"') -WorkingDirectory $dest
    } catch {
        $message = $_.Exception.Message
        if ($dest) { Note $dest ('INSTALL_FAIL ' + ($message -replace '[\r\n]+', ' ')) }
        try {
            if ($stage -and (Test-Path -LiteralPath $stage)) {
                if ($newApp -and (Test-Path -LiteralPath $activeApp)) { Remove-Item -LiteralPath $activeApp -Recurse -Force }
                if ($oldApp -and (Test-Path -LiteralPath (Join-Path $stage 'previous_app'))) {
                    Move-Item -LiteralPath (Join-Path $stage 'previous_app') -Destination $activeApp
                }
                if ($newRuntime -and (Test-Path -LiteralPath $activePython)) { Remove-Item -LiteralPath $activePython -Recurse -Force }
                if ($oldRuntime -and (Test-Path -LiteralPath (Join-Path $stage 'previous_python'))) {
                    Move-Item -LiteralPath (Join-Path $stage 'previous_python') -Destination $activePython
                }
                if (Test-Path -LiteralPath (Join-Path $stage 'previous_install.json')) {
                    Copy-Item -LiteralPath (Join-Path $stage 'previous_install.json') -Destination (Join-Path $dest 'install.json') -Force
                } elseif ($manifestWritten -and (Test-Path -LiteralPath (Join-Path $dest 'install.json'))) {
                    Remove-Item -LiteralPath (Join-Path $dest 'install.json') -Force
                }
                if (Test-Path -LiteralPath (Join-Path $stage 'previous_launcher.cmd')) {
                    Copy-Item -LiteralPath (Join-Path $stage 'previous_launcher.cmd') -Destination (Join-Path $dest '进入后室.cmd') -Force
                } elseif ($launcherWritten -and (Test-Path -LiteralPath (Join-Path $dest '进入后室.cmd'))) {
                    Remove-Item -LiteralPath (Join-Path $dest '进入后室.cmd') -Force
                }
                if (Test-Path -LiteralPath (Join-Path $stage 'previous_safe_launcher.cmd')) {
                    Copy-Item -LiteralPath (Join-Path $stage 'previous_safe_launcher.cmd') -Destination (Join-Path $dest '兼容模式.cmd') -Force
                } elseif ($safeLauncherWritten -and (Test-Path -LiteralPath (Join-Path $dest '兼容模式.cmd'))) {
                    Remove-Item -LiteralPath (Join-Path $dest '兼容模式.cmd') -Force
                }
                Remove-Item -LiteralPath $stage -Recurse -Force
            }
        } catch { $message += '；自动回滚未完成，请检查游戏文件夹。' }
        Update-Status ('未完成：' + $message) $bar.Value
        if (-not $script:cancelRequested) {
            [System.Windows.Forms.MessageBox]::Show($message, '部署未完成', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
        }
    } finally {
        $script:busy = $false
        $script:cancelRequested = $false
        $start.Enabled = $true
        $choose.Enabled = $true
        $leave.Enabled = $true
        $leave.Text = '退出'
    }
})

[void]$form.ShowDialog()
$form.Dispose()
