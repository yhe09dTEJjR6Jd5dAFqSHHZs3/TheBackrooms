import argparse
import ast
import importlib.util
import math
import os
import tempfile
import tokenize
from pathlib import Path

from game import Game
from storage import Storage, DEFAULT_SETTINGS
from audio_synth import pcm, DURATIONS, SAMPLE_RATE


BASE = Path(__file__).resolve().parent


def check(root=None, require_runtime=True):
    sources = sorted(BASE.glob('*.py'))
    expected = {'main.py', 'game.py', 'world.py', 'storage.py', 'config.py', 'controls.py',
                'horror.py', 'gpu.py', 'renderer.py', 'sound.py', 'interface.py', 'effects.py',
                'verify.py', 'procedural.py', 'weapon3d.py', 'audio_synth.py'}
    if {p.name for p in sources} != expected:
        raise RuntimeError('INCOMPLETE_SOURCE')
    for source in sources:
        compile(source.read_bytes(), str(source), 'exec')
        with source.open('rb') as stream:
            if any(token.type == tokenize.COMMENT for token in tokenize.tokenize(stream.readline)):
                raise RuntimeError('SOURCE_HAS_COMMENT ' + source.name)
        tree = ast.parse(source.read_text(encoding='utf-8'))
        if any(ast.get_docstring(node) for node in ast.walk(tree)
               if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))):
            raise RuntimeError('SOURCE_HAS_DOCSTRING ' + source.name)
    assets = [p for p in BASE.rglob('*') if p.is_file() and p.suffix.lower() != '.py'
              and '__pycache__' not in p.parts]
    if assets:
        raise RuntimeError('UNEXPECTED_NONCODE_FILE ' + assets[0].name)
    for seed in (0, 1, 7, 13, 26, 87, 103, 307, 1207, 8309, 20080326, 2147483646):
        game = Game(seed=seed)
        if not game.world.spawn_clearance():
            raise RuntimeError('SPAWN_CLEARANCE_FAILED ' + str(seed))
        for direction in range(8):
            heading = math.tau * direction / 8
            dx, dy = math.cos(heading), math.sin(heading)
            if not game.world.can_move(game.x + dx * 1.4, game.y + dy * 1.4):
                raise RuntimeError('SPAWN_DIRECTION_BLOCKED ' + str(seed))
        if len(game.world.items) < 12:
            raise RuntimeError('INSUFFICIENT_CONTENT')
        if not game.world.route((game.x, game.y), game.world.exit):
            raise RuntimeError('EXIT_UNREACHABLE')
        for name in ('note', 'relay'):
            for item in game.world.items:
                if item['kind'] == name and not game.world.route((game.x, game.y), (item['x'], item['y'])):
                    raise RuntimeError('CLUE_UNREACHABLE')
        for forward, strafe in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            trial = Game(seed=seed)
            before = (trial.x, trial.y)
            trial.update(1. / 60, forward, strafe, False)
            if math.hypot(trial.x - before[0], trial.y - before[1]) < .02:
                raise RuntimeError('START_MOVEMENT_FAILED ' + str(seed))
        save = game.export_save()
        if not math.isfinite(Game(saved=save).x):
            raise RuntimeError('SAVE_RESTORE_FAILED')
        if game.attack('fire') not in ('shot', 'hit') or not game.tracers:
            raise RuntimeError('RAY_BALLISTICS_FAILED')
        game.weapon = 1
        game.attack_clock = 0.
        if game.attack('fire') not in ('shot', 'hit') or not game.projectiles:
            raise RuntimeError('PROJECTILE_BALLISTICS_FAILED')
        for _ in range(80):
            game.update(1. / 60, 0, 0, False)
        if game.projectiles:
            raise RuntimeError('PROJECTILE_EXPIRED_FAILED')
        if game.skill(0) != 'listen' or game.skill(1) != 'pulse':
            raise RuntimeError('SKILL_FAILED')
    for seed in range(64):
        depth = seed % 9
        game = Game(seed=seed * 331, depth=depth)
        if not game.world.spawn_clearance() or game.depth != depth:
            raise RuntimeError('DEEP_SPAWN_INVALID ' + str(seed))
        if not game.world.route(game.world.spawn, game.world.exit):
            raise RuntimeError('DEEP_EXIT_UNREACHABLE ' + str(seed))
        for item in game.world.items:
            if not game.world.route(game.world.spawn, (item['x'], item['y'])):
                raise RuntimeError('DEEP_ITEM_UNREACHABLE ' + str(seed) + ' ' + item['id'])
        recovered = Game(saved=game.export_save())
        if recovered.depth != depth or recovered.world.architecture != game.world.architecture:
            raise RuntimeError('DEEP_SAVE_MISMATCH')
        candidates = [(x, y) for y in range(2, game.world.height - 2)
                      for x in range(2, game.world.width - 2)
                      if game.world._rift_candidate(x, y)]
        if candidates:
            opened = candidates[0]
            game.world.restore_passages([list(opened)])
            if opened not in game.world.passages or not game.world.route(game.world.spawn, game.world.exit):
                raise RuntimeError('ARCHITECTURE_CHANGE_BROKE_ROUTE')
            saved = game.export_save()
            reloaded = Game(saved=saved)
            if opened not in reloaded.world.passages:
                raise RuntimeError('PERMANENT_PASSAGE_SAVE_FAILED')
        if seed in (0, 7, 13):
            game.elapsed = 100.
            game.horror.cooldown = 0.
            for _ in range(430):
                game.horror.update(game, 1.)
            if game.horror.pattern_stage != 3 or game.horror.event_count < 12:
                raise RuntimeError('HORROR_PATTERN_STALLED')
            copy = Game(saved=game.export_save())
            if copy.horror.pattern_stage != 3 or copy.horror.pattern != game.horror.pattern:
                raise RuntimeError('HORROR_PATTERN_RESTORE_FAILED')
    target = Path(root or BASE.parent).resolve()
    target.mkdir(parents=True, exist_ok=True)
    data = target / 'data'
    data.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='verify_', dir=data) as directory:
        store = Storage(directory)
        try:
            game = Game(seed=371, depth=4)
            if not store.save(game, durable=True) or not store.load():
                raise RuntimeError('SYNCHRONOUS_SAVE_FAILED')
            game.x, game.y = game.world.spawn
            game.elapsed = 3.2
            if not store.save(game, durable=True):
                raise RuntimeError('BACKUP_SAVE_FAILED')
            (store.data / 'savegame.json').write_bytes(b'{invalid')
            if not store.load() or store.load()['seed'] != game.seed:
                raise RuntimeError('SAVE_BACKUP_RECOVERY_FAILED')
            original = store._write_json
            def fail_save(name, payload, backup=False):
                if name == 'savegame.json':
                    raise OSError('simulated disk failure')
                return original(name, payload, backup)
            store._write_json = fail_save
            if store.save(game, durable=True) or not store.pop_io_errors():
                raise RuntimeError('SAVE_FAILURE_UNREPORTED')
            store._write_json = original
            if not store.save(game, durable=True):
                raise RuntimeError('SAVE_FAILURE_RECOVERY_FAILED')
            game.won = True
            original = store._write_json
            def fail_archive(name, payload, backup=False):
                if name == 'archive.json':
                    raise OSError('simulated archive failure')
                return original(name, payload, backup)
            store._write_json = fail_archive
            if store.record_completion(game) is not None or store.archive_count() != 0:
                raise RuntimeError('ARCHIVE_FAILURE_UNREPORTED')
            store._write_json = original
            store.pop_io_errors()
            if store.record_completion(game) != 1:
                raise RuntimeError('ARCHIVE_COMMIT_FAILED')
            stats = store.archive_summary()
            if stats['deepest_depth'] != 4 or stats['patterns'].get(game.horror.pattern) != 1:
                raise RuntimeError('ARCHIVE_PROGRESS_INCONSISTENT')
            desktop = store._desktop
            store._desktop = lambda: Path(directory)
            try:
                target_zip = store.blackbox(game, {'probe': 'verification'})
                if not target_zip.exists() or target_zip.stat().st_size > 1_000_000:
                    raise RuntimeError('BLACKBOX_SIZE_INVALID')
            finally:
                store._desktop = desktop
        finally:
            store.release_instance()
    if require_runtime:
        if importlib.util.find_spec('pygame') is None:
            raise RuntimeError('PYGAME_NOT_INSTALLED')
        os.environ['SDL_VIDEODRIVER'] = 'dummy'
        os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')
        import pygame
        from procedural import art, WALL_NAMES, SPRITE_NAMES
        from weapon3d import WeaponMesh
        from config import WALL_TEXTURE_SIZE, ENTITY_TEXTURE_SIZE
        from gpu import FRAGMENT, VERTEX
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_mode((32, 32))
        try:
            for name in WALL_NAMES + SPRITE_NAMES + ('mask_on', 'mask_danger', 'icon'):
                surface = art(name, 37)
                if not isinstance(surface, pygame.Surface) or min(surface.get_size()) <= 0:
                    raise RuntimeError('PROCEDURAL_ART_FAILED ' + name)
            if art('wall').get_width() < WALL_TEXTURE_SIZE or art('creature').get_size() != ENTITY_TEXTURE_SIZE:
                raise RuntimeError('VISUAL_QUALITY_REGRESSION')
            if not {'creature_stride','creature_lurk','creature_still'} <= set(SPRITE_NAMES):
                raise RuntimeError('ENTITY_ANIMATION_MISSING')
            if 'tension' not in FRAGMENT or '#version 120' not in VERTEX:
                raise RuntimeError('GPU_SHADER_INCOMPLETE')
            for variant in (0, 1):
                mesh = WeaponMesh(variant)
                if len(mesh.faces) < 200:
                    raise RuntimeError('PROCEDURAL_WEAPON_FAILED')
            for name in ('step', 'shot_flare', 'ambience'):
                samples = pcm(name, 31)
                if len(samples) < int(DURATIONS[name] * SAMPLE_RATE * 4 * .9):
                    raise RuntimeError('PROCEDURAL_SOUND_FAILED ' + name)
            from interface import Interface
            from controls import Controls
            from renderer import SceneRenderer
            from effects import VisualEffects
            ui = Interface()
            controls = Controls({'bindings': {}})
            game = Game(seed=241, depth=2)
            settings = dict(DEFAULT_SETTINGS)
            for size in ((320, 240), (560, 360), (1024, 768)):
                screen = pygame.display.set_mode(size)
                if size[0] <= 560:
                    renderer = SceneRenderer(size, 'ECO')
                    renderer.draw(screen, game, 5., True)
                    VisualEffects().draw(screen, game, 5., True)
                for state in ('MENU', 'SETTINGS', 'MAP', 'PAUSE', 'WON', 'ARCHIVE', 'DIAGNOSTICS'):
                    ui.draw(screen, game, state, True, settings, 60., controls)
                    if any(rect.w <= 0 or rect.h <= 0 or rect.left < -1 or rect.top < -1
                           or rect.right > size[0] + 1 or rect.bottom > size[1] + 1
                           for rect, action in ui.buttons):
                        raise RuntimeError('UI_BUTTON_OUT_OF_BOUNDS ' + str(size) + ' ' + state)
                    if state == 'MENU' and len(ui.buttons) != 7:
                        raise RuntimeError('MENU_ACTIONS_UNAVAILABLE ' + str(size))
        finally:
            pygame.display.quit()
    return len(sources), 5 + 16 + 3, len(DURATIONS)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default=str(BASE.parent))
    parser.add_argument('--skip-runtime', action='store_true')
    args = parser.parse_args()
    files, materials, sound_types = check(args.root, not args.skip_runtime)
    print(f'VERIFY_OK code={files} procedural_art={materials} procedural_audio={sound_types}')
