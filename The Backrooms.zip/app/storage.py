import ctypes
import datetime
import hashlib
import json
import math
import os
import platform
import re
import shutil
import traceback
import zipfile


class InstanceBusyError(RuntimeError):
    pass

from pathlib import Path

from config import ARCHIVE_RECENT_LIMIT, BLACKBOX_LIMIT, VERSION as APP_VERSION
DEFAULT_SETTINGS = {'quality': 'AUTO', 'volume': .65, 'sensitivity': .0024,
                    'fullscreen': False, 'reduce_flash': False, 'target_fps': 60,
                    'gpu_scaling': True, 'gpu_approved': True, 'assist': True, 'immersive_hud': True,
                    'horror_intensity': 1.0, 'ui_scale': 1.0, 'bindings': {}}


class Storage:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.data = self.root / 'data'
        self.data.mkdir(parents=True, exist_ok=True)
        self.log_file = self.data / 'events.log'
        self._mutex = None
        self._lock_file = None
        self._session_original_settings = {}
        self.settings = self._load_json('settings.json')
        if self.settings.get('gpu_approved') is False:
            self.settings['gpu_scaling'] = True
            self.settings['gpu_approved'] = True
        self.settings = {**DEFAULT_SETTINGS, **{k: v for k, v in self.settings.items() if k in DEFAULT_SETTINGS}}
        self.settings['quality'] = self.settings['quality'] if self.settings['quality'] in ('AUTO', 'HIGH', 'ECO') else 'AUTO'
        for name, low, high in (('volume', 0, 1), ('sensitivity', .0008, .006),
                                ('horror_intensity', .55, 1.5), ('ui_scale', .75, 1.40)):
            try:
                v = float(self.settings[name])
                self.settings[name] = min(high, max(low, v)) if math.isfinite(v) else DEFAULT_SETTINGS[name]
            except (TypeError, ValueError):
                self.settings[name] = DEFAULT_SETTINGS[name]
        self.settings['fullscreen'] = self.settings['fullscreen'] is True
        self.settings['reduce_flash'] = self.settings['reduce_flash'] is True
        self.settings['gpu_approved'] = self.settings['gpu_approved'] is True
        self.settings['gpu_scaling'] = self.settings['gpu_scaling'] is True
        self.settings['assist'] = self.settings['assist'] is not False
        self.settings['immersive_hud'] = self.settings['immersive_hud'] is not False
        self.settings['target_fps'] = self.settings['target_fps'] if type(self.settings['target_fps']) is int and self.settings['target_fps'] in (30, 45, 60, 90, 120) else 60
        if not isinstance(self.settings['bindings'], dict):
            self.settings['bindings'] = {}

    def _load_json(self, name):
        path = self.data / name
        try:
            if path.stat().st_size > 300_000:
                return {}
            data = json.loads(path.read_text(encoding='utf-8'))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError, UnicodeError):
            return {}

    def _write_json(self, name, payload, backup=False):
        path = self.data / name
        tmp = self.data / (name + '.pending')
        text = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        try:
            with tmp.open('w', encoding='utf-8') as stream:
                stream.write(text)
                stream.flush()
                os.fsync(stream.fileno())
            if backup and path.is_file():
                old = self._load_json(name)
                if old and type(old.get('seed')) is int:
                    staged = self.data / (name + '.backup_pending')
                    shutil.copyfile(path, staged)
                    os.replace(staged, self.data / (name + '.bak'))
            os.replace(tmp, path)
        finally:
            tmp.unlink(missing_ok=True)

    def apply_session_settings(self, changes):
        for name, value in changes.items():
            if name not in DEFAULT_SETTINGS:
                raise KeyError(name)
            if name not in self._session_original_settings:
                self._session_original_settings[name] = self.settings[name]
            self.settings[name] = value

    def commit_session_setting(self, name):
        self._session_original_settings.pop(name, None)

    def persist_settings(self):
        try:
            self._write_json('settings.json', {**self.settings, **self._session_original_settings})
            return True
        except (OSError, ValueError, TypeError) as error:
            self.log(f'SETTINGS_WRITE_FAILED {type(error).__name__}')
            return False

    def save(self, game):
        try:
            self._write_json('savegame.json', game.export_save(), backup=True)
            return True
        except (OSError, ValueError, TypeError) as error:
            self.log(f'SAVE_WRITE_FAILED {type(error).__name__}')
            return False

    @staticmethod
    def _valid_save(data):
        return (isinstance(data, dict) and type(data.get('seed')) is int
                and 0 <= data['seed'] < 2147483648
                and isinstance(data.get('x'), (int, float))
                and type(data.get('x')) in (int, float) and math.isfinite(data['x'])
                and type(data.get('y')) in (int, float) and math.isfinite(data['y'])
                and 0 <= data['x'] <= 100000 and 0 <= data['y'] <= 100000)

    def load(self):
        result = self._load_json('savegame.json')
        if self._valid_save(result):
            return result
        result = self._load_json('savegame.json.bak')
        if self._valid_save(result):
            self.log('SAVE_RECOVERED_FROM_BACKUP')
            return result
        return {}

    def _archive_data(self):
        archive = self._load_json('archive.json')
        runs = archive.get('runs', [])
        runs = [run for run in runs if isinstance(run, dict)] if isinstance(runs, list) else []
        total = archive.get('total_runs')
        total = max(len(runs), total) if type(total) is int and total >= 0 else len(runs)
        endings = archive.get('endings')
        if not isinstance(endings, dict):
            endings = {}
            for run in runs:
                ending = run.get('ending')
                if isinstance(ending, str) and ending:
                    endings[ending] = endings.get(ending, 0) + 1
        endings = {key[:48]: max(0, min(int(value), 1_000_000_000))
                   for key, value in endings.items() if isinstance(key, str) and type(value) is int}
        best = archive.get('best_seconds')
        if type(best) not in (float, int) or not math.isfinite(best) or best <= 0:
            values = [run.get('seconds') for run in runs]
            values = [float(val) for val in values if type(val) in (int, float) and math.isfinite(val) and val > 0]
            best = min(values) if values else None
        daily = archive.get('daily_runs')
        if type(daily) is not int or daily < 0:
            daily = sum(run.get('mode') == 'DAILY' for run in runs)
        seconds = archive.get('total_seconds')
        if type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds < 0:
            seconds = sum(float(run.get('seconds', 0)) for run in runs
                          if type(run.get('seconds')) in (int, float) and math.isfinite(run['seconds']))
        recoveries = archive.get('total_recoveries')
        if type(recoveries) is not int or recoveries < 0:
            recoveries = sum(int(run.get('recoveries', 0)) for run in runs
                             if type(run.get('recoveries')) is int and run['recoveries'] >= 0)
        profile = archive.get('profile', {})
        if not isinstance(profile, dict):
            profile = {}
        profile = {key: max(0., min(10_000_000., float(profile.get(key, 0.))))
                   if type(profile.get(key, 0.)) in (int, float) and math.isfinite(profile.get(key, 0.)) else 0.
                   for key in ('shots', 'stealth_seconds', 'sprint_seconds', 'revisits', 'observations')}
        missions = archive.get('missions', {})
        missions = {key: max(0, min(1_000_000_000, value)) if type(value) is int else 0
                    for key, value in missions.items() if key in ('TAPES', 'ECHO', 'SURVEY', 'SIGNAL', 'MIXED')} if isinstance(missions, dict) else {}
        daily_bests = archive.get('daily_bests', {})
        daily_bests = {str(key)[:12]: float(value) for key, value in daily_bests.items()
                       if type(value) in (int, float) and math.isfinite(value) and 0 < value < 1e6} if isinstance(daily_bests, dict) else {}
        daily_bests = dict(sorted(daily_bests.items())[-120:])
        return {'schema': 3, 'total_runs': total, 'endings': endings,
                'daily_runs': daily, 'best_seconds': best, 'total_seconds': seconds,
                'total_recoveries': recoveries, 'runs': runs[-ARCHIVE_RECENT_LIMIT:],
                'profile': profile, 'missions': missions, 'daily_bests': daily_bests}

    def record_completion(self, game):
        archive = self._archive_data()
        archive['total_runs'] += 1
        archive['daily_runs'] += int(game.mode == 'DAILY')
        archive['total_seconds'] += game.elapsed
        archive['total_recoveries'] += game.recoveries
        archive['best_seconds'] = min(archive['best_seconds'], game.elapsed) if archive['best_seconds'] else game.elapsed
        mission = getattr(game, 'mission', 'TAPES')
        archive['missions'][mission] = archive['missions'].get(mission, 0) + 1
        behavior = getattr(game, 'behavior', {})
        for key in ('shots', 'stealth_seconds', 'sprint_seconds', 'observations'):
            archive['profile'][key] += min(100_000., float(behavior.get(key, 0)))
        archive['profile']['revisits'] += sum(v > 1 for v in game.horror.visits.values())
        if game.mode == 'DAILY':
            day = datetime.date.today().isoformat()
            previous = archive['daily_bests'].get(day)
            archive['daily_bests'][day] = min(previous, game.elapsed) if previous else game.elapsed
            archive['daily_bests'] = dict(sorted(archive['daily_bests'].items())[-120:])
        ending = str(game.ending)[:48]
        archive['endings'][ending] = archive['endings'].get(ending, 0) + 1
        archive['runs'].append({'seed': game.seed, 'seconds': round(game.elapsed, 1),
                                'recoveries': game.recoveries, 'ending': ending, 'mode': game.mode,
                                'echoes': len(game.echoes), 'mission': mission, 'daily_rule': game.daily_rule,
                                'imprints': len(game.world.imprints),
                                'date': datetime.datetime.now().isoformat(timespec='seconds')})
        archive['runs'] = archive['runs'][-ARCHIVE_RECENT_LIMIT:]
        try:
            self._write_json('archive.json', archive)
        except (OSError, TypeError, ValueError) as error:
            self.log(f'ARCHIVE_FAILED {type(error).__name__}')
        return archive['total_runs']

    def archive_count(self):
        return self._archive_data()['total_runs']

    def archive_summary(self):
        return self._archive_data()

    def clear_save(self):
        for name in ('savegame.json', 'savegame.json.bak'):
            try:
                (self.data / name).unlink(missing_ok=True)
            except OSError:
                pass

    def acquire_instance(self):
        if self._mutex is not None or self._lock_file is not None:
            return
        name = hashlib.sha256(os.path.normcase(str(self.root)).encode('utf-8')).hexdigest()[:32]
        if os.name == 'nt':
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            create = kernel.CreateMutexW
            create.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p)
            create.restype = ctypes.c_void_p
            handle = create(None, False, 'Local\\Backrooms_' + name)
            if not handle:
                raise OSError('无法创建游戏实例锁')
            if ctypes.get_last_error() == 183:
                kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
                kernel.CloseHandle(handle)
                raise InstanceBusyError('这个游戏目录已经有一个窗口正在运行')
            self._mutex = handle
        else:
            import fcntl
            handle = (self.data / '.instance.lock').open('a+b')
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except (BlockingIOError, OSError):
                handle.close()
                raise InstanceBusyError('这个游戏目录已经有一个窗口正在运行')
            self._lock_file = handle

    def release_instance(self):
        if self._mutex is not None:
            try:
                ctypes.WinDLL('kernel32').CloseHandle(ctypes.c_void_p(self._mutex))
            finally:
                self._mutex = None
        if self._lock_file is not None:
            try:
                import fcntl
                fcntl.flock(self._lock_file, fcntl.LOCK_UN)
            finally:
                self._lock_file.close()
                self._lock_file = None

    def start_session(self, safe_mode=False):
        previous = self._load_json('session.json')
        unexpected = previous.get('active') is True
        session = {'active': True, 'version': APP_VERSION,
                   'started': datetime.datetime.now().isoformat(timespec='seconds'),
                   'safe_mode': bool(safe_mode or unexpected), 'stage': 'initializing',
                   'last_position': None, 'renderer': 'pending', 'pid': os.getpid()}
        try:
            self._write_json('session.json', session)
        except OSError:
            pass
        if unexpected:
            try:
                self._write_json('last_crash.json', previous)
            except OSError:
                pass
            self.log('UNCLEAN_PREVIOUS_EXIT switching_to_safe_mode')
        return unexpected

    def heartbeat(self, game=None, renderer='pending', stage='menu'):
        data = {'active': True, 'version': APP_VERSION,
                'time': datetime.datetime.now().isoformat(timespec='seconds'),
                'stage': str(stage), 'renderer': str(renderer), 'pid': os.getpid(),
                'last_position': [round(game.x, 2), round(game.y, 2)] if game else None,
                'seed': game.seed if game else None}
        try:
            self._write_json('session.json', data)
        except OSError:
            pass

    def end_session(self):
        try:
            self._write_json('session.json', {'active': False,
                                              'finished': datetime.datetime.now().isoformat(timespec='seconds')})
        except OSError:
            pass

    def preserve_previous(self):
        current = self._load_json('savegame.json')
        if not self._valid_save(current):
            current = self._load_json('savegame.json.bak')
        if not self._valid_save(current):
            return False
        try:
            self._write_json('previous_save.json', current)
            return True
        except (OSError, TypeError, ValueError) as error:
            self.log(f'PREVIOUS_SAVE_FAILED {type(error).__name__}')
            return False

    def previous_available(self):
        return self._valid_save(self._load_json('previous_save.json'))

    def restore_previous(self):
        previous = self._load_json('previous_save.json')
        if not self._valid_save(previous):
            return False
        current = self.load()
        try:
            self._write_json('savegame.json', previous, backup=False)
            if self._valid_save(current):
                self._write_json('previous_save.json', current)
            else:
                (self.data / 'previous_save.json').unlink(missing_ok=True)
            return True
        except (OSError, TypeError, ValueError) as error:
            self.log(f'PREVIOUS_RESTORE_FAILED {type(error).__name__}')
            return False

    @staticmethod
    def _redact(value):
        value = str(value)
        value = re.sub(r'(?i)[A-Z]:\\Users\\[^\\\r\n]+', '<PROFILE>', value)
        value = re.sub(r'(?i)/(?:home|Users)/[^/\r\n]+', '<PROFILE>', value)
        value = re.sub(r'(?i)[a-z0-9_.+\-]+@[a-z0-9.\-]+\.[a-z]{2,}', '<EMAIL>', value)
        value = re.sub(r'(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)', '<IP>', value)
        value = re.sub(r'(?i)\b(bearer\s+)[A-Za-z0-9._~+\-/=]+', r'\1<REDACTED>', value)
        value = re.sub(r'(?i)(https?://)[^/@\s]+:[^/@\s]+@', r'\1<REDACTED>@', value)
        value = re.sub(r'(?i)([?&](?:api[_-]?key|access[_-]?token|refresh[_-]?token|token|secret|password|signature|sessionid|authorization)=)[^&\s]+',
                       r'\1<REDACTED>', value)
        value = re.sub(r'(?i)\b((?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret|authorization|cookie)\s*[:=]\s*)(?:"[^"\r\n]*"|\'[^\'\r\n]*\'|[^\s&,;]+)',
                       r'\1<REDACTED>', value)
        value = re.sub(r'(?i)[A-Z]:\\[^\s\r\n]+', '<PATH>', value)
        return value

    def log(self, message):
        stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        message = re.sub(r'[\r\n\t]+', ' ', str(message))
        message = self._redact(message)[:250]
        try:
            if self.log_file.exists() and self.log_file.stat().st_size > 64_000:
                retained = self.log_file.read_text('utf-8', errors='replace')[-30_000:]
                self.log_file.write_text(retained, encoding='utf-8')
            with self.log_file.open('a', encoding='utf-8') as f:
                f.write(f'[{stamp}] {message}\n')
        except OSError:
            pass

    def log_error(self, error):
        self.log(f'ERROR {type(error).__name__}: {str(error)[:170]}')
        trace = traceback.extract_tb(error.__traceback__)
        for frame in trace[-9:]:
            self.log(f'{Path(frame.filename).name}:{frame.lineno} {frame.name}')

    @staticmethod
    def _desktop():
        if os.name == 'nt':
            try:
                from ctypes import wintypes
                import uuid
                class GUID(ctypes.Structure):
                    _fields_ = [('Data1', ctypes.c_uint32), ('Data2', ctypes.c_uint16),
                                ('Data3', ctypes.c_uint16), ('Data4', ctypes.c_ubyte * 8)]
                guid = uuid.UUID('B4BFCC3A-DB2C-424C-B029-7FE99A87C641')
                raw = guid.bytes_le
                folder_guid = GUID.from_buffer_copy(raw)
                shell = ctypes.WinDLL('shell32')
                shell.SHGetKnownFolderPath.argtypes = (ctypes.POINTER(GUID), wintypes.DWORD,
                                                       wintypes.HANDLE, ctypes.POINTER(ctypes.c_wchar_p))
                path = ctypes.c_wchar_p()
                result = shell.SHGetKnownFolderPath(ctypes.byref(folder_guid), 0, None, ctypes.byref(path))
                try:
                    if result == 0 and path.value and Path(path.value).is_dir():
                        return Path(path.value)
                finally:
                    if path:
                        ctypes.WinDLL('ole32').CoTaskMemFree(ctypes.cast(path, ctypes.c_void_p))
            except (OSError, ValueError, AttributeError):
                pass
            try:
                import winreg
                key_path = r'Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as key:
                    value, _ = winreg.QueryValueEx(key, 'Desktop')
                result = Path(os.path.expandvars(value))
                if result.is_dir():
                    return result
            except (OSError, ValueError):
                pass
        return Path.home() / 'Desktop'

    @classmethod
    def _sanitize(cls, value):
        if isinstance(value, str):
            return cls._redact(value)
        if isinstance(value, dict):
            return {cls._redact(k): ('<REDACTED>' if re.search(r'(?i)(?:password|secret|api[_-]?key|(?:access|refresh)[_-]?token|authorization|cookie)', k) else cls._sanitize(v)) for k, v in value.items() if isinstance(k, str)}
        if isinstance(value, list):
            return [cls._sanitize(v) for v in value[:150]]
        return value

    def _blackbox_payload(self, game, runtime):
        meta = {'app': 'Backrooms: Low Frequency', 'version': APP_VERSION,
                'exported': datetime.datetime.now().isoformat(timespec='seconds'),
                'platform': platform.system(), 'release': platform.release(), 'architecture': platform.machine(),
                'runtime': self._sanitize(runtime)}
        status = self._sanitize(game.diagnostic()) if game else {'mode': 'menu'}
        def recent(name, limit):
            try:
                content = (self.data / name).read_text('utf-8', errors='replace')
            except OSError:
                return ''
            return self._redact(content[-limit:])
        return {'meta.json': json.dumps(meta, ensure_ascii=False, separators=(',', ':')),
                'settings.json': json.dumps(self._sanitize(self.settings), ensure_ascii=False, separators=(',', ':')),
                'status.json': json.dumps(status, ensure_ascii=False, separators=(',', ':')),
                'events.log': recent('events.log', 24_000),
                'install.log': recent('install.log', 10_000),
                'crash.log': recent('crash.log', 32_000),
                'session.json': json.dumps(self._sanitize(self._load_json('session.json')), ensure_ascii=False),
                'last_crash.json': json.dumps(self._sanitize(self._load_json('last_crash.json')), ensure_ascii=False)}

    def blackbox_preview(self, game=None, runtime=None):
        payload = self._blackbox_payload(game, runtime or {})
        lines = payload['events.log'].splitlines()
        return {'files': list(payload), 'estimated_bytes': sum(len(v.encode('utf-8')) for v in payload.values()),
                'recent': lines[-4:], 'sanitized': True}

    def blackbox(self, game, runtime):
        desktop = self._desktop()
        if not desktop.is_dir():
            raise OSError('系统桌面文件夹不存在')
        now = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        target = desktop / f'Backrooms_BlackBox_{now}.zip'
        payload = self._blackbox_payload(game, runtime)
        try:
            with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as arc:
                for name, content in payload.items():
                    arc.writestr(name, content)
            if target.stat().st_size > BLACKBOX_LIMIT:
                target.unlink(missing_ok=True)
                raise OSError('黑匣子超过容量限制')
        except Exception:
            target.unlink(missing_ok=True)
            raise
        self.log('BLACKBOX_EXPORTED')
        return target
