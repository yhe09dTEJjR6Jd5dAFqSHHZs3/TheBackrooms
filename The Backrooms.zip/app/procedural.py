import functools
import math
import random

import pygame

from config import WALL_TEXTURE_SIZE, ENTITY_TEXTURE_SIZE


WALL_NAMES = ('wall', 'wall_stained', 'wall_aged', 'wall_damp', 'wall_faded')
SPRITE_NAMES = ('fragment', 'cell', 'echo', 'creature', 'creature_stride', 'creature_lurk', 'creature_still', 'exit', 'light', 'apparition', 'false_door', 'relay', 'note', 'chair', 'sign', 'pipe')


def _stroke(surface, a, b, color, size=1):
    pygame.draw.line(surface, color, a, b, size)


def _metal(surface, rect, tint=(66, 70, 62), border=3):
    rect = pygame.Rect(rect)
    pygame.draw.rect(surface, (13, 15, 14, 255), rect.inflate(border * 2, border * 2), border_radius=3)
    pygame.draw.rect(surface, (*tint, 255), rect, border_radius=2)
    pygame.draw.line(surface, (159, 154, 132, 230), (rect.left + 3, rect.top + 3),
                     (rect.right - 3, rect.top + 3), 2)
    pygame.draw.line(surface, (18, 19, 17, 255), (rect.left + 3, rect.bottom - 4),
                     (rect.right - 3, rect.bottom - 4), 2)
    for x in (rect.left + 7, rect.right - 8):
        for y in (rect.top + 7, rect.bottom - 8):
            pygame.draw.circle(surface, (18, 19, 17), (x, y), 3)
            pygame.draw.circle(surface, (126, 119, 94), (x, y), 1)


def _wall(index, seed):
    rnd = random.Random(seed + index * 9083)
    size = WALL_TEXTURE_SIZE
    base = ((152, 144, 96), (132, 125, 86), (142, 129, 82), (117, 119, 88), (159, 150, 101))[index]
    surf = pygame.Surface((size, size)).convert()
    surf.fill(base)
    for y in range(size):
        band = math.sin(y * .008) * 7. + math.cos(y * .031) * 3. + math.sin(y * .129) * 1.5
        shade = tuple(max(0, min(255, int(channel + band))) for channel in base)
        pygame.draw.line(surf, shade, (0, y), (size, y))
    interval = max(32, size // 8)
    for x in range(0, size, interval):
        shift = rnd.randrange(-3, 4)
        dark = tuple(max(0, channel - 14) for channel in base)
        light = tuple(min(255, channel + 10) for channel in base)
        _stroke(surf, (x + shift, 0), (x + shift, size), dark, 2)
        _stroke(surf, (x + shift + 3, 0), (x + shift + 3, size), light, 1)
        for y in range(0, size, 35):
            ix = x + interval // 2
            if ix >= size:
                continue
            tiny = int(5 * math.sin((y + ix) * .07))
            pygame.draw.arc(surf, (base[0]-8, base[1]-8, base[2]-5),
                            (ix - 11 + tiny, y, 21, 30), .17, 3.1, 1)
            pygame.draw.arc(surf, (base[0]+8, base[1]+7, base[2]+6),
                            (ix - 8 + tiny, y+3, 17, 24), 3.35, 6.15, 1)
            _stroke(surf, (ix + tiny, y + 15), (ix + tiny - 1, y + 22),
                    (max(0, base[0]-11), max(0, base[1]-12), max(0, base[2]-9)))
    for _ in range(size * size // 4):
        x, y = rnd.randrange(size), rnd.randrange(size)
        noise = rnd.randrange(-23, 21)
        if index in (2, 3) and rnd.random() < .20:
            noise -= rnd.randrange(8, 38)
        surf.set_at((x, y), tuple(max(0, min(255, c + noise)) for c in base))
    dirt = pygame.Surface((size, size), pygame.SRCALPHA)
    for _ in range(75 + index * 23):
        x, y = rnd.randrange(size), rnd.randrange(size)
        rx, ry = rnd.randrange(9, 67), rnd.randrange(10, 96)
        pygame.draw.ellipse(dirt, (25, 32, 26, rnd.randrange(3, 17)),
                            (x-rx, y-ry, rx*2, ry*2))
    for _ in range(280 + index * 50):
        x, y = rnd.randrange(size), rnd.randrange(size)
        length = rnd.randrange(2, 38)
        pygame.draw.line(dirt, (15, 25, 20, rnd.randrange(5, 34)),
                         (x,y), (x+rnd.randrange(-5,6), y+length), rnd.randrange(1,4))
    for _ in range(8 + index * 5):
        x = rnd.randrange(size)
        y = rnd.randrange(size)
        points = [(x, y)]
        for section in range(rnd.randrange(3, 10)):
            x += rnd.randrange(-12, 13)
            y += rnd.randrange(7, 25)
            points.append((x, y))
        pygame.draw.lines(dirt, (14, 25, 21, rnd.randrange(13, 49)), False, points, 1)
        if index >= 2:
            pygame.draw.lines(dirt, (212, 195, 143, 20), False,
                              [(a+2,b) for a,b in points], 1)
    for _ in range(12 + index * 3):
        x, y = rnd.randrange(0,size), rnd.randrange(0,size)
        width = rnd.randrange(7, 40)
        height = rnd.randrange(5, 45)
        pygame.draw.polygon(dirt, (58, 55, 41, rnd.randrange(18, 52)),
                            ((x,y),(x+width,y-4),(x+width-5,y+height),(x+9,y+height+6)))
        pygame.draw.line(dirt, (213,198,149,35), (x+2,y), (x+width,y-4), 2)
    if index == 3:
        for _ in range(29):
            x = rnd.randrange(size)
            y = rnd.randrange(-20, 30)
            pygame.draw.line(dirt, (30,40,28,rnd.randrange(18,65)),
                             (x,y),(x+rnd.randrange(-8,9),y+rnd.randrange(110,320)),rnd.randrange(2,10))
    surf.blit(dirt,(0,0))
    return surf


def _creature(name, seed):
    rnd = random.Random(seed ^ sum(ord(c)*31 for c in name))
    w,h = ENTITY_TEXTURE_SIZE
    canvas = pygame.Surface((w*2,h*2),pygame.SRCALPHA)
    ghost = name == 'apparition'
    stride = 1 if name == 'creature_stride' else -1 if name == 'creature_lurk' else 0
    crouch = 23 if name == 'creature_lurk' else 0
    tilt = 13 if name == 'creature_still' else -8 if name == 'creature_lurk' else 4
    dark = (9,13,13,251)
    tissue = (37,44,39,249) if not ghost else (49,70,68,207)
    skin = (70,74,61,247) if not ghost else (92,110,101,180)
    bone = (116,110,86,229) if not ghost else (116,149,132,142)
    fabric = (28,32,29,252) if not ghost else (33,55,51,173)
    def point(v):
        return (int(v[0]*2),int(v[1]*2))
    def poly(vertices,color):
        pygame.draw.polygon(canvas,color,[point(v) for v in vertices])
    def stroke(vertices,color,width):
        if len(vertices)>1:
            pygame.draw.lines(canvas,color,False,[point(v) for v in vertices],max(1,int(width*2)))
    def ellipse(x,y,rx,ry,color):
        pygame.draw.ellipse(canvas,color,(int((x-rx)*2),int((y-ry)*2),int(rx*4),int(ry*4)))
    def bonechain(vertices,width):
        for k in range(len(vertices)-1):
            ax,ay=vertices[k]
            bx,by=vertices[k+1]
            dx,dy=bx-ax,by-ay
            length=math.hypot(dx,dy) or 1.
            nx,ny=-dy/length,dx/length
            start_r=width*(.64 if k==0 else .46)
            end_r=width*(.45 if k==len(vertices)-2 else .59)
            mid_x=(ax+bx)*.5+rnd.uniform(-4,4)
            mid_y=(ay+by)*.5
            middle_r=width*rnd.uniform(.45,.72)
            silhouette=((ax+nx*start_r+2,ay+ny*start_r),
                        (mid_x+nx*(middle_r+4),mid_y+ny*(middle_r+4)),
                        (bx+nx*end_r,by+ny*end_r),
                        (bx-nx*(end_r+2),by-ny*(end_r+2)),
                        (mid_x-nx*(middle_r+5),mid_y-ny*(middle_r+5)),
                        (ax-nx*(start_r+4),ay-ny*(start_r+4)))
            poly(silhouette,(5,9,10,251))
            poly(((ax+nx*(start_r-3),ay+ny*(start_r-3)),
                  (mid_x+nx*middle_r,mid_y+ny*middle_r),
                  (bx+nx*(end_r-2),by+ny*(end_r-2)),
                  (bx-nx*(end_r-5),by-ny*(end_r-5)),
                  (mid_x-nx*(middle_r-4),mid_y-ny*(middle_r-4)),
                  (ax-nx*(start_r-5),ay-ny*(start_r-5))),tissue)
            poly(((ax+nx*(start_r-6),ay+ny*(start_r-6)),
                  (mid_x+nx*(middle_r-4),mid_y+ny*(middle_r-4)),
                  (bx+nx*(end_r-5),by+ny*(end_r-5)),
                  (bx+nx*(end_r*.05),by+ny*(end_r*.05)),
                  (mid_x+nx*(middle_r*.01),mid_y+ny*(middle_r*.01)),
                  (ax+nx*(start_r*.1),ay+ny*(start_r*.1))),
                 (74,78,64,219) if not ghost else (87,113,101,133))
            for n in range(8):
                t=rnd.uniform(.15,.9)
                cx=ax+dx*t+nx*rnd.uniform(-width*.24,width*.24)
                cy=ay+dy*t+ny*rnd.uniform(-width*.24,width*.24)
                delta=rnd.uniform(3,18)
                stroke(((cx,cy),(cx+dx/length*delta+nx*rnd.uniform(-3,3),
                                 cy+dy/length*delta+ny*rnd.uniform(-3,3))),
                       rnd.choice(((10,16,15,176),(112,107,80,108),(33,42,33,200))),
                       rnd.uniform(1,3))
        for j,(x,y) in enumerate(vertices[1:-1]):
            poly(((x-width*.34,y-4),(x-width*.14,y-width*.43),
                  (x+width*.29,y-width*.28),(x+width*.48,y+width*.20),
                  (x+width*.07,y+width*.41),(x-width*.38,y+width*.28)),tissue)
            stroke(((x-width*.34,y-width*.2),(x+width*.14,y+width*.22),
                    (x+width*.25,y+width*.05)),(8,16,15,180),4)
            stroke(((x-width*.24,y-width*.31),(x-width*.12,y-width*.37)),skin,2)
    ellipse(190,497,142,13,(0,0,0,58))
    off = stride * 18
    left_leg = [(168,291+crouch),(146-off,385+crouch),(127+off,463),(112+off,499)]
    right_leg = [(222,292+crouch),(251+off,377+crouch),(234-off,459),(250-off,500)]
    bonechain(left_leg,31)
    bonechain(right_leg,30)
    for root_leg in (left_leg,right_leg):
        x,y=root_leg[-1]
        poly(((x-15,y-3),(x+17,y-4),(x+27,y+7),(x-23,y+9)),fabric)
        for i in range(3):
            stroke(((x-9+i*10,y+3),(x-14+i*10,y+9)),(104,105,80,121),2)
    left_arm=[(132,183+crouch),(91-off*.3,279+crouch),(67-off,374),(54-off,431)]
    right_arm=[(247,177+crouch),(301+off*.4,261+crouch),(314+off,369),(342+off,430)]
    bonechain(left_arm,22)
    bonechain(right_arm,24)
    for arm,side in ((left_arm,-1),(right_arm,1)):
        x,y=arm[-1]
        ellipse(x,y,11,14,skin)
        for finger in range(4):
            dx=side*(8+finger*9)
            bend = (finger-2)*3
            stroke(((x+finger*3*side,y),(x+dx,y+19+bend),(x+dx+side*9,y+36+finger*4)),dark,8-finger)
            stroke(((x+finger*3*side-2,y),(x+dx-2,y+18+bend),(x+dx+side*9,y+36+finger*4)),bone,2)
    poly(((135,153+crouch),(169,140+crouch),(205,144+crouch),(245,153+crouch),
          (265,197+crouch),(241,245+crouch),(234,297+crouch),(220,326+crouch),
          (185,317+crouch),(160,326+crouch),(150,292+crouch),(125,231+crouch)),dark)
    poly(((148,158+crouch),(174,148+crouch),(232,156+crouch),(244,191+crouch),
          (221,277+crouch),(218,303+crouch),(167,309+crouch),(143,222+crouch)),fabric)
    poly(((169,154+crouch),(181,169+crouch),(175,258+crouch),(169,302+crouch),
          (155,271+crouch),(156,203+crouch)),tissue)
    poly(((220,163+crouch),(231,181+crouch),(221,275+crouch),(211,296+crouch),
          (217,229+crouch)),tissue)
    for rib in range(8):
        yy=181+crouch+rib*14
        spread=33-rib*1.4
        bias=rnd.uniform(-7,6)
        stroke(((196-spread,yy+rnd.uniform(-5,1)),(177+bias,yy+5),
                (199+bias*.3,yy+9)),(13,19,18,208),4)
        stroke(((201+rnd.uniform(-4,5),yy+8),(196+spread,yy+rnd.uniform(-6,1))),
               (12,18,17,190),4)
        stroke(((196-spread+3,yy-5),(179+bias,yy+2)),bone,2)
        if rib%3!=1:
            stroke(((211,yy+4),(196+spread-5,yy-6)),(92,91,71,164),2)
        if rib%2:
            stroke(((195+spread-5,yy-7),(191+spread,yy+3)),(35,43,35,150),3)
    stroke(((197,165+crouch),(196,289+crouch),(190,314+crouch)),(4,9,9,225),8)
    stroke(((201,175+crouch),(201,278+crouch)),(95,95,74,145),2)
    for side in (-1,1):
        x=196+side*44
        for i in range(7):
            yy=205+crouch+i*15
            stroke(((x+side*(i%3)*3,yy),(x-side*5,yy+10),(x+side*7,yy+23)),
                   (68,77,63,103),2)
    head_x=193+tilt
    head_y=94+crouch
    poly(((head_x-35,head_y-48),(head_x-13,head_y-61),(head_x+22,head_y-57),
          (head_x+40,head_y-34),(head_x+40,head_y+21),(head_x+26,head_y+55),
          (head_x+11,head_y+72),(head_x-22,head_y+59),(head_x-42,head_y+25)),dark)
    poly(((head_x-27,head_y-51),(head_x-10,head_y-57),(head_x+23,head_y-46),
          (head_x+31,head_y-17),(head_x+24,head_y+35),(head_x+7,head_y+62),
          (head_x-17,head_y+46),(head_x-31,head_y+2)),tissue)
    ellipse(head_x-4,head_y-12,27,43,(55,62,52,152) if not ghost else (92,113,103,100))
    poly(((head_x-28,head_y-26),(head_x-12,head_y-41),(head_x-7,head_y+22),
          (head_x-18,head_y+48),(head_x-30,head_y+2)),(102,98,75,128))
    stroke(((head_x+18,head_y-36),(head_x+31,head_y+4),(head_x+16,head_y+44)),(10,17,16,185),10)
    for ex,ey,rx,ry in ((-16,-8,11,8),(17,-4,8,11)):
        ellipse(head_x+ex,head_y+ey,rx,ry,(3,8,8,251))
        ellipse(head_x+ex-3,head_y+ey-3,rx*.3,ry*.25,(36,50,42,230))
    stroke(((head_x+2,head_y-10),(head_x-1,head_y+19),(head_x+6,head_y+28)),(8,15,13,247),6)
    ellipse(head_x+4,head_y+39,13,14,(3,6,7,248))
    for tooth in range(4):
        tx=head_x-5+tooth*5
        stroke(((tx,head_y+33),(tx+rnd.randrange(-1,2),head_y+36+rnd.randrange(1,6))),
               (91,93,74,134),2)
    for _ in range(80):
        xx=rnd.uniform(144,240)
        yy=rnd.uniform(163+crouch,307+crouch)
        if abs(xx-194)<45:
            width=rnd.randrange(1,4)
            stroke(((xx,yy),(xx+rnd.uniform(-6,6),yy+rnd.randrange(3,13))),
                   rnd.choice(((4,12,11,133),(118,107,78,80),(80,82,69,101))),width)
    for _ in range(110):
        xx = rnd.uniform(head_x-25,head_x+25)
        yy = rnd.uniform(head_y-36,head_y+35)
        if ((xx-head_x)/29)**2+((yy-head_y)/47)**2 < 1.:
            ellipse(xx,yy,rnd.uniform(.5,1.7),rnd.uniform(.5,2.0),
                    (3,9,9,rnd.randrange(70,180)))
    for _ in range(26):
        sx = rnd.choice((head_x-25, head_x+30, 151, 240))
        sy = rnd.uniform(head_y+5,head_y+67) if sx in (head_x-25,head_x+30) else rnd.uniform(180+crouch,270+crouch)
        stroke(((sx,sy),(sx+rnd.uniform(-9,9),sy+rnd.uniform(25,62)),
                (sx+rnd.uniform(-17,17),sy+rnd.uniform(62,108))),
               (19,27,24,rnd.randrange(95,180)),rnd.uniform(1,3))
    if name == 'creature_lurk':
        stroke(((head_x-23,head_y-26),(head_x+11,head_y-21)),(172,170,122,50),3)
    if ghost:
        canvas.fill((255,255,255,160),special_flags=pygame.BLEND_RGBA_MULT)
    return pygame.transform.smoothscale(canvas,(w,h))


def _sprite(name, seed):
    rnd = random.Random(seed ^ sum((i + 1) * ord(char) for i, char in enumerate(name)))
    w, h = 160, 224
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    if name in ('creature', 'creature_stride', 'creature_lurk', 'creature_still', 'apparition'):
        return _creature(name, seed)
    if name in ('false_door', 'exit'):
        pygame.draw.rect(surf, (7, 13, 12, 246), (27, 21, 109, 194))
        _metal(surf, (30, 21, 104, 194), (64, 64, 53))
        pygame.draw.rect(surf, (10, 13, 14, 255), (45, 35, 74, 173))
        for y in range(42, 196, 13):
            pygame.draw.line(surf, (21, 24, 21, 180), (48, y), (115, y))
        pygame.draw.circle(surf, (137, 124, 85) if name == 'exit' else (65, 65, 57), (106, 132), 6)
        if name == 'exit':
            pygame.draw.rect(surf, (178, 140, 60), (53, 46, 56, 17), border_radius=2)
            pygame.draw.rect(surf, (22, 34, 27), (57, 50, 48, 9))
    elif name in ('chair', 'sign', 'pipe'):
        if name == 'chair':
            _metal(surf, (43, 54, 74, 91), (70, 66, 54))
            pygame.draw.rect(surf, (80, 68, 44), (38, 131, 88, 19), border_radius=5)
            for x in (47, 115):
                _stroke(surf, (x, 144), (x - 6, 213), (41, 42, 36), 6)
        elif name == 'pipe':
            for i in range(3):
                _stroke(surf, (51 + i * 24, 12), (51 + i * 24, 207), (50 + i * 9, 56 + i * 6, 54 + i * 6), 13)
                _stroke(surf, (47 + i * 24, 12), (47 + i * 24, 207), (147, 140, 109), 2)
            for y in (45, 149):
                pygame.draw.rect(surf, (48, 47, 39), (32, y, 92, 14))
        else:
            _metal(surf, (15, 63, 133, 75), (76, 76, 64))
            for y in (86, 104, 122):
                _stroke(surf, (33, y), (124, y), (162, 152, 114), 3)
    elif name == 'light':
        halo = pygame.Surface((w, h), pygame.SRCALPHA)
        for r in range(67, 7, -4):
            alpha = max(1, int(5 + 14 * (1 - r / 67)))
            pygame.draw.ellipse(halo, (219, 208, 144, alpha), (80 - r, 37 - r // 4, r * 2, max(8, r // 2)))
        surf.blit(halo, (0, 0))
        pygame.draw.rect(surf, (82, 78, 61, 255), (25, 23, 112, 24))
        pygame.draw.rect(surf, (220, 210, 160, 255), (31, 26, 100, 13))
        pygame.draw.line(surf, (251, 245, 205, 255), (37, 29), (122, 29), 3)
    else:
        pygame.draw.ellipse(surf, (7, 13, 12, 42), (40, 183, 83, 17))
        if name in ('cell', 'fragment'):
            _metal(surf, (54, 83, 52, 74), (88, 83, 66))
            for y in (100, 121, 141):
                pygame.draw.line(surf, (35, 36, 33), (60, y), (101, y), 4)
            pygame.draw.rect(surf, (154, 157, 105) if name == 'cell' else (112, 143, 127), (67, 91, 25, 8))
        elif name == 'echo':
            for i in range(7):
                radius = 11 + i * 9
                pygame.draw.arc(surf, (127, 145, 114, max(15, 160 - i * 23)),
                                (80 - radius, 124 - radius, radius * 2, radius * 2), .5, 4.7, 2)
            pygame.draw.circle(surf, (177, 183, 147, 230), (80, 124), 6)
        elif name == 'relay':
            _metal(surf, (29, 60, 103, 133), (71, 71, 65))
            pygame.draw.rect(surf, (26, 41, 37), (47, 86, 65, 35))
            for y in range(90, 116, 5):
                pygame.draw.line(surf, (95, 146, 115), (53, y), (103, y + rnd.randrange(-3, 3)), 1)
            for x in range(44, 112, 12):
                pygame.draw.circle(surf, (169, 160, 110), (x, 148), 3)
        elif name == 'note':
            pygame.draw.polygon(surf, (172, 156, 115), [(45, 58), (126, 66), (119, 176), (33, 168)])
            for y in range(79, 161, 11):
                pygame.draw.line(surf, (68, 72, 60), (51, y), (112 - rnd.randrange(0, 23), y + 3), 1)
    return surf


@functools.lru_cache(maxsize=48)
def art(name, seed=0):
    if name in WALL_NAMES:
        return _wall(WALL_NAMES.index(name), seed + 308)
    if name in SPRITE_NAMES:
        return _sprite(name, seed + 112)
    if name == 'icon':
        surf = pygame.Surface((64, 64), pygame.SRCALPHA)
        pygame.draw.rect(surf, (19, 23, 19), (3, 3, 58, 58), border_radius=3)
        pygame.draw.rect(surf, (153, 140, 89), (11, 13, 42, 42), 3)
        pygame.draw.line(surf, (183, 170, 111), (19, 25), (48, 25), 4)
        pygame.draw.line(surf, (97, 110, 82), (19, 36), (42, 36), 4)
        return surf
    if name in ('mask_on', 'mask_danger'):
        surf = pygame.Surface((256, 256), pygame.SRCALPHA)
        for radius in range(128, 4, -4):
            amount = max(0., min(110, int(120 * (radius / 128) ** 3)))
            pygame.draw.circle(surf, (4, 9, 8, amount if name == 'mask_on' else amount // 2), (128, 128), radius, 4)
        return surf
    raise KeyError(name)
