from array import array
import math
import random
import sys


SAMPLE_RATE = 22050
CONTINUOUS = ('ambience', 'drone', 'roomtone', 'tape_hiss')
DURATIONS = {'ambience': 4.25, 'drone': 4.25, 'roomtone': 4.25, 'tape_hiss': 4.25,
             'breath': 1.55, 'whisper': 1.15, 'distant_steps': 1.3,
             'stinger': 1.35, 'door': 1.1, 'duct': 1.4, 'metal_creak': 1.15,
             'reload': .65, 'skill_echo': .89, 'radio_distortion': .68,
             'skill_cloak': .57, 'skill_pulse': .66, 'skill_listen': .48,
             'shot_flare': .49, 'shot_emitter': .44, 'shot': .42, 'melee': .36,
             'knock': .45, 'pickup': .32, 'click': .16, 'heartbeat': .40,
             'step': .29}


def pcm(name, seed=0, sample_rate=SAMPLE_RATE):
    rng = random.Random(seed * 3571 + sum((i + 7) * ord(c) for i, c in enumerate(name)))
    seconds = DURATIONS.get(name, .5)
    length = max(1024, int(seconds * sample_rate))
    data = array('h')
    loop = name in CONTINUOUS
    low = 0.
    upper = 0.
    slow = 0.
    tau = math.tau
    for i in range(length):
        t = i / sample_rate
        u = i / length
        random_value = rng.random() * 2. - 1.
        low += (random_value - low) * .036
        upper += (random_value - upper) * .16
        slow += (random_value - slow) * .004
        noise = .63 * low + .3 * upper + .08 * random_value
        rise = min(1., t / .035)
        fall = max(0., 1. - u)
        envelope = rise * (fall ** 1.4)
        component = 0.
        if loop:
            edge = max(0., min(1., u * 45., (1. - u) * 45.))
            if name == 'ambience':
                hum = math.sin(tau * 120 * t) * .14 + math.sin(tau * 60 * t) * .09
                component = (noise * .60 + hum + slow * 1.6) * (.90 + .10 * math.sin(tau * u * 2))
            elif name == 'drone':
                component = (math.sin(tau * 5 * u) * .14 + math.sin(tau * 17 * u) * .10 +
                             math.sin(tau * 29 * u) * .055 + low * .55) * .85
            elif name == 'roomtone':
                component = noise * .48 + math.sin(tau * 7 * u) * .018
            else:
                component = (random_value * .15 + upper * .16) * .75
            component *= edge
        elif name in ('step', 'distant_steps', 'heartbeat', 'knock'):
            pulses = (0., .55, .78) if name == 'distant_steps' else (0., .42) if name == 'heartbeat' else (0., .52) if name == 'knock' else (0.,)
            thumps = 0.
            for p in pulses:
                v = max(0., t - p * seconds)
                if v < .26:
                    thumps += math.exp(-v * (18. if name != 'heartbeat' else 12.)) * math.sin(tau * (87. - v * 78.) * v)
            component = thumps * (.7 if name == 'heartbeat' else .65) + noise * (.5 if name == 'distant_steps' else .30) * envelope
        elif name in ('shot', 'shot_emitter', 'shot_flare', 'melee', 'stinger'):
            if name in ('shot_emitter', 'shot'):
                frequency = 870. * math.exp(-t * 8.) + 67.
                component = math.sin(tau * (87. * t + 85. * (1. - math.exp(-t * 8.)))) * .40
                component += math.sin(tau * frequency * t) * .23 + noise * .83
                component *= math.exp(-t * 8.5)
            elif name == 'shot_flare':
                component = (.95 * random_value + .60 * math.sin(tau * (91. - 45 * t) * t) + noise * .75) * math.exp(-t * 13.)
                component += .13 * math.sin(tau * 73. * t) * math.exp(-t * 4.)
            elif name == 'melee':
                component = (noise * .85 + math.sin(tau * (230. - 130 * t) * t) * .3) * math.exp(-t * 9.)
            else:
                component = (math.sin(tau * 43 * t) * .35 +
                             math.sin(tau * 46.2 * t) * .21 + noise * .34) * envelope
        elif name in ('ambience', 'breath', 'whisper', 'duct', 'metal_creak', 'door'):
            vowel = math.sin(tau * (135. + 15. * math.sin(t * 3.)) * t) * .15
            creak = math.sin(tau * (55. + 210. * t + 90 * math.sin(t * 10.)) * t) * .25
            if name == 'breath':
                component = noise * .95 * math.sin(math.pi * u) ** 2
            elif name == 'whisper':
                component = (noise * .8 + vowel * .35) * math.sin(math.pi * u) ** 2
            elif name == 'door':
                component = (creak * .72 + noise * .38) * envelope
            elif name == 'metal_creak':
                component = (creak + math.sin(tau * 422 * t) * .04 + noise * .23) * envelope
            else:
                component = (noise * .8 + creak * .13) * envelope
        elif name in ('click', 'pickup', 'reload', 'radio_distortion', 'skill_listen', 'skill_pulse', 'skill_cloak', 'skill_echo'):
            frequency = (530. if name == 'pickup' else 244. if name == 'reload' else 176. if name == 'click' else 350.)
            sweep = frequency * (1. + .5 * math.sin(u * math.pi))
            tone = .45 * math.sin(tau * sweep * t) + .16 * math.sin(tau * sweep * 1.98 * t)
            if name == 'reload':
                knocks = (math.exp(-max(0., t - .1) * 27.) if t > .1 else 0.) + (math.exp(-max(0., t - .37) * 30.) if t > .37 else 0.)
                component = (knocks * (noise * .72 + math.sin(tau * 145 * t) * .3)) * envelope
            elif name == 'click':
                component = (noise + tone * .28) * math.exp(-t * 49.)
            elif name == 'radio_distortion':
                component = (tone * .48 + random_value * (1. if int(t * 23) % 4 else .07) * .36) * envelope
            else:
                component = (tone + noise * .23) * envelope
        else:
            component = noise * envelope
        component = max(-1., min(1., component * .55))
        left = int(max(-32767, min(32767, component * 32767 * (.97 + .03 * math.sin(t * .31)))))
        right = int(max(-32767, min(32767, component * 32767 * (.95 + .05 * math.cos(t * .23)))))
        data.append(left)
        data.append(right)
    if sys.byteorder != 'little':
        data.byteswap()
    return data.tobytes()
