import collections
import math
import random

from config import (HORROR_COOLDOWN, HORROR_EVENT_LENGTH, HORROR_INITIAL_DELAY,
                    HORROR_MAX_VISITS, HORROR_MIN_PROGRESS, HORROR_SILENCE_GRACE,
                    HORROR_VIEW_DISTANCE, HORROR_AFTERSHOCK)


class HorrorDirector:
    EVENT_KINDS = frozenset(('steps', 'knock', 'whisper', 'figure', 'door', 'flicker',
                             'silence', 'mimic', 'watch', 'loop', 'breath', 'blackout',
                             'reflection', 'replay', 'presence', 'rift'))
    def __init__(self, seed):
        self.rng = random.Random(seed ^ 0x65A3CF)
        self.cooldown = self.rng.uniform(HORROR_INITIAL_DELAY * .8, HORROR_INITIAL_DELAY * 1.3)
        self.duration = 0.
        self.kind = ''
        self.tension = .10
        self.ghost = None
        self.false_door = None
        self.sound_point = None
        self.visits = {}
        self.last_tile = None
        self.last_kind = ''
        self.recent = collections.deque(maxlen=5)
        self.event_count = 0
        self.flicker = 0.
        self.blackout = 0.
        self.warp = 0.
        self.shiver = 0.
        self.ghost_seen = 0.
        self.grace = 0.
        self.stillness = 0.
        self.trail = 0
        self.phase = 'DORMANT'
        self.turn_pressure = 0.
        self.aftershock = 0.
        self.interruption = 0.
        self.last_seen_at = None
        self.intensity = 1.
        self.preference = {}
        self.memory_mutations = 0

    def _candidate(self, game, in_front=None, minimum=None, maximum=None):
        minimum = HORROR_VIEW_DISTANCE[0] if minimum is None else minimum
        maximum = HORROR_VIEW_DISTANCE[1] if maximum is None else maximum
        chosen = []
        for attempt in range(48):
            angle = game.angle + self.rng.uniform(-1.1, 1.1) + (math.pi if in_front is False else 0.)
            distance = self.rng.uniform(minimum, maximum)
            x = game.x + math.cos(angle) * distance
            y = game.y + math.sin(angle) * distance
            if not game.world.can_move(x, y, .14):
                continue
            if not game.world.visible(game.x, game.y, x, y):
                continue
            if game.enemy_active and math.hypot(x - game.enemy_x, y - game.enemy_y) < 2.:
                continue
            chosen.append((x, y))
            if len(chosen) >= 4:
                break
        return self.rng.choice(chosen) if chosen else None

    def _wall_candidate(self, game):
        for _ in range(12):
            point = self._candidate(game, True, 2.6, 9.)
            if point is None:
                return None
            x, y = int(point[0]), int(point[1])
            neighbors = ((x + 1, y, x + .96, y + .5), (x - 1, y, x + .04, y + .5),
                         (x, y + 1, x + .5, y + .96), (x, y - 1, x + .5, y + .04))
            walls = [(px, py) for ix, iy, px, py in neighbors
                     if not game.world.is_floor(ix + .5, iy + .5)
                     and game.world.visible(game.x, game.y, px, py)]
            if walls:
                return self.rng.choice(walls)
        return None

    def _source(self, game, behind=False):
        point = self._candidate(game, False if behind else self.rng.random() < .40, 1.8, 10.)
        if point:
            return point
        angle = game.angle + math.pi + self.rng.uniform(-.40, .40)
        return game.x + 2.3 * math.cos(angle), game.y + 2.3 * math.sin(angle)

    def _begin(self, game):
        overdue = max(0., game.elapsed - game.last_progress - HORROR_MIN_PROGRESS)
        revisited = self.visits.get((int(game.x), int(game.y)), 0) > 1
        weights = {'steps': 5, 'knock': 4, 'whisper': 3, 'figure': 5,
                   'door': 2, 'flicker': 2, 'silence': 2, 'mimic': 3,
                   'watch': 4, 'loop': 3, 'breath': 3, 'blackout': 2,
                   'reflection': 3, 'replay': 3, 'presence': 2, 'rift': 2}
        if game.behavior.get('shots', 0) > 3:
            weights['silence'] += 4
            weights['replay'] += 2
            weights['watch'] += 3
        if game.behavior.get('stealth_seconds', 0) > 15:
            weights['mimic'] += 5
            weights['breath'] += 2
        if self.preference.get('shots', 0) > self.preference.get('stealth_seconds', 0) * .7:
            weights['watch'] += 3
            weights['reflection'] += 2
        if self.preference.get('revisits', 0) > 25:
            weights['loop'] += 4
            weights['door'] += 2
        if game.world.imprints:
            weights['replay'] += min(7, len(game.world.imprints) // 8)
        if self.stillness > 4.:
            weights['watch'] += 7
            weights['breath'] += 5
        if revisited or self.trail > 7:
            weights['loop'] += 6
            weights['door'] += 3
            weights['replay'] += 4
            weights['rift'] += 2
        if overdue > 45.:
            weights['figure'] += 5
        if self.turn_pressure > .6:
            weights['watch'] += 4
            weights['reflection'] += 4
        if game.enemy_distance < 7.:
            weights['figure'] = 0
            weights['blackout'] = 0
            weights['mimic'] += 2
            weights['presence'] += 3
        if game.elapsed < 28.:
            weights['blackout'] = 0
            weights['door'] += 2
            weights['figure'] += 4
            weights['reflection'] = 0
            weights['rift'] = 0
        options = [(name, weight / (1. + self.recent.count(name) * 3.5))
                   for name, weight in weights.items() if name != self.last_kind and weight > 0]
        self.kind = self.rng.choices([name for name, _ in options], [weight for _, weight in options])[0]
        self.last_kind = self.kind
        self.recent.append(self.kind)
        self.event_count += 1
        self.duration = self.rng.uniform(*HORROR_EVENT_LENGTH)
        self.shiver = self.rng.uniform(.17, .55)
        self.ghost = None
        self.false_door = None
        self.sound_point = None
        event = {'type': 'horror', 'kind': self.kind}
        if self.kind in ('figure', 'watch', 'reflection'):
            self.ghost = self._candidate(game, self.kind == 'figure', 2.6 if self.kind == 'watch' else 4., 11.)
            self.duration = self.rng.uniform(3.4, 6.0)
            self.sound_point = self.ghost or self._source(game, self.kind == 'watch')
            event['sound'] = 'breath' if self.kind == 'figure' else None
            if self.kind == 'reflection':
                self.duration = self.rng.uniform(2.8, 5.2)
                self.warp = max(self.warp, .45)
        elif self.kind in ('door', 'loop', 'replay'):
            self.false_door = self._wall_candidate(game)
            self.warp = max(self.warp, .7 if self.kind in ('loop', 'replay') else .25)
            self.duration = self.rng.uniform(4.0, 7.0)
            self.sound_point = self.false_door or self._source(game)
            event['sound'] = ('whisper' if self.kind == 'replay' else 'door') if self.false_door else 'knock'
        elif self.kind == 'rift':
            point = game.world.open_rift_near(game.x, game.y, game.angle)
            self.duration = self.rng.uniform(5., 9.)
            self.warp = max(self.warp, .95)
            self.sound_point = point or self._source(game)
            event['sound'] = 'door' if point else 'knock'
        elif self.kind in ('flicker', 'blackout'):
            self.flicker = 1.
            self.blackout = 1. if self.kind == 'blackout' else 0.
            self.duration = 3.8 if self.kind == 'blackout' else 2.0
            self.sound_point = self._source(game)
            event['sound'] = 'duct'
        elif self.kind == 'silence':
            self.duration = self.rng.uniform(3.8, 6.5)
            event['sound'] = None
        elif self.kind == 'presence':
            self.sound_point = self._source(game, True)
            self.duration = self.rng.uniform(2.6, 5.4)
            event['sound'] = 'breath'
        else:
            names = {'steps': 'distant_steps', 'knock': 'knock', 'whisper': 'whisper',
                     'mimic': 'distant_steps', 'breath': 'breath'}
            event['sound'] = names[self.kind]
            self.sound_point = self._source(game, self.kind in ('mimic', 'breath'))
            if self.kind == 'mimic':
                self.duration = self.rng.uniform(5.0, 8.5)
        if self.sound_point:
            event['position'] = self.sound_point
        event['intensity'] = .26 if self.kind in ('figure', 'watch', 'breath') else .38
        return event

    def update(self, game, dt):
        cell = (int(game.x), int(game.y))
        if cell != self.last_tile:
            previous = self.visits.get(cell, 0)
            self.visits[cell] = min(HORROR_MAX_VISITS, previous + 1)
            self.trail += 1 if previous == 0 else 2
            self.last_tile = cell
            self.stillness = 0.
            if game.world.remember(cell, self.visits[cell]):
                self.memory_mutations += 1
                self.warp = max(self.warp, .18)
        else:
            self.stillness = min(30., self.stillness + dt if game.move_amount < .08 else max(0., self.stillness - dt * 2.))
        self.turn_pressure = max(0., min(2., self.turn_pressure * max(0., 1. - dt * .6)
                                          + game.turn_amount * .45))
        self.cooldown -= dt
        self.duration = max(0., self.duration - dt)
        self.grace = max(0., self.grace - dt)
        self.flicker = max(0., self.flicker - dt * .26)
        self.blackout = max(0., min(1., self.blackout - dt * .23))
        self.warp = max(0., self.warp - dt * .075)
        self.shiver = max(0., self.shiver - dt * .32)
        self.aftershock = max(0., self.aftershock - dt)
        self.interruption = max(0., self.interruption - dt)
        if self.ghost and self.duration > 0:
            dx, dy = self.ghost[0] - game.x, self.ghost[1] - game.y
            delta = (math.atan2(dy, dx) - game.angle + math.pi) % (2 * math.pi) - math.pi
            if abs(delta) < .17 and game.world.visible(game.x, game.y, *self.ghost):
                self.ghost_seen += dt
                if self.ghost_seen > .75:
                    self.duration = min(self.duration, .65)
            else:
                self.ghost_seen = max(0., self.ghost_seen - dt * 1.6)
        else:
            self.ghost_seen = 0.
        if self.duration <= 0.:
            self.ghost = None
            self.false_door = None
            self.kind = ''
        proximity = max(0., min(1., (12. - game.enemy_distance) / 12.)) if game.enemy_active else 0.
        memory = min(.21, sum(1 for visit in self.visits.values() if visit > 1) * .008)
        target = (.10 + memory + proximity * .55 + min(.22, self.stillness * .011)
                  + (1. - game.sanity / 100.) * .27 + (.23 if self.duration > 0. else 0.))
        self.tension += (min(1., target) - self.tension) * min(1., dt * 1.15)
        self.phase = ('CHASE' if game.enemy_state == 'CHASE' and game.enemy_distance < 11. else
                      'AFTERSHOCK' if self.aftershock > 0. else
                      'APPROACH' if game.enemy_distance < 9. or self.tension > .72 else
                      'ANOMALY' if self.duration > 0. or self.tension > .47 else
                      'DOUBT' if self.stillness > 4. or self.trail > 12 else
                      'CALM')
        if (self.cooldown > 0. or self.duration > 0. or self.grace > 0.
                or game.elapsed < HORROR_INITIAL_DELAY * .70 or game.won):
            return []
        event = self._begin(game)
        interval = self.rng.uniform(*HORROR_COOLDOWN) / (max(.5, self.intensity) * (1. + self.tension * .35))
        if self.event_count and self.event_count % 5 == 0:
            self.aftershock = max(self.aftershock, self.rng.uniform(12., 25.))
            interval = max(interval, self.aftershock)
        if self.kind in ('silence', 'reflection', 'replay'):
            self.aftershock = self.rng.uniform(*HORROR_AFTERSHOCK)
            self.cooldown = max(interval, self.aftershock) + self.duration * .45
        else:
            self.cooldown = interval + self.duration * .45
        if self.kind == 'silence':
            self.grace = HORROR_SILENCE_GRACE
        return [event]

    @property
    def ghost_alpha(self):
        if not self.ghost:
            return 0.
        return max(0., min(.84, self.duration / 1.2))

    def diagnostics(self):
        return {'events': self.event_count, 'phase': self.phase, 'last_event': self.last_kind,
                'tension': round(self.tension, 2), 'visited_tiles': len(self.visits),
                'revisited_tiles': sum(1 for value in self.visits.values() if value > 1),
                'aftershock': round(self.aftershock, 1), 'memory_mutations': self.memory_mutations,
                'recent': list(self.recent)}
