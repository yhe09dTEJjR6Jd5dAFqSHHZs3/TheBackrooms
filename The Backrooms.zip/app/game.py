import math
import random
import time

from world import OBJECTIVES, SIZE, World, ZONE_NAMES

from config import (AUTO_PICKUP_RADIUS, AUTO_PICKUP_SECONDS, CROUCH_MULTIPLIER, GUIDANCE_DELAY,
                    JUMP_DURATION, PLAYER_SPEED, SAFE_GRACE, SKILL_COOLDOWNS,
                    SPRINT_MULTIPLIER, WEAPON_CAPACITY, WEAPON_RELOAD, STALKER_AWAKEN_SECONDS,
                    STALKER_CHASE_SPEED, STALKER_WANDER_SPEED, STALKER_APPROACH_TILES,
                    WORLD_GENERATION, SAVE_SCHEMA, MISSION_SURVEY_TILES,
                    MISSION_CALIBRATION_REGIONS, MISSION_ECHOES_REQUIRED,
                    NOISE_EVENT_LIMIT, NOISE_EVENT_DURATION)
from horror import HorrorDirector


def clamp(value, minimum, maximum):
    try:
        result = float(value)
        return max(minimum, min(maximum, result)) if math.isfinite(result) else maximum
    except (ValueError, TypeError):
        return minimum


DAILY_RULES = ('无声协议', '共振协议', '警戒协议', '复原协议')

MISSION_NAMES = {'TAPES': '常规录音回收', 'ECHO': '异常旁证', 'SURVEY': '重复测绘',
                 'SIGNAL': '多区信号校准', 'MIXED': '不一致证词'}


def save_rng(rng):
    return list(rng.getstate()[1])


def restore_rng(rng, values):
    if (isinstance(values, list) and len(values) == 625 and
            all(type(v) is int and 0 <= v <= 0xffffffff for v in values[:624]) and
            type(values[624]) is int and 0 <= values[624] <= 624):
        try:
            rng.setstate((3, tuple(values), None))
        except (ValueError, TypeError):
            pass


def valid_point(value):
    if (isinstance(value, (list, tuple)) and len(value) == 2 and
            all(type(v) in (int, float) and math.isfinite(v) for v in value) and
            all(-1. <= v <= SIZE + 1. for v in value)):
        return tuple(float(v) for v in value)
    return None


class Game:
    def __init__(self, seed=None, saved=None, depth=0):
        if isinstance(saved, dict) and type(saved.get('seed')) is int:
            seed = saved['seed']
        self.seed = int(seed if seed is not None else time.time_ns() % 2_147_483_647) & 0x7fffffff
        if isinstance(saved, dict):
            depth = saved.get('depth', 0)
        self.depth = max(0, min(999999, depth)) if type(depth) is int else 0
        self.world_version = (int(saved.get('world_version', 1))
                              if isinstance(saved, dict) else WORLD_GENERATION)
        if self.world_version not in (1, 2, 3, WORLD_GENERATION):
            self.world_version = 1
        self.world = World(self.seed, generation=self.world_version, depth=self.depth)
        self.mode = 'DAILY' if isinstance(saved, dict) and saved.get('mode') == 'DAILY' else 'FREE'
        self.investigation = ('记忆断层', '信号搜寻', '未署名档案', '重复测绘')[(self.seed + self.depth) % 4]
        self.mission = ('TAPES', 'ECHO', 'SURVEY', 'SIGNAL', 'MIXED')[(self.seed // 7 + self.depth * 2) % 5] if self.world_version >= 3 else 'TAPES'
        self.calibrated_regions = set()
        self.mission_notified = False
        self.enemy_behavior = ('WATCHER', 'LISTENER', 'DRIFTER')[self.seed % 3]
        self.echoes = set()
        self.evidence = set()
        self.relays = set()
        self.total_fragments = OBJECTIVES
        self.x, self.y = self.world.spawn
        self.angle = self.world.spawn_angle()
        self.pitch = 0.
        self.flash_on = True
        self.battery = 98.
        self.stamina = 100.
        self.sanity = 100.
        self.fragments = 0
        self.collected = set()
        self.seen = set()
        self._last_explored = None
        self.elapsed = 0.
        self.walk_phase = 0.
        self.move_amount = 0.
        self.turn_amount = 0.
        self.hud_awake = 11.
        self.step_clock = 0.
        self.enemy_x, self.enemy_y = self.world.enemy_spawn
        self.enemy_active = False
        self.enemy_distance = 1000.
        self.enemy_timer = 0.
        self.enemy_path = []
        self.enemy_notice = False
        self.enemy_stunned = 0.
        self.enemy_state = 'WANDER'
        self.enemy_investigate = None
        self.enemy_investigate_clock = 0.
        self.shadow_active = False
        self.shadow_x, self.shadow_y = self.world.enemy_spawn
        self.shadow_timer = 28. + self.seed % 23
        self.shadow_seen = 0.
        self.shadow_distance = 1000.
        self.shadow_moves = 0
        self.noise = 0.
        self.noise_events = []
        self.behavior = {'shots': 0, 'steps': 0, 'sprint_seconds': 0., 'stealth_seconds': 0., 'observations': 0}
        self.safe_grace = SAFE_GRACE
        self.checkpoint = (self.x, self.y)
        self.recoveries = 0
        self.near_item = None
        self.dead = False
        self.won = False
        self.ending = ''
        self.current_region = self.world.region(self.x, self.y)
        self.tutorial = 20.
        self.message = '听见了吗？荧光灯下总有另一个人的呼吸。'
        self.message_time = 6.
        self.last_progress = 0.
        self.last_hint = 0.
        self._signal_cache_key = None
        self._signal_cache = None
        self._random = random.Random(self.seed + 1)
        self.crouching = False
        self.aiming = False
        self.jump_clock = 0.
        self.jump_height = 0.
        self.weapon = 0
        self.ammo = [6, 12]
        self.reserve = [36, 48]
        self.reload_clock = 0.
        self.attack_clock = 0.
        self.tracers = []
        self.projectiles = []
        self.shot_flash = 0.
        self.impact_flash = 0.
        self.skill_cooldowns = [0.] * 4
        self.listen_clock = 0.
        self.cloak_clock = 0.
        self.echo_clock = 0.
        self.threat = 0.
        self.anomaly = 0.
        self.horror = HorrorDirector(self.seed)
        self.horror_intensity = 1.
        self.assist = True
        self.auto_pick_clock = 0.
        self.last_pickup = None
        self.target_lock = False
        self.listen_bearing = 0.
        self.listen_distance = 0.
        if saved:
            self._restore(saved)
        self.current_region = self.world.region(self.x, self.y)
        self._explore()
        self.near_item = self.world.nearest_interactable(self.x, self.y, self.collected, self.exit_ready)

    def _restore(self, saved):
        self.world.restore_passages(saved.get('passages'))
        self.world.restore_rift(saved.get('rift'))
        self.world.restore_imprints(saved.get('imprints'))
        position = (clamp(saved.get('x'), 1.05, SIZE - 1.05),
                    clamp(saved.get('y'), 1.05, SIZE - 1.05))
        if self.world.can_move(*position):
            self.x, self.y = position
        self.angle = clamp(saved.get('angle'), -100., 100.) % (2 * math.pi)
        self.pitch = clamp(saved.get('pitch', 0.), -.14, .14)
        self.flash_on = True
        self.battery = clamp(saved.get('battery'), 0., 100.)
        self.stamina = clamp(saved.get('stamina'), 0., 100.)
        self.sanity = clamp(saved.get('sanity'), 1., 100.)
        self.elapsed = clamp(saved.get('elapsed'), 0., 100000.)
        selected = saved.get('collected', [])
        valid = {item['id'] for item in self.world.items if item['kind'] == 'fragment'}
        self.collected = {item for item in selected if isinstance(item, str) and item in valid} if isinstance(selected, list) else set()
        self.fragments = len(self.collected)
        echoes = saved.get('echoes', [])
        valid_echoes = {item['id'] for item in self.world.items if item['kind'] == 'echo'}
        if isinstance(echoes, list):
            self.echoes = {value for value in echoes if isinstance(value, str) and value in valid_echoes}
        consumed = saved.get('consumed', [])
        consumed = {item for item in consumed if isinstance(item, str)} if isinstance(consumed, list) else set()
        for item in self.world.items:
            if item['id'] in self.collected or item['id'] in self.echoes or item['id'] in consumed:
                item['active'] = False
                if item['kind'] == 'note':
                    self.evidence.add(item['id'])
                elif item['kind'] == 'relay':
                    self.relays.add(item['id'])
        seen = saved.get('seen', [])
        if isinstance(seen, list):
            self.seen = {i for i in seen[:SIZE * SIZE] if type(i) is int and 0 <= i < SIZE * SIZE}
        self.enemy_active = saved.get('enemy_active') is True or self.fragments > 0
        ex = clamp(saved.get('enemy_x', self.world.enemy_spawn[0]), 1.05, SIZE - 1.05)
        ey = clamp(saved.get('enemy_y', self.world.enemy_spawn[1]), 1.05, SIZE - 1.05)
        if self.world.can_move(ex, ey):
            self.enemy_x, self.enemy_y = ex, ey
        self.weapon = int(clamp(saved.get('weapon', 0), 0, 1))
        for name, defaults, maximum in (('ammo', WEAPON_CAPACITY, WEAPON_CAPACITY),
                                        ('reserve', (36, 48), (120, 160))):
            values = saved.get(name)
            if isinstance(values, list) and len(values) == 2:
                setattr(self, name, [int(clamp(values[i], 0, maximum[i])) for i in range(2)])
            else:
                setattr(self, name, list(defaults))
        self.recoveries = int(clamp(saved.get('recoveries', 0), 0, 999))
        checkpoint = saved.get('checkpoint')
        if isinstance(checkpoint, (list, tuple)) and len(checkpoint) == 2:
            candidate = (clamp(checkpoint[0], 1.05, SIZE - 1.05), clamp(checkpoint[1], 1.05, SIZE - 1.05))
            if self.world.can_move(*candidate):
                self.checkpoint = candidate
        else:
            self.checkpoint = (self.x, self.y)
        self.safe_grace = SAFE_GRACE
        self.last_progress = clamp(saved.get('last_progress', self.elapsed), 0., self.elapsed)
        self.last_hint = clamp(saved.get('last_hint', self.elapsed), 0., self.elapsed)
        calibrated = saved.get('calibrated_regions', [])
        if isinstance(calibrated, list):
            self.calibrated_regions = {value for value in calibrated if type(value) is int and 0 <= value < len(ZONE_NAMES)}
        self.mission_notified = saved.get('mission_notified') is True
        behavior = saved.get('behavior', {})
        if isinstance(behavior, dict):
            for name in self.behavior:
                self.behavior[name] = clamp(behavior.get(name, 0), 0., 1_000_000.)
        self.skill_cooldowns = [clamp(value, 0., SKILL_COOLDOWNS[i]) for i, value in enumerate(saved.get('skill_cooldowns', []))] if isinstance(saved.get('skill_cooldowns'), list) and len(saved['skill_cooldowns']) == 4 else [0.] * 4
        for attr, maximum in (('reload_clock', max(WEAPON_RELOAD)), ('attack_clock', 2.),
                              ('listen_clock', 10.), ('cloak_clock', 9.), ('echo_clock', 13.),
                              ('jump_clock', JUMP_DURATION), ('enemy_stunned', 30.),
                              ('enemy_timer', 20.), ('enemy_investigate_clock', 15.),
                              ('shadow_timer', 90.), ('shadow_seen', 5.)):
            setattr(self, attr, clamp(saved.get(attr, getattr(self, attr)), 0., maximum))
        self.safe_grace = max(2.5, clamp(saved.get('safe_grace', SAFE_GRACE), 0., SAFE_GRACE))
        self.enemy_notice = saved.get('enemy_notice') is True
        self.enemy_state = saved.get('enemy_state') if saved.get('enemy_state') in ('WANDER', 'SEARCH', 'LISTEN', 'CHASE', 'OBSERVE') else 'WANDER'
        self.enemy_investigate = valid_point(saved.get('enemy_investigate'))
        self.shadow_active = saved.get('shadow_active') is True
        point = valid_point(saved.get('shadow_position'))
        if point and self.world.can_move(*point):
            self.shadow_x, self.shadow_y = point
        self.shadow_moves = int(clamp(saved.get('shadow_moves', 0), 0, 10000))
        audio = saved.get('noise_events', [])
        if isinstance(audio, list):
            for record in audio[:NOISE_EVENT_LIMIT]:
                if isinstance(record, (list, tuple)) and len(record) == 4:
                    point = valid_point(record[:2])
                    if point:
                        self.noise_events.append((point[0], point[1], clamp(record[2], 0., 28.),
                                                  clamp(record[3], 0., NOISE_EVENT_DURATION)))
        rng = saved.get('rng', {})
        if isinstance(rng, dict):
            for key, target in (('game', self._random), ('horror', self.horror.rng), ('world', self.world.random)):
                restore_rng(target, rng.get(key))
        self.tutorial = 0.
        self.message = '录音已连接。你仍在这里。'
        self.message_time = 4.
        memory = saved.get('horror_memory', {})
        if isinstance(memory, dict):
            visit_data = memory.get('visits', [])
            if isinstance(visit_data, list):
                for entry in visit_data[:SIZE * SIZE]:
                    if (isinstance(entry, list) and len(entry) == 3
                            and all(type(n) is int for n in entry)
                            and 0 <= entry[0] < SIZE and 0 <= entry[1] < SIZE):
                        self.horror.visits[(entry[0], entry[1])] = max(1, min(12, entry[2]))
            self.horror.event_count = int(clamp(memory.get('events', 0), 0, 1000000))
            self.horror.pattern_stage = int(clamp(memory.get('pattern_stage', 0), 0, 3))
            route = memory.get('path_memory', [])
            if isinstance(route, list):
                for pos in route[-64:]:
                    if (isinstance(pos, (list, tuple)) and len(pos) == 2 and
                            all(type(v) is int and 0 <= v < SIZE for v in pos)):
                        self.horror.path_memory.append(tuple(pos))
            self.horror.trail = int(clamp(memory.get('trail', 0), 0, 1000000))
            self.horror.cooldown = clamp(memory.get('cooldown', self.horror.cooldown), 0., 120.)
            self.horror.duration = clamp(memory.get('duration', 0.), 0., 20.)
            self.horror.grace = clamp(memory.get('grace', 0.), 0., 60.)
            self.horror.tension = clamp(memory.get('tension', self.horror.tension), 0., 1.)
            self.horror.aftershock = clamp(memory.get('aftershock', 0.), 0., 90.)
            self.horror.stillness = clamp(memory.get('stillness', 0.), 0., 30.)
            self.horror.flicker = clamp(memory.get('flicker', 0.), 0., 1.)
            self.horror.blackout = clamp(memory.get('blackout', 0.), 0., 1.)
            self.horror.warp = clamp(memory.get('warp', 0.), 0., 2.)
            self.horror.turn_pressure = clamp(memory.get('turn_pressure', 0.), 0., 2.)
            self.horror.shiver = clamp(memory.get('shiver', 0.), 0., 1.)
            self.horror.ghost_seen = clamp(memory.get('ghost_seen', 0.), 0., 5.)
            self.horror.ghost = valid_point(memory.get('ghost'))
            self.horror.false_door = valid_point(memory.get('false_door'))
            self.horror.sound_point = valid_point(memory.get('sound_point'))
            tile = memory.get('last_tile')
            if (isinstance(tile, list) and len(tile) == 2 and all(type(n) is int and 0 <= n < SIZE for n in tile)):
                self.horror.last_tile = tuple(tile)
            self.horror.kind = memory.get('kind') if isinstance(memory.get('kind'), str) and memory.get('kind') in self.horror.EVENT_KINDS else ''
            self.horror.last_kind = memory.get('last_kind') if isinstance(memory.get('last_kind'), str) and memory.get('last_kind') in self.horror.EVENT_KINDS else ''
            recent = memory.get('recent', [])
            if isinstance(recent, list):
                self.horror.recent.extend(value for value in recent[-5:] if isinstance(value, str) and len(value) < 24)
        self.horror.grace = max(3., self.horror.grace)
        self.shadow_timer = max(3., self.shadow_timer)


    def _explore(self):
        signature = (int(self.x * 2), int(self.y * 2))
        if self._last_explored == signature:
            return
        self._last_explored = signature
        x0, y0 = int(self.x), int(self.y)
        for dy in range(-5, 6):
            for dx in range(-5, 6):
                x, y = x0 + dx, y0 + dy
                if 0 <= x < SIZE and 0 <= y < SIZE and dx * dx + dy * dy <= 27:
                    if self.world.visible(self.x, self.y, x + .5, y + .5):
                        self.seen.add(y * SIZE + x)

    @property
    def daily_rule(self):
        return DAILY_RULES[(self.seed // 11) % len(DAILY_RULES)] if self.mode == 'DAILY' else ''

    def mission_progress(self):
        if self.mission == 'ECHO':
            return min(MISSION_ECHOES_REQUIRED, len(self.echoes)), MISSION_ECHOES_REQUIRED
        if self.mission == 'SURVEY':
            return min(MISSION_SURVEY_TILES, len(self.seen)), MISSION_SURVEY_TILES
        if self.mission == 'SIGNAL':
            return min(MISSION_CALIBRATION_REGIONS, len(self.calibrated_regions)), MISSION_CALIBRATION_REGIONS
        if self.mission == 'MIXED':
            return min(1, len(self.echoes)) + min(1, len(self.calibrated_regions)), 2
        return 0, 0

    @property
    def exit_ready(self):
        progress, required = self.mission_progress()
        return self.fragments >= self.total_fragments and progress >= required

    def mission_summary(self):
        value, goal = self.mission_progress()
        if not goal:
            return '恢复四段录音，前往出口'
        extra = ('记录异常回声' if self.mission == 'ECHO' else
                 '调查不同区域' if self.mission == 'SURVEY' else
                 '在不同区域启动倾听或回声' if self.mission == 'SIGNAL' else
                 '记录一次异常并完成一次校准')
        return f'{MISSION_NAMES[self.mission]} · {extra} {value}/{goal}'

    def emit_noise(self, radius, duration=NOISE_EVENT_DURATION):
        if self.cloak_clock > 0.:
            radius *= .55
        if self.daily_rule == '无声协议':
            radius *= .70
        self.noise_events.append((self.x, self.y, float(radius), float(duration)))
        self.noise_events = self.noise_events[-NOISE_EVENT_LIMIT:]

    def export_save(self):
        return {'version': SAVE_SCHEMA, 'world_version': self.world_version,
                'mode': self.mode, 'seed': self.seed, 'depth': self.depth,
                'x': round(self.x, 4), 'y': round(self.y, 4),
                'angle': round(self.angle, 5), 'pitch': round(self.pitch, 4),
                'battery': round(self.battery, 2), 'stamina': round(self.stamina, 2),
                'sanity': round(self.sanity, 2), 'elapsed': round(self.elapsed, 2),
                'collected': sorted(self.collected), 'echoes': sorted(self.echoes),
                'consumed': sorted(item['id'] for item in self.world.items
                                   if item['kind'] in ('cell', 'echo', 'note', 'relay') and not item['active']),
                'seen': sorted(self.seen), 'enemy_active': self.enemy_active,
                'enemy_x': round(self.enemy_x, 4), 'enemy_y': round(self.enemy_y, 4),
                'enemy_notice': self.enemy_notice, 'enemy_state': self.enemy_state,
                'enemy_timer': self.enemy_timer, 'enemy_stunned': self.enemy_stunned,
                'enemy_investigate': self.enemy_investigate,
                'enemy_investigate_clock': self.enemy_investigate_clock,
                'shadow_active': self.shadow_active, 'shadow_timer': self.shadow_timer,
                'shadow_seen': self.shadow_seen, 'shadow_moves': self.shadow_moves,
                'shadow_position': [self.shadow_x, self.shadow_y],
                'checkpoint': [round(p, 4) for p in self.checkpoint], 'recoveries': self.recoveries,
                'weapon': self.weapon, 'ammo': self.ammo[:], 'reserve': self.reserve[:],
                'skill_cooldowns': [round(v, 3) for v in self.skill_cooldowns],
                'reload_clock': self.reload_clock, 'attack_clock': self.attack_clock,
                'listen_clock': self.listen_clock, 'cloak_clock': self.cloak_clock,
                'echo_clock': self.echo_clock, 'jump_clock': self.jump_clock,
                'safe_grace': self.safe_grace, 'last_progress': self.last_progress,
                'last_hint': self.last_hint, 'noise_events': self.noise_events[-NOISE_EVENT_LIMIT:],
                'calibrated_regions': sorted(self.calibrated_regions),
                'mission_notified': self.mission_notified, 'behavior': self.behavior,
                'imprints': [[x, y, state] for (x, y), state in self.world.imprints.items()],
                'passages': [list(point) for point in sorted(self.world.passages)],
                'rift': [*self.world.rift, round(max(.1, self.world.rift_remaining), 2)] if self.world.rift else None,
                'rng': {'game': save_rng(self._random), 'horror': save_rng(self.horror.rng),
                        'world': save_rng(self.world.random)},
                'horror_memory': {'visits': [[x, y, v] for (x, y), v in self.horror.visits.items()],
                                  'events': self.horror.event_count, 'trail': self.horror.trail,
                                  'pattern_stage': self.horror.pattern_stage,
                                  'path_memory': [list(point) for point in self.horror.path_memory],
                                  'recent': list(self.horror.recent),
                                  'cooldown': self.horror.cooldown, 'duration': self.horror.duration,
                                  'grace': self.horror.grace, 'tension': self.horror.tension,
                                  'aftershock': self.horror.aftershock, 'stillness': self.horror.stillness,
                                  'flicker': self.horror.flicker, 'blackout': self.horror.blackout,
                                  'warp': self.horror.warp, 'turn_pressure': self.horror.turn_pressure,
                                  'shiver': self.horror.shiver, 'ghost_seen': self.horror.ghost_seen,
                                  'ghost': self.horror.ghost, 'false_door': self.horror.false_door,
                                  'sound_point': self.horror.sound_point,
                                  'last_tile': self.horror.last_tile, 'kind': self.horror.kind,
                                  'last_kind': self.horror.last_kind}}

    def diagnostic(self):
        return {'status': 'won' if self.won else 'playing', 'ending': self.ending, 'seed': self.seed,
                'depth': self.depth, 'architecture': self.world.architecture,
                'position': [round(self.x, 2), round(self.y, 2)], 'fragments': self.fragments,
                'battery': round(self.battery, 2), 'sanity': round(self.sanity, 2),
                'stamina': round(self.stamina, 2), 'enemy_active': self.enemy_active,
                'enemy_distance': round(self.enemy_distance, 1), 'elapsed': round(self.elapsed, 1),
                'explored_tiles': len(self.seen), 'recoveries': self.recoveries,
                'weapon': self.weapon, 'ammo': self.ammo[:], 'cooldowns': [round(c, 1) for c in self.skill_cooldowns],
                'horror': self.horror.diagnostics(), 'assist': self.assist,
                'world_version': self.world_version, 'mode': self.mode, 'echoes': len(self.echoes),
                'evidence': len(self.evidence), 'relays': len(self.relays),
                'rift_active': self.world.rift is not None,
                'entity_behavior': self.enemy_behavior, 'investigation': self.investigation,
                'daily_rule': self.daily_rule,
                'enemy_state': self.enemy_state, 'mission': self.mission,
                'mission_progress': self.mission_progress(), 'imprints': len(self.world.imprints),
                'passages': len(self.world.passages),
                'behavior': self.behavior}

    def look(self, dx, sensitivity, dy=0.):
        scale = sensitivity * (.62 if self.aiming else 1.)
        self.angle = (self.angle + dx * scale) % (2 * math.pi)
        self.pitch = clamp(self.pitch - dy * scale * .36, -.14, .14)
        self.turn_amount = min(2., self.turn_amount + abs(dx * scale))
        if abs(dx) + abs(dy) > 2.:
            self.hud_awake = max(self.hud_awake, 2.4)

    def show_message(self, message, seconds=3.):
        self.message = message
        self.message_time = seconds
        self.hud_awake = max(self.hud_awake, min(7., seconds))

    def interact(self):
        item = self.world.nearest_interactable(self.x, self.y, self.collected, self.exit_ready)
        if not item:
            self.show_message('只有电流声。这里没有东西可以触碰。', 2.)
            return 'empty'
        if item['kind'] == 'exit':
            self.won = True
            self.ending = ('失配频道' if len(self.evidence) >= 3 and len(self.relays) >= 3 else
                           '遗留调查员' if len(self.evidence) >= 5 else
                           '深层证词' if len(self.echoes) >= 5 else
                           '零号目击' if self.recoveries == 0 and self.horror.event_count >= 8 else
                           '重播档案' if self.recoveries >= 3 else
                           '错误出口' if self.investigation != '重复测绘' else '回到起点')
            self.show_message('传输完成。欢迎回来。', 8.)
            return 'won'
        if item['kind'] == 'fragment':
            self.collected.add(item['id'])
            self.fragments = len(self.collected)
            item['active'] = False
            self._signal_cache_key = None
            self.last_progress = self.elapsed
            self.last_hint = self.elapsed
            self.checkpoint = (self.x, self.y)
            self.sanity = min(100., self.sanity + 15.)
            if not self.enemy_active:
                self._awaken_stalker()
                self.safe_grace = max(self.safe_grace, 12.)
            transcripts = (
                ('灯一直亮着，却没有人知道电从哪里来。', '每一个分岔路口，都通向同一个房间。',
                 '别跑。它会记住你发出的声音。', '我们不是失踪，只是被遗忘了。'),
                ('信号比房间更早抵达这里。', '地毯下有人在数你的脚步。',
                 '声音从左侧传来，门却在右边。', '确认出口之前，请不要相信地图。'),
                ('那面墙的另一侧昨天还是走廊。', '你的名字被写进了不存在的值班簿。',
                 '有一个人始终没有离开录像。', '最后的录音里只有你此刻的呼吸。'),
                ('第四次测绘时，楼层又恢复原样。', '标记消失后，房间自己移动了。',
                 '第二次经过时，天花板更低了。', '重复不代表相同。'))
            index = int(item['id'].split('_')[-1])
            if self.fragments == self.total_fragments:
                self.show_message('四段录音已恢复。' + ('出口开始回应。' if self.exit_ready else '仍有旁证尚未确认。'), 7.)
            else:
                self.show_message(f'录音 {index + 1:02d}：{transcripts[self.seed % len(transcripts)][index]}', 7.)
            return 'fragment'
        if item['kind'] == 'echo':
            item['active'] = False
            self.echoes.add(item['id'])
            self.sanity = min(100., self.sanity + 9.)
            self.battery = min(100., self.battery + 8.)
            traces = ('有脚印停在一面没有门的墙前。', '同一组脚步声比你快了半拍。',
                      '一个房间在另一条走廊的镜头里出现。', '有人声称今天已经发生过。',
                      '不要对自己的回声作出回答。', '尽头的灯比来时少了一盏。',
                      '有人替你标记了已经走过的路。', '录音波形和你的心跳完全相同。')
            ordinal = int(item['id'].rsplit('_', 1)[-1])
            self.show_message('异常记录：' + traces[(ordinal + self.seed) % len(traces)], 6.)
            self.horror.grace = max(self.horror.grace, 3.)
            return 'echo'
        if item['kind'] == 'note':
            item['active'] = False
            self.evidence.add(item['id'])
            self.last_progress = self.elapsed
            self.sanity = min(100., self.sanity + 8.)
            notes = ('值班表有两列姓名。第二列全是你的名字。',
                     '检查窗外。无论经过多少个拐角，窗外总是同一堵墙。',
                     '不要回答从墙壁里传出的自己。',
                     '这张照片上的人正举着一张你还没找到的照片。',
                     '记录日期比摄像机制造日期早了二十七年。')
            self.show_message(f'遗留记录 {len(self.evidence):02d} · ' +
                              notes[int(item['id'].rsplit('_', 1)[-1])], 8.)
            self.horror.warp = max(self.horror.warp, .35)
            return 'note'
        if item['kind'] == 'relay':
            item['active'] = False
            self.relays.add(item['id'])
            self.last_progress = self.elapsed
            self.battery = min(100., self.battery + 18.)
            self.sanity = min(100., self.sanity + 12.)
            self.horror.grace = max(self.horror.grace, 5.)
            self.echo_clock = max(self.echo_clock, 4.)
            self._signal_cache_key = None
            self.world.mark_anomaly(self.x, self.y, self.angle)
            self.show_message(f'频段重联 {len(self.relays)}/3：声音从不存在的房间返回。', 7.)
            return 'relay'
        if item['kind'] == 'cell':
            item['active'] = False
            self.battery = min(100., self.battery + 34.)
            self.reserve = [min(120, self.reserve[0] + 5), min(160, self.reserve[1] + 8)]
            self.show_message('取回备用电芯与补给。', 3.)
            return 'cell'
        return 'empty'

    def switch_weapon(self):
        self.weapon = 1 - self.weapon
        self.reload_clock = 0.
        self.attack_clock = max(self.attack_clock, .23)
        self.show_message('应急信号枪' if self.weapon else '干扰发射器', 2.)
        return 'switch'

    def reload(self):
        slot = self.weapon
        if self.reload_clock > 0 or self.ammo[slot] == WEAPON_CAPACITY[slot] or self.reserve[slot] <= 0:
            return 'denied'
        self.reload_clock = WEAPON_RELOAD[slot]
        self.emit_noise(4.8, 1.6)
        return 'reload'

    def _can_hit_target(self, arc, radius=14.):
        if not self.enemy_active or self.enemy_distance > radius:
            return False
        angle = math.atan2(self.enemy_y - self.y, self.enemy_x - self.x)
        delta = (angle - self.angle + math.pi) % (2 * math.pi) - math.pi
        return abs(delta) <= arc and self.world.visible(self.x, self.y, self.enemy_x, self.enemy_y)

    def _hit(self, radius, arc, stun):
        if self._can_hit_target(arc, radius):
            self.enemy_stunned = max(self.enemy_stunned, stun)
            self.enemy_notice = False
            self.enemy_path = []
            self.enemy_timer = 2.5
            return True
        return False

    def _ballistic_hit(self, x, y, damage_stun):
        if not self.enemy_active or self.enemy_stunned > 1.:
            return False
        if math.hypot(x - self.enemy_x, y - self.enemy_y) > .43:
            return False
        self.enemy_stunned = max(self.enemy_stunned, damage_stun)
        self.enemy_notice = False
        self.enemy_path = []
        self.enemy_timer = 2.2
        return True

    def _fire_ray(self, angle, distance, stun):
        dx, dy = math.cos(angle), math.sin(angle)
        ox, oy = self.x, self.y
        result = None
        length = distance
        for index in range(1, int(distance / .07) + 1):
            d = min(distance, index * .07)
            x, y = ox + dx * d, oy + dy * d
            if not self.world.is_floor(x, y):
                length = d
                break
            if self.enemy_active and self.enemy_stunned <= 1. and math.hypot(x - self.enemy_x, y - self.enemy_y) < .37:
                length = d
                result = self._ballistic_hit(x, y, stun)
                break
        self.tracers.append({'x0': ox, 'y0': oy, 'x1': ox + dx * length,
                             'y1': oy + dy * length, 'life': .19, 'duration': .19,
                             'weapon': 0, 'hit': bool(result)})
        self.tracers = self.tracers[-18:]
        return bool(result)

    def _launch_flare(self, angle, secondary=False):
        self.projectiles.append({'x': self.x, 'y': self.y, 'dx': math.cos(angle),
                                 'dy': math.sin(angle), 'speed': 13. if secondary else 18.,
                                 'life': 1.05, 'tail': [(self.x, self.y)], 'weapon': 1})
        self.projectiles = self.projectiles[-12:]

    def _ballistic_tick(self, dt):
        self.shot_flash = max(0., self.shot_flash - dt)
        self.impact_flash = max(0., self.impact_flash - dt)
        self.tracers = [trace for trace in self.tracers if trace['life'] > dt]
        for trace in self.tracers:
            trace['life'] -= dt
        remaining = []
        for bullet in self.projectiles:
            distance = min(bullet['life'] * bullet['speed'], dt * bullet['speed'])
            count = max(1, int(math.ceil(distance / .065)))
            step = distance / count
            alive = True
            for _ in range(count):
                nx = bullet['x'] + bullet['dx'] * step
                ny = bullet['y'] + bullet['dy'] * step
                if not self.world.is_floor(nx, ny):
                    self.impact_flash = .15
                    alive = False
                    break
                bullet['x'], bullet['y'] = nx, ny
                if self._ballistic_hit(nx, ny, 4.5):
                    self.impact_flash = .18
                    alive = False
                    break
            bullet['life'] -= dt
            bullet['tail'].append((bullet['x'], bullet['y']))
            bullet['tail'] = bullet['tail'][-9:]
            if alive and bullet['life'] > 0.:
                remaining.append(bullet)
        self.projectiles = remaining

    def attack(self, kind):
        if self.attack_clock > 0 or self.reload_clock > 0:
            return 'denied'
        if kind == 'melee':
            self.emit_noise(6.5, 1.4)
            self.attack_clock = .48
            return 'hit' if self._hit(1.7, .85, 3.) else 'swing'
        if kind == 'heavy' or kind == 'secondary' and self.ammo[self.weapon] <= 0:
            self.emit_noise(9.5, 2.)
            self.attack_clock = .90
            return 'hit' if self._hit(2.4, 1.0, 5.) else 'heavy'
        if kind not in ('fire', 'secondary'):
            return 'denied'
        if self.ammo[self.weapon] <= 0:
            self.show_message('空仓。按 R 装弹。', 2.)
            self.attack_clock = .25
            return 'dry'
        secondary = kind == 'secondary'
        cost = min(2, self.ammo[self.weapon]) if secondary else 1
        self.ammo[self.weapon] -= cost
        self.emit_noise((20. if self.weapon else 16.) if secondary else (19. if self.weapon else 15.))
        self.behavior['shots'] += 1
        self.attack_clock = (.83 if self.weapon == 0 else .66) if secondary else (.47 if self.weapon == 0 else .28)
        self.shot_flash = .21 if secondary else .12
        spread = (.020 if self.aiming else .055) * (1.7 if secondary else 1.)
        did_hit = False
        count = 2 if secondary else 1
        for index in range(count):
            deviation = (index - (count - 1) * .5) * spread * 1.3
            deviation += self._random.uniform(-spread, spread)
            angle = self.angle + deviation
            if self.weapon == 0:
                did_hit = self._fire_ray(angle, 15. if secondary else 13., 7.5 if secondary else 7.) or did_hit
            else:
                self._launch_flare(angle, secondary)
        return 'hit' if did_hit else 'secondary' if secondary else 'shot'

    def skill(self, index):
        if not 0 <= index < len(self.skill_cooldowns):
            return 'denied'
        if self.skill_cooldowns[index] > 0:
            self.show_message(f'信号重整中 · {math.ceil(self.skill_cooldowns[index])} 秒', 1.6)
            return 'denied'
        if index == 0:
            self.listen_clock = 10.
            self.show_message('倾听已激活。耳机中浮现声源方位。', 3.)
        elif index == 1:
            if self.battery < 12.:
                self.show_message('电量不足以释放脉冲。', 2.)
                return 'denied'
            self.battery -= 12.
            self.emit_noise(12., 2.5)
            self._hit(6.5, 1.9, 6.)
            self.show_message('脉冲干扰已释放。手电依然亮着。', 3.)
        elif index == 2:
            self.cloak_clock = 9.
            self.enemy_notice = False
            self.show_message('步频已压低。保持安静。', 3.)
        else:
            self.echo_clock = 13.
            self._signal_cache_key = None
            self.show_message('回声定位已建立。信号开始偏转。', 3.)
        if index in (0, 3):
            self.calibrated_regions.add(self.world.region(self.x, self.y))
        self.skill_cooldowns[index] = SKILL_COOLDOWNS[index]
        return ('listen', 'pulse', 'cloak', 'echo')[index]

    def jump(self):
        if self.jump_clock > 0 or self.crouching or self.stamina < 8.:
            return False
        self.jump_clock = JUMP_DURATION
        self.stamina = max(0., self.stamina - 4.)
        return True

    def signal(self):
        target_type = 'EXIT' if self.exit_ready else 'TAPE'
        destination = self.world.exit if self.exit_ready else None
        extra, goal = self.mission_progress()
        cache_key = (int(self.x), int(self.y), self.fragments, self.echo_clock > 0,
                     self.world.revision, self.mission, extra,
                     tuple(sorted(self.calibrated_regions)))
        if cache_key != self._signal_cache_key:
            if destination is None:
                dists = self.world.distances((int(self.x), int(self.y)))
                if self.fragments < self.total_fragments:
                    targets = [item for item in self.world.items if item['kind'] == 'fragment' and item['active']]
                    targets.sort(key=lambda item: dists.get((int(item['x']), int(item['y'])), SIZE * SIZE))
                    destination = (targets[0]['x'], targets[0]['y']) if targets else None
                elif extra < goal:
                    if self.mission in ('ECHO', 'MIXED') and (self.mission == 'ECHO' or not self.echoes):
                        targets = [item for item in self.world.items if item['kind'] == 'echo' and item['active']]
                        targets.sort(key=lambda item: dists.get((int(item['x']), int(item['y'])), SIZE * SIZE))
                        destination = (targets[0]['x'], targets[0]['y']) if targets else None
                        target_type = 'ECHO'
                    elif self.mission == 'SURVEY':
                        unseen = [p for p in dists if p[1] * SIZE + p[0] not in self.seen and dists[p] > 3]
                        destination = self.world._center(min(unseen, key=dists.get)) if unseen else None
                        target_type = 'SURVEY'
                    else:
                        positions = [p for p in dists if self.world.region(*p) not in self.calibrated_regions]
                        destination = self.world._center(min(positions, key=dists.get)) if positions else None
                        target_type = 'CALIBRATE'
            self._signal_cache = (destination, self.world.route((self.x, self.y), destination, SIZE * SIZE)
                                  if destination else [])
            self._signal_cache_key = cache_key
        target, path = self._signal_cache
        if not target:
            return 0., 0., 'NONE'
        waypoint = next((p for p in path if math.hypot(p[0] - self.x, p[1] - self.y) > .72), target)
        bearing = (math.atan2(waypoint[1] - self.y, waypoint[0] - self.x) - self.angle + math.pi) % (2 * math.pi) - math.pi
        distance = max(0., len(path) - 1)
        strength = .14 + .67 / (1. + distance / 17.)
        overdue = max(0., self.elapsed - self.last_progress - GUIDANCE_DELAY)
        strength = min(1., strength + min(.33, overdue / 190.) + (.13 if self.echo_clock > 0 else 0.) + (.12 if self.daily_rule == '共振协议' else 0.))
        if self.exit_ready:
            target_type = 'EXIT'
        return bearing, strength, target_type

    def _awaken_stalker(self):
        origin = (int(self.x), int(self.y))
        distances = self.world.distances(origin)
        near, far = STALKER_APPROACH_TILES
        candidates = []
        for point, steps in distances.items():
            if not near <= steps <= far:
                continue
            px, py = point[0] + .5, point[1] + .5
            if math.hypot(px - self.x, py - self.y) < 5.:
                continue
            bearing = (math.atan2(py - self.y, px - self.x) - self.angle + math.pi) % (2 * math.pi) - math.pi
            hidden = abs(bearing) > 1.1 or not self.world.visible(self.x, self.y, px, py)
            candidates.append((int(hidden), steps, (px, py)))
        if candidates:
            choices = [item[-1] for item in candidates if item[0]] or [item[-1] for item in candidates]
            self.enemy_x, self.enemy_y = self._random.choice(choices)
        self.enemy_active = True
        self.enemy_distance = math.hypot(self.enemy_x - self.x, self.enemy_y - self.y)
        self.enemy_timer = .1
        self.enemy_path = []
        self.enemy_notice = False
        self.enemy_stunned = max(self.enemy_stunned, 5.)
        self.horror.cooldown = min(self.horror.cooldown, 5.)

    def _recover(self, events):
        self.x, self.y = self.checkpoint
        self.sanity = max(70., self.sanity)
        self.battery = max(40., self.battery)
        self.stamina = max(70., self.stamina)
        self.enemy_x, self.enemy_y = self.world.enemy_spawn
        self.enemy_path = []
        self.enemy_notice = False
        self.enemy_timer = 7.
        self.enemy_state = 'WANDER'
        self.enemy_investigate = None
        self.noise_events.clear()
        self.safe_grace = SAFE_GRACE
        self.enemy_stunned = 10.
        self.shadow_active = False
        self.shadow_timer = 24.
        self.horror.cooldown = max(self.horror.cooldown, 14.)
        self.horror.duration = 0.
        self.horror.blackout = 0.
        self.horror.flicker = 0.
        self.horror.grace = max(self.horror.grace, 15.)
        self.recoveries += 1
        self._signal_cache_key = None
        self.show_message('录音出现断层……你在熟悉的灯下醒来。', 6.)
        events.append('caught')

    def update(self, dt, forward, strafe, run, crouch=False, aim=False):
        if self.won or self.dead:
            return []
        dt = clamp(dt, 0., .06)
        events = []
        self.elapsed += dt
        self._ballistic_tick(dt)
        self.noise_events = [(x, y, r, remaining - dt) for x, y, r, remaining in self.noise_events if remaining > dt]
        self.enemy_investigate_clock = max(0., self.enemy_investigate_clock - dt)
        self.hud_awake = max(0., self.hud_awake - dt)
        self.turn_amount = max(0., self.turn_amount * (1. - min(1., dt * 3.2)))
        for attr in ('tutorial', 'message_time', 'enemy_stunned', 'safe_grace', 'attack_clock',
                     'listen_clock', 'cloak_clock', 'echo_clock'):
            setattr(self, attr, max(0., getattr(self, attr) - dt))
        self.skill_cooldowns = [max(0., cd - dt) for cd in self.skill_cooldowns]
        if self.reload_clock > 0:
            self.reload_clock = max(0., self.reload_clock - dt)
            if self.reload_clock == 0:
                slot = self.weapon
                taken = min(WEAPON_CAPACITY[slot] - self.ammo[slot], self.reserve[slot])
                self.ammo[slot] += taken
                self.reserve[slot] -= taken
                events.append('loaded')
        if self.jump_clock > 0:
            self.jump_clock = max(0., self.jump_clock - dt)
            self.jump_height = .24 * math.sin(math.pi * (1. - self.jump_clock / JUMP_DURATION))
        else:
            self.jump_height = 0.
        self.crouching = bool(crouch)
        self.aiming = bool(aim)
        magnitude = math.hypot(forward, strafe)
        running = bool(run and magnitude > .01 and self.stamina > 5. and not crouch and not aim)
        speed = PLAYER_SPEED * (SPRINT_MULTIPLIER if running else CROUCH_MULTIPLIER if crouch else .70 if aim else 1.)
        was_x, was_y = self.x, self.y
        if magnitude > .01:
            forward, strafe = forward / magnitude, strafe / magnitude
            dx = (math.cos(self.angle) * forward - math.sin(self.angle) * strafe) * speed * dt
            dy = (math.sin(self.angle) * forward + math.cos(self.angle) * strafe) * speed * dt
            substeps = max(1, math.ceil(math.hypot(dx, dy) / .12))
            for _ in range(substeps):
                mx, my = dx / substeps, dy / substeps
                if self.world.can_move(self.x + mx, self.y + my):
                    self.x += mx
                    self.y += my
                else:
                    if self.world.can_move(self.x + mx, self.y):
                        self.x += mx
                    if self.world.can_move(self.x, self.y + my):
                        self.y += my
        displacement = math.hypot(self.x - was_x, self.y - was_y)
        self.move_amount = min(1., displacement / max(.001, dt * PLAYER_SPEED))
        self.noise = (1.7 if running else .19 if crouch else .64 if displacement > .0001 else .04)
        if self.jump_clock > 0. and displacement > .0001:
            self.noise += .35
        if displacement > .0001:
            self.walk_phase += displacement * (6.2 if running else 5.2)
            self.step_clock += displacement * (1.8 if running else 1.25 if crouch else 1.5)
            if self.step_clock >= 1.:
                self.step_clock %= 1.
                self.behavior['steps'] += 1
                events.append('step')
        if running and displacement > .0001:
            self.behavior['sprint_seconds'] += dt
            self.stamina = max(0., self.stamina - dt * 14.)
        else:
            self.stamina = min(100., self.stamina + dt * (13. if self.move_amount < .1 else 9.))
        if crouch and displacement > .0001:
            self.behavior['stealth_seconds'] += dt
        self.flash_on = True
        self.battery = min(100., self.battery + dt * (.11 if self.daily_rule == '复原协议' else .055))
        self.sanity = min(100., self.sanity + dt * (.050 if self.daily_rule == '复原协议' else .025))
        if not self.enemy_active and self.elapsed > STALKER_AWAKEN_SECONDS:
            self._awaken_stalker()
            self.show_message('灯管的声音突然停了一秒。', 3.5)
            events.append('presence')
        if self.world.tick_rift(dt, (self.x, self.y), (self.enemy_x, self.enemy_y) if self.enemy_active else None):
            self.enemy_path = []
            self.enemy_timer = 0.
            self._signal_cache_key = None
        self.enemy_distance = math.hypot(self.x - self.enemy_x, self.y - self.enemy_y) if self.enemy_active else 1000.
        if self.enemy_active:
            self._enemy_tick(dt, running, events)
            self._shadow_tick(dt, events)
        if self.sanity <= 0:
            self._recover(events)
        if self.elapsed - self.last_progress > GUIDANCE_DELAY and self.elapsed - self.last_hint > 42.:
            self.last_hint = self.elapsed
            self.show_message('收音设备的指针颤动了一下。靠近信号更强的方向。', 5.)
            events.append('hint')
        self.threat = max(0., min(1., (12. - self.enemy_distance) / 12.)) if self.enemy_active else 0.
        self.anomaly = min(1., self.threat * .65 + max(0., (55. - self.sanity) / 110.)
                           + (.16 if self.shadow_active else .08))
        self._explore()
        region = self.world.region(self.x, self.y)
        if region != self.current_region:
            self.current_region = region
            if self.elapsed > 18. and self.horror.grace < 3.:
                self.show_message(('灯光变得更黄了。', '墙里传来了排水声。', '这里像是你刚刚走过的地方。',
                                   '空气中弥漫着旧纸张的味道。', '同一台机器的嗡鸣又出现了。')[region], 3.5)
        self.near_item = self.world.nearest_interactable(self.x, self.y, self.collected, self.exit_ready)
        if self.assist and self.near_item and self.near_item['kind'] in ('fragment', 'cell', 'echo'):
            nearby = math.hypot(self.near_item['x'] - self.x, self.near_item['y'] - self.y) <= AUTO_PICKUP_RADIUS
            self.auto_pick_clock = self.auto_pick_clock + dt if nearby else 0.
            if self.auto_pick_clock >= AUTO_PICKUP_SECONDS:
                result = self.interact()
                if result in ('fragment', 'cell', 'echo'):
                    events.append('pickup_' + result)
                self.auto_pick_clock = 0.
        else:
            self.auto_pick_clock = 0.
        if self.assist and self.ammo[self.weapon] == 0 and self.reserve[self.weapon] > 0 and self.reload_clock <= 0.:
            if self.reload() == 'reload':
                events.append('auto_reload')
        if self.listen_clock > 0.:
            source = (self.enemy_x, self.enemy_y) if self.enemy_active else self.horror.sound_point
            if source:
                dx, dy = source[0] - self.x, source[1] - self.y
                self.listen_bearing = (math.atan2(dy, dx) - self.angle + math.pi) % (2 * math.pi) - math.pi
                self.listen_distance = math.hypot(dx, dy)
            else:
                self.listen_bearing, self.listen_distance = 0., 1000.
        self.target_lock = self._can_hit_target(.46 if self.aiming else .28)
        horror_events = self.horror.update(self, dt)
        for event in horror_events:
            stage = event.get('pattern_stage', 0) if isinstance(event, dict) else 0
            if stage:
                signs = {
                    '重复的脚步': ('脚步声和你刚才的节奏完全相同。', '你停下之后，它又走了三步。', '这次脚步声先于你的动作响起。'),
                    '多余的房间': ('你确信刚才那里没有走廊。', '新的门通向记忆里不存在的空间。', '地图上少了一间你刚刚经过的房间。'),
                    '未发送的记录': ('录音里有人复述你尚未说出口的话。', '墙后的设备正在播放上一段调查。', '记录显示：你不止一次来过这里。'),
                    '远处的观察者': ('远处的人影没有影子。', '你回过头时，它似乎更靠近了。', '你终于确认：被观察的是另一个你。')}
                self.show_message(signs[self.horror.pattern][min(2, stage - 1)], 6.5)
        events.extend(horror_events)
        progress, required = self.mission_progress()
        if self.fragments == self.total_fragments and progress >= required and not self.mission_notified:
            self.mission_notified = True
            self.last_progress = self.elapsed
            self._signal_cache_key = None
            self.show_message('信号已核实。出口位置正在浮现。', 6.)
            events.append('hint')
        self.anomaly = max(self.anomaly, self.horror.tension * .65)
        return events

    def _shadow_tick(self, dt, events):
        self.shadow_timer = max(-1., self.shadow_timer - dt)
        if not self.shadow_active:
            if self.shadow_timer > 0. or self.safe_grace > 0. or self.elapsed < 55.:
                return
            cells = self.world.distances((int(self.x), int(self.y)))
            candidates = []
            for (x, y), distance in cells.items():
                if not 3 <= distance <= 8:
                    continue
                px, py = x + .5, y + .5
                angle = (math.atan2(py - self.y, px - self.x) - self.angle + math.pi) % (2 * math.pi) - math.pi
                if abs(angle) < .60 and self.world.visible(self.x, self.y, px, py):
                    candidates.append((px, py))
            if candidates:
                self.shadow_x, self.shadow_y = self._random.choice(candidates)
                self.shadow_active = True
                self.shadow_seen = 0.
                self.shadow_moves = 0
                self.shadow_timer = self._random.uniform(7., 13.)
                events.append({'type': 'horror', 'kind': 'shadow', 'sound': None})
            else:
                self.shadow_timer = 8.
            return
        self.shadow_distance = math.hypot(self.x - self.shadow_x, self.y - self.shadow_y)
        delta = (math.atan2(self.shadow_y - self.y, self.shadow_x - self.x) - self.angle + math.pi) % (2 * math.pi) - math.pi
        if abs(delta) < .26 and self.world.visible(self.x, self.y, self.shadow_x, self.shadow_y):
            self.shadow_seen += dt
        else:
            self.shadow_seen = max(0., self.shadow_seen - 2. * dt)
        if self.shadow_distance < 2.2:
            self.sanity = max(1., self.sanity - dt * .48)
        if self.shadow_seen > .65 and self.shadow_moves < 3 and self.shadow_timer > 1.:
            cells = self.world.distances((int(self.x), int(self.y)))
            locations = []
            for (cx, cy), steps in cells.items():
                if 4 <= steps <= 9:
                    px, py = cx + .5, cy + .5
                    angle = (math.atan2(py - self.y, px - self.x) - self.angle + math.pi) % (2 * math.pi) - math.pi
                    if abs(angle) > 1.9 and not self.world.visible(self.x, self.y, px, py):
                        locations.append((px, py))
            if locations:
                self.shadow_x, self.shadow_y = self._random.choice(locations)
                self.shadow_moves += 1
                self.behavior['observations'] += 1
                self.shadow_seen = 0.
                self.shadow_timer = max(1.5, self.shadow_timer - 2.)
                events.append({'type': 'horror', 'kind': 'observer', 'sound': 'whisper',
                               'position': (self.shadow_x, self.shadow_y), 'intensity': .12})
        if self.shadow_timer <= 0. or self.shadow_seen > 1.1 or self.shadow_distance > 12.:
            self.shadow_active = False
            self.shadow_distance = 1000.
            self.shadow_timer = self._random.uniform(25., 58.)

    def _enemy_tick(self, dt, running, events):
        if self.enemy_stunned > 0 or self.safe_grace > 0:
            return
        self.enemy_timer -= dt
        dist = self.enemy_distance
        visible = dist < 13. and self.world.visible(self.enemy_x, self.enemy_y, self.x, self.y)
        movement_radius = 3.2 + self.noise * (5.2 if self.enemy_behavior == 'LISTENER' else 3.5)
        sight_radius = 8.5 if self.enemy_behavior == 'WATCHER' else 6.8
        if self.crouching:
            sight_radius *= .48
        if self.move_amount < .08:
            sight_radius *= .78
        if self.enemy_behavior == 'DRIFTER' and self.move_amount < .08:
            sight_radius *= 1.28
        optical = visible and dist < sight_radius
        movement_heard = dist < movement_radius
        heard = None
        for sound in reversed(self.noise_events):
            sx, sy, radius, _ = sound
            if not self.world.is_floor(sx, sy):
                continue
            distance = math.hypot(self.enemy_x - sx, self.enemy_y - sy)
            occluded = not self.world.visible(self.enemy_x, self.enemy_y, sx, sy)
            limit = radius * (.56 if occluded else 1.)
            if self.enemy_behavior == 'LISTENER':
                limit *= 1.18
            if distance <= limit:
                heard = (sx, sy)
                break
        if heard:
            self.enemy_investigate = heard
            self.enemy_investigate_clock = max(self.enemy_investigate_clock, 4.5)
        hunting = self.cloak_clock <= 0. and (optical or movement_heard)
        investigating = self.enemy_investigate is not None and self.enemy_investigate_clock > 0.
        if (hunting or heard) and not self.enemy_notice:
            self.enemy_notice = True
            self.horror.grace = max(self.horror.grace, 4.)
            self.horror.cooldown = max(self.horror.cooldown, 5.)
            self.hud_awake = max(self.hud_awake, 10.)
            events.append('spotted')
        if not hunting and not investigating and dist > 15.:
            self.enemy_notice = False
        if hunting:
            self.enemy_state = 'CHASE'
        elif investigating:
            self.enemy_state = 'LISTEN' if heard else 'SEARCH'
        elif self.enemy_behavior == 'WATCHER' and 5. < dist < 12.:
            self.enemy_state = 'OBSERVE'
        else:
            self.enemy_state = 'WANDER'
        if self.enemy_timer <= 0 or not self.enemy_path or heard:
            if hunting:
                target = (self.x, self.y)
            elif investigating:
                target = self.enemy_investigate
            elif self.enemy_state == 'OBSERVE':
                target = (self.enemy_x, self.enemy_y)
            elif dist > 10. and self._random.random() < (.30 if self.crouching else .58):
                target = (self.x, self.y)
            elif self._random.random() < .55:
                target = self._random.choice(self.world.lights)
            else:
                target = self.world.enemy_spawn
            self.enemy_path = self.world.route((self.enemy_x, self.enemy_y), target, SIZE * SIZE)
            self.enemy_timer = .85 if hunting else 1.5 if investigating else 3.2
        if self.enemy_path:
            tx, ty = self.enemy_path[0]
            dx, dy = tx - self.enemy_x, ty - self.enemy_y
            distance = math.hypot(dx, dy)
            behavior_speed = (1.0, .87, .94)[('WATCHER', 'LISTENER', 'DRIFTER').index(self.enemy_behavior)]
            pace = (STALKER_CHASE_SPEED if hunting else STALKER_WANDER_SPEED) * behavior_speed * dt
            if distance <= pace + .05:
                self.enemy_x, self.enemy_y = tx, ty
                self.enemy_path.pop(0)
            elif distance > .001:
                self.enemy_x += dx / distance * pace
                self.enemy_y += dy / distance * pace
        if investigating and self.enemy_investigate:
            if math.hypot(self.enemy_x - self.enemy_investigate[0], self.enemy_y - self.enemy_investigate[1]) < 1.:
                self.enemy_investigate_clock = min(self.enemy_investigate_clock, 1.)
        if self.enemy_investigate_clock <= 0.:
            self.enemy_investigate = None
        self.enemy_distance = math.hypot(self.x - self.enemy_x, self.y - self.enemy_y)
        if self.enemy_distance < 5.:
            self.hud_awake = max(self.hud_awake, 3.)
            self.sanity = max(0., self.sanity - dt * (.85 if visible else .12))
        if self.enemy_distance < .48 and visible:
            self._recover(events)
