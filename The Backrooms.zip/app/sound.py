import math
import os
import random

import pygame

from config import (SOUND_CHANNELS, SOUND_INTERVAL, SOUND_ECHO_QUEUE_LIMIT,
                    SOUND_MAX_SOURCE_RANGE_FACTOR)

MEDIA = os.path.join(os.path.dirname(__file__), 'media')
SOUND_NAMES = ('ambience', 'step', 'pickup', 'click', 'stinger', 'heartbeat', 'door',
               'drone', 'duct', 'distant_steps', 'whisper', 'shot', 'melee', 'reload',
               'breath', 'roomtone', 'tape_hiss', 'knock')


class Soundscape:
    def __init__(self, volume=.65, on_warning=None):
        self.enabled = False
        self.sounds = {}
        self.volume = max(0., min(1., float(volume)))
        self.focused = True
        self.channels = []
        self.heartbeat_clock = 0.
        self.spatial_clock = 13.
        self.listen_sound_clock = 0.
        self.mimic_clock = 0.
        self.clock = 0.
        self.random = random.Random()
        self.error = ''
        self.echo_queue = []
        self.on_warning = on_warning
        self._reported_sources = set()
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=1024)
            self.sounds = {name: pygame.mixer.Sound(os.path.join(MEDIA, name + '.wav'))
                           for name in SOUND_NAMES if os.path.isfile(os.path.join(MEDIA, name + '.wav'))}
            pygame.mixer.set_num_channels(max(SOUND_CHANNELS, pygame.mixer.get_num_channels()))
            pygame.mixer.set_reserved(5)
            self.channels = [pygame.mixer.Channel(i) for i in range(5)]
            for index, name in ((0, 'ambience'), (1, 'drone'), (2, 'roomtone'), (3, 'tape_hiss')):
                if name in self.sounds:
                    self.channels[index].play(self.sounds[name], loops=-1, fade_ms=900 + index * 200)
            self.enabled = True
        except (pygame.error, OSError) as error:
            self.enabled = False
            self.error = f'{type(error).__name__}: {str(error)[:140]}'

    def set_volume(self, value):
        self.volume = max(0., min(1., float(value)))

    def set_focus(self, focused):
        self.focused = bool(focused)
        if self.enabled and not self.focused:
            self.channels[4].stop()
            self.echo_queue.clear()

    def play(self, name, factor=1., pan=0., channel=None):
        if not self.enabled or not self.focused or name not in self.sounds:
            return
        if channel is None:
            channel = pygame.mixer.find_channel(force=False)
        if channel is None:
            return
        level = max(0., min(.83, self.volume * factor))
        pan = max(-1., min(1., pan))
        channel.set_volume(level * math.sqrt((1. - pan) * .5) * 1.41,
                           level * math.sqrt((1. + pan) * .5) * 1.41)
        channel.play(self.sounds[name])

    @staticmethod
    def _pan(game, dx, dy):
        return math.sin(math.atan2(dy, dx) - game.angle)

    @staticmethod
    def _valid_position(position):
        if not isinstance(position, (tuple, list)) or len(position) != 2:
            return False
        try:
            return all(type(value) in (int, float) and math.isfinite(value) for value in position)
        except (TypeError, ValueError, OverflowError):
            return False

    def _invalid_source(self, name, position, reason):
        self.error = f'Invalid audio source ({reason}): {name}'
        key = (str(name)[:48], reason)
        if key not in self._reported_sources:
            self._reported_sources.add(key)
            if self.on_warning is not None:
                self.on_warning(f'AUDIO_INVALID_SOURCE name={str(name)[:48]} kind={reason} type={type(position).__name__}')

    def play_at(self, name, factor, game, position, channel=None):
        if game is None or position is None:
            self.play(name, factor, channel=channel)
            return
        if not self._valid_position(position):
            self._invalid_source(name, position, 'coordinates')
            self.play(name, factor, channel=channel)
            return
        try:
            x, y = float(position[0]), float(position[1])
            dx, dy = x - game.x, y - game.y
            distance = math.hypot(dx, dy)
            if not math.isfinite(distance):
                raise ValueError('nonfinite distance')
            world = game.world
            bound = max(getattr(world, 'width', 0), getattr(world, 'height', 0))
            if bound and distance > bound * SOUND_MAX_SOURCE_RANGE_FACTOR:
                raise ValueError('source out of bounds')
            occluded = not world.visible(game.x, game.y, x, y)
            attenuation = 1. / (1. + max(0., distance - 1.) * (.087 if not occluded else .22))
            pan = self._pan(game, dx, dy) * (.42 if occluded else 1.)
            level = factor * attenuation * (.53 if occluded else 1.)
            if (name in ('knock', 'door', 'distant_steps', 'whisper', 'breath', 'duct')
                    and distance > 1.7 and len(self.echo_queue) < SOUND_ECHO_QUEUE_LIMIT):
                space = world.region(game.x, game.y)
                reflections = (.11, .22, .14, .28, .19)[space]
                self.echo_queue.append((self.clock + reflections, name,
                                        level * (.15 if occluded else .23), -pan * .55))
        except (TypeError, ValueError, OverflowError, IndexError, AttributeError) as error:
            self._invalid_source(name, position, type(error).__name__)
            self.play(name, factor, channel=channel)
            return
        self.play(name, level, pan, channel)

    def _distant_source(self, game):
        if game.enemy_active and self.random.random() < .42:
            return game.enemy_x, game.enemy_y
        if game.horror.sound_point and self.random.random() < .65:
            return game.horror.sound_point
        candidates = []
        for _ in range(20):
            angle = game.angle + self.random.uniform(-math.pi, math.pi)
            dist = self.random.uniform(3., 13.)
            x, y = game.x + math.cos(angle) * dist, game.y + math.sin(angle) * dist
            if game.world.is_floor(x, y):
                candidates.append((x, y))
        return self.random.choice(candidates) if candidates else (game.x, game.y)

    def update(self, dt, game, state):
        if not self.enabled:
            return
        self.clock += dt
        due = [entry for entry in self.echo_queue if entry[0] <= self.clock]
        self.echo_queue = [entry for entry in self.echo_queue if entry[0] > self.clock]
        if self.focused and state == 'PLAY':
            for _, name, level, pan in due:
                self.play(name, level, pan)
        if not self.focused:
            for channel in self.channels[:4]:
                channel.set_volume(0.)
            return
        playing = state == 'PLAY' and game is not None
        threat = game.threat if playing else 0.
        tension = game.horror.tension if playing else 0.
        silent = playing and game.horror.kind == 'silence'
        listening = playing and game.listen_clock > 0.
        atten = .12 if silent else .55 if listening else 1.
        breathing = .89 + .11 * math.sin(self.clock * .17)
        area = game.world.region(game.x, game.y) if playing else 0
        profiles = ((1., 1., 1.), (.86, 1.18, .95), (.90, 1.32, 1.2),
                    (1.10, .86, 1.05), (.67, 1.45, .86))
        a, d, r = profiles[area]
        levels = (.27 * a * breathing * atten,
                  (.04 + .12 * threat + .06 * tension) * d * atten,
                  .12 * r * atten, .045 * atten)
        for channel, level in zip(self.channels[:4], levels):
            channel.set_volume(self.volume * level)
        if not playing:
            self.heartbeat_clock = 0.
            self.listen_sound_clock = 0.
            return
        if game.enemy_active and game.enemy_distance < 8.:
            self.heartbeat_clock -= dt
            if self.heartbeat_clock <= 0.:
                self.play_at('heartbeat', .30 + .42 * (1. - min(8., game.enemy_distance) / 8.),
                             game, (game.enemy_x, game.enemy_y))
                self.heartbeat_clock = .53 + .66 * min(1., game.enemy_distance / 8.)
        else:
            self.heartbeat_clock = 0.
        if playing and game.horror.kind == 'mimic' and game.move_amount > .12:
            self.mimic_clock -= dt
            if self.mimic_clock <= 0.:
                self.play_at('distant_steps', .39, game, game.horror.sound_point, self.channels[4])
                self.mimic_clock = .52 + self.random.uniform(-.09, .15)
        else:
            self.mimic_clock = 0.
        if listening:
            self.listen_sound_clock -= dt
            if self.listen_sound_clock <= 0.:
                source = (game.enemy_x, game.enemy_y) if game.enemy_active else game.horror.sound_point
                if source:
                    self.play_at('distant_steps', .53, game, source, self.channels[4])
                else:
                    self.play_at('duct', .32, game, self._distant_source(game), self.channels[4])
                self.listen_sound_clock = 1.45 + self.random.uniform(0., .55)
        else:
            self.listen_sound_clock = 0.
        self.spatial_clock -= dt
        if self.spatial_clock <= 0. and not listening and game.horror.kind != 'silence':
            proximity = game.enemy_distance if game.enemy_active else 15.
            name = self.random.choices(('duct', 'distant_steps', 'whisper', 'breath'),
                                       weights=(5, 4, 3 if proximity < 12 else 1, 2), k=1)[0]
            self.play_at(name, .30 if name == 'distant_steps' else .25, game,
                         self._distant_source(game), self.channels[4])
            self.spatial_clock = self.random.uniform(*SOUND_INTERVAL) / (1. + tension * .42)

    def close(self):
        if self.enabled:
            try:
                pygame.mixer.stop()
            except pygame.error:
                pass
