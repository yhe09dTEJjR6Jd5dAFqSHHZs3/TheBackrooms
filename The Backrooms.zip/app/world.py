import collections
import math
import random

from config import (EXIT_INTERACT_RADIUS, INTERACT_RADIUS, WORLD_BASE_ROOMS,
                    WORLD_ECHOES, WORLD_GENERATION, WORLD_OBJECTIVES,
                    WORLD_REGION_SIZE, WORLD_SIZE, WORLD_MEMORY_MAX_MARKS,
                    WORLD_REVISIT_THRESHOLDS)

SIZE = WORLD_SIZE
OBJECTIVES = WORLD_OBJECTIVES
ZONE_NAMES = ('泛黄回廊', '空调夹层', '潮湿底区', '档案走廊', '断电边界')


class World:
    def __init__(self, seed, generation=WORLD_GENERATION):
        self.generation = int(generation) if generation in (1, 2, WORLD_GENERATION) else WORLD_GENERATION
        self.seed = int(seed)
        self.random = random.Random(self.seed)
        self.width = SIZE
        self.height = SIZE
        self.grid = [[0] * SIZE for _ in range(SIZE)]
        self.items = []
        self.lights = []
        self.exit = (1.5, 1.5)
        self.enemy_spawn = (1.5, 1.5)
        self.revision = 0
        self.rift = None
        self.rift_remaining = 0.
        self.imprints = {}
        self.architecture = ('静滞办公区', '巨型空厅', '折返通道', '潮湿资料区',
                             '连续壁龛', '隔音工作间')[self.seed % 6]
        self._generate()

    def _generate(self):
        rnd = self.random
        self.grid[1][1] = 1
        stack = [(1, 1)]
        while stack:
            x, y = stack[-1]
            neighbors = [(x + dx, y + dy, dx, dy) for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2))
                         if 1 <= x + dx < SIZE - 1 and 1 <= y + dy < SIZE - 1 and not self.grid[y + dy][x + dx]]
            if not neighbors:
                stack.pop()
                continue
            nx, ny, dx, dy = rnd.choice(neighbors)
            self.grid[y + dy // 2][x + dx // 2] = 1
            self.grid[ny][nx] = 1
            stack.append((nx, ny))
        for _ in range(WORLD_BASE_ROOMS):
            x = rnd.randrange(3, SIZE - 5, 2)
            y = rnd.randrange(3, SIZE - 5, 2)
            if rnd.random() < .55:
                for yy in range(y - 1, y + rnd.randrange(2, 5)):
                    for xx in range(x - 1, x + rnd.randrange(2, 5)):
                        if 1 <= yy < SIZE - 1 and 1 <= xx < SIZE - 1:
                            self.grid[yy][xx] = 1
        for y in range(2, SIZE - 2):
            for x in range(2, SIZE - 2):
                if self.grid[y][x]:
                    continue
                horizontal = self.grid[y][x - 1] and self.grid[y][x + 1]
                vertical = self.grid[y - 1][x] and self.grid[y + 1][x]
                if (horizontal or vertical) and rnd.random() < .14:
                    self.grid[y][x] = 1
        if self.generation >= 2:
            self._architectural_variations(rnd)
        if self.generation >= 3:
            self._expand_architecture(rnd)
        distances = self.distances((1, 1))
        ranked = sorted(distances, key=lambda p: distances[p], reverse=True)
        far = [p for p in ranked if distances[p] > 35]
        self.exit = self._center(far[0] if far else ranked[0])
        selected = [self._cell(self.exit)]
        for index in range(OBJECTIVES):
            if index == 0:
                candidates = [p for p, steps in distances.items() if 9 <= steps <= 17
                              and min(self._sqdist(p, s) for s in selected) >= 80]
                pool = candidates if candidates else [p for p, steps in distances.items() if 6 <= steps <= 24]
            else:
                candidates = [p for p in ranked if distances[p] > 16
                              and min(self._sqdist(p, s) for s in selected) >= 80]
                pool = candidates[:max(1, len(candidates) // 2)] if candidates else ranked[:50]
            point = rnd.choice(pool)
            selected.append(point)
            self.items.append({'id': f'fragment_{index}', 'kind': 'fragment', 'x': point[0] + .5,
                               'y': point[1] + .5, 'active': True})
        candidates = [p for p in ranked if distances[p] > 20 and self._sqdist(p, (1, 1)) >= 500]
        spawn = rnd.choice(candidates[:max(1, len(candidates) // 2)]) if candidates else ranked[0]
        self.enemy_spawn = self._center(spawn)
        for index in range(13):
            point = rnd.choice(ranked)
            if self._sqdist(point, (1, 1)) < 18 or min(self._sqdist(point, s) for s in selected) < 3:
                continue
            self.items.append({'id': f'cell_{index}', 'kind': 'cell', 'x': point[0] + .5,
                               'y': point[1] + .5, 'active': True})
        if self.generation >= 2:
            self._scatter_echoes(rnd, ranked, selected, distances)
        for y in range(2, SIZE - 2):
            for x in range(2, SIZE - 2):
                if not self.grid[y][x]:
                    continue
                if (x * 13 + y * 29 + self.seed) % (19 if self.generation >= 2 and self.region(x, y) == 3 else 23) == 0:
                    self.lights.append((x + .5, y + .5))
        self.lights.append((1.5, 1.5))
        self.lights.append(self.exit)

    def _architectural_variations(self, rnd):
        variant = self.seed % 4
        room_count = (5, 8, 6, 9)[variant]
        for _ in range(room_count):
            x = rnd.randrange(5, SIZE - 12, 2)
            y = rnd.randrange(5, SIZE - 12, 2)
            span_x = rnd.randrange(3, 8) if variant != 2 else rnd.randrange(5, 10)
            span_y = rnd.randrange(3, 8) if variant != 1 else rnd.randrange(2, 5)
            for yy in range(y, min(SIZE - 1, y + span_y)):
                for xx in range(x, min(SIZE - 1, x + span_x)):
                    self.grid[yy][xx] = 1
        if variant in (1, 3):
            for _ in range(16):
                x = rnd.randrange(3, SIZE - 3)
                y = rnd.randrange(3, SIZE - 3)
                if (self.grid[y][x - 1] and self.grid[y][x + 1]
                        or self.grid[y - 1][x] and self.grid[y + 1][x]):
                    self.grid[y][x] = 1

    def _expand_architecture(self, rnd):
        pattern = self.seed % 6
        reachable = list(self.distances((1, 1)))
        if not reachable:
            return
        count = (7, 4, 5, 9, 6, 8)[pattern]
        for _ in range(count):
            x, y = rnd.choice(reachable)
            if not 5 <= x < SIZE - 6 or not 5 <= y < SIZE - 6:
                continue
            length = rnd.randrange(2, 7) if pattern != 1 else rnd.randrange(4, 9)
            width = (1, 2, 1, 2, 1, 3)[pattern]
            dx, dy = rnd.choice(((1, 0), (-1, 0), (0, 1), (0, -1)))
            for step in range(length):
                for offset in range(-width, width + 1):
                    xx = x + dx * step + (dy * offset)
                    yy = y + dy * step + (dx * offset)
                    if 1 <= xx < SIZE - 1 and 1 <= yy < SIZE - 1:
                        self.grid[yy][xx] = 1
            reachable = list(self.distances((1, 1)))

    def remember(self, cell, visits):
        if self.generation < 3 or visits not in WORLD_REVISIT_THRESHOLDS:
            return False
        if len(self.imprints) >= WORLD_MEMORY_MAX_MARKS:
            return False
        x, y = cell
        if (x * 13 + y * 19 + self.seed) % 4:
            return False
        candidates = [(x + dx, y + dy) for dx, dy in ((1, 0), (0, 1), (-1, 0), (0, -1))
                      if 0 <= x + dx < SIZE and 0 <= y + dy < SIZE
                      and not self.grid[y + dy][x + dx]]
        if not candidates:
            return False
        wall = candidates[(x * 7 + y * 3 + self.seed) % len(candidates)]
        next_state = min(2, self.imprints.get(wall, 0) + 1)
        if self.imprints.get(wall) == next_state:
            return False
        self.imprints[wall] = next_state
        self.revision += 1
        return True

    def restore_imprints(self, records):
        if self.generation < 3 or not isinstance(records, list):
            return
        for item in records[:WORLD_MEMORY_MAX_MARKS]:
            if not isinstance(item, (list, tuple)) or len(item) != 3:
                continue
            x, y, v = item
            if (type(x) is int and type(y) is int and type(v) is int
                    and 0 <= x < SIZE and 0 <= y < SIZE and not self.grid[y][x]
                    and 1 <= v <= 2):
                self.imprints[(x, y)] = v
        if self.imprints:
            self.revision += 1

    def _scatter_echoes(self, rnd, ranked, selected, distances):
        pool = [point for point in ranked if distances[point] > 13
                and min(self._sqdist(point, other) for other in selected) > 24]
        rnd.shuffle(pool)
        amount = rnd.randint(*WORLD_ECHOES)
        picks = []
        for point in pool:
            if len(picks) >= amount:
                break
            if any(self._sqdist(point, other) < 38 for other in picks):
                continue
            picks.append(point)
        for index, (x, y) in enumerate(picks):
            self.items.append({'id': f'echo_{index}', 'kind': 'echo',
                               'x': x + .5, 'y': y + .5, 'active': True})

    def _rift_candidate(self, x, y):
        if not 2 <= x < SIZE - 2 or not 2 <= y < SIZE - 2 or self.grid[y][x]:
            return False
        return bool((self.grid[y][x - 1] and self.grid[y][x + 1]) or
                    (self.grid[y - 1][x] and self.grid[y + 1][x]))

    def restore_rift(self, record):
        if self.generation < 2 or not isinstance(record, list) or len(record) != 3:
            return False
        x, y, remaining = record
        if type(x) is not int or type(y) is not int or type(remaining) not in (int, float):
            return False
        if not self._rift_candidate(x, y) or not math.isfinite(remaining) or not .0 < remaining <= 60.:
            return False
        self.grid[y][x] = 1
        self.rift = (x, y)
        self.rift_remaining = remaining
        self.revision += 1
        return True

    def open_rift_near(self, px, py, angle):
        if self.generation < 2 or self.rift is not None:
            return None
        candidates = []
        for y in range(max(2, int(py) - 8), min(SIZE - 2, int(py) + 9)):
            for x in range(max(2, int(px) - 8), min(SIZE - 2, int(px) + 9)):
                if not self._rift_candidate(x, y):
                    continue
                cx, cy = x + .5, y + .5
                distance = math.hypot(cx - px, cy - py)
                if not 2. <= distance <= 7.5:
                    continue
                delta = (math.atan2(cy - py, cx - px) - angle + math.pi) % (2 * math.pi) - math.pi
                if abs(delta) > .95:
                    continue
                neighbors = ((x - .5, cy), (x + 1.5, cy), (cx, y - .5), (cx, y + 1.5))
                if not any(self.is_floor(nx, ny) and self.visible(px, py, nx, ny)
                           for nx, ny in neighbors):
                    continue
                candidates.append((distance + abs(delta), (x, y)))
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0])
        point = self.random.choice(candidates[:max(1, len(candidates) // 3)])[1]
        self.grid[point[1]][point[0]] = 1
        self.rift = point
        self.rift_remaining = 12.
        self.revision += 1
        return self._center(point)

    def tick_rift(self, dt, player, enemy=None):
        if self.rift is None:
            return False
        self.rift_remaining = max(0., self.rift_remaining - dt)
        if self.rift_remaining > 0.:
            return False
        center = self._center(self.rift)
        if math.hypot(player[0] - center[0], player[1] - center[1]) < 1.45:
            return False
        if enemy and math.hypot(enemy[0] - center[0], enemy[1] - center[1]) < 1.45:
            return False
        self.grid[self.rift[1]][self.rift[0]] = 0
        self.rift = None
        self.revision += 1
        return True

    def zone_name(self, x, y):
        return ZONE_NAMES[self.region(x, y)]

    @staticmethod
    def _sqdist(a, b):
        return (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2

    @staticmethod
    def _center(point):
        return point[0] + .5, point[1] + .5

    @staticmethod
    def _cell(point):
        return int(point[0]), int(point[1])

    def is_floor(self, x, y):
        ix, iy = int(math.floor(x)), int(math.floor(y))
        return 0 <= ix < self.width and 0 <= iy < self.height and self.grid[iy][ix] == 1

    def can_move(self, x, y, radius=.19):
        return all(self.is_floor(x + dx, y + dy) for dx in (-radius, radius) for dy in (-radius, radius))

    def distances(self, start):
        todo = collections.deque([start])
        d = {start: 0}
        while todo:
            x, y = todo.popleft()
            for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                p = (nx, ny)
                if p not in d and self.is_floor(nx, ny):
                    d[p] = d[(x, y)] + 1
                    todo.append(p)
        return d

    def route(self, start, destination, max_nodes=SIZE * SIZE):
        start = self._cell(start)
        destination = self._cell(destination)
        if start == destination:
            return [self._center(destination)]
        todo = collections.deque([start])
        parent = {start: None}
        while todo and len(parent) <= max_nodes:
            x, y = todo.popleft()
            for p in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if p in parent or not self.is_floor(*p):
                    continue
                parent[p] = (x, y)
                if p == destination:
                    path = [p]
                    while parent[path[-1]] is not None:
                        path.append(parent[path[-1]])
                    path.reverse()
                    return [self._center(point) for point in path]
                todo.append(p)
        return []

    def visible(self, x1, y1, x2, y2):
        distance = math.hypot(x2 - x1, y2 - y1)
        steps = max(1, int(distance / .11))
        for i in range(1, steps):
            ratio = i / steps
            if not self.is_floor(x1 + (x2 - x1) * ratio, y1 + (y2 - y1) * ratio):
                return False
        return True

    def region(self, x, y):
        return ((int(x) // WORLD_REGION_SIZE) * 3 + (int(y) // WORLD_REGION_SIZE) * 7 + self.seed) % 5

    def wall_style(self, x, y, variants=5):
        region = self.region(x, y) % variants
        speckle = ((x * 29) ^ (y * 41) ^ self.seed) % 11
        return (region + (1 if speckle == 0 else 0) + self.imprints.get((x, y), 0)) % variants

    def nearest_interactable(self, x, y, collected, exit_ready=None):
        choices = [item for item in self.items if item['active'] and math.hypot(item['x'] - x, item['y'] - y) < INTERACT_RADIUS
                   and self.visible(x, y, item['x'], item['y'])]
        if (len(collected) == OBJECTIVES if exit_ready is None else exit_ready) and math.hypot(self.exit[0] - x, self.exit[1] - y) < EXIT_INTERACT_RADIUS:
            choices.append({'id': 'exit', 'kind': 'exit', 'x': self.exit[0], 'y': self.exit[1], 'active': True})
        return min(choices, key=lambda item: self._sqdist((x, y), (item['x'], item['y']))) if choices else None
