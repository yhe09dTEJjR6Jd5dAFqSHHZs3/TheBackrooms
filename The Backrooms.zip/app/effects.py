import math

import pygame

from config import TAN_HALF, WEAPON_RELOAD
from weapon3d import WeaponMesh



class VisualEffects:
    def __init__(self):
        self.meshes = (WeaponMesh(0), WeaponMesh(1))
        self.cache = {}
        self.layer = None
        self.size = None
        self.reset()

    def reset(self):
        self.action = 'draw'
        self.action_time = 0.
        self.action_length = 0.001
        self.hit_time = 0.
        self.flash_time = 0.
        self.pulse_time = 0.
        self.echo_time = 0.
        self.listen_time = 0.
        self.cloak_time = 0.
        self.discover_time = 0.
        self.weapon = 0
        self.shot_type = 'fire'
        self.clock = 0.

    def weapon_action(self, action, weapon, hit=False):
        self.action = action
        self.weapon = weapon
        self.action_length = {'fire': .42, 'secondary': .73, 'heavy': .74,
                              'melee': .54, 'reload': WEAPON_RELOAD[weapon],
                              'switch': .38, 'draw': .27}.get(action, .40)
        self.action_time = self.action_length
        if action in ('fire', 'secondary'):
            self.shot_type = action
            self.flash_time = .19 if action == 'fire' else .33
        if hit:
            self.hit_time = .28

    def skill(self, kind):
        if kind == 'listen':
            self.listen_time = 1.0
        elif kind == 'pulse':
            self.pulse_time = .94
        elif kind == 'cloak':
            self.cloak_time = 1.
        elif kind == 'echo':
            self.echo_time = 1.7

    def discovery(self):
        self.discover_time = 1.25

    def update(self, dt):
        self.clock += max(0., dt)
        for attr in ('action_time', 'hit_time', 'flash_time', 'pulse_time',
                     'echo_time', 'listen_time', 'cloak_time', 'discover_time'):
            setattr(self, attr, max(0., getattr(self, attr) - dt))

    def _layer(self, size):
        if size != self.size:
            self.size = size
            self.layer = pygame.Surface(size, pygame.SRCALPHA)
            self.cache.clear()
        self.layer.fill((0, 0, 0, 0))
        return self.layer

    @staticmethod
    def _project(game, x, y, size):
        dx, dy = x - game.x, y - game.y
        depth = dx * math.cos(game.angle) + dy * math.sin(game.angle)
        if depth <= .2 or depth > 20.:
            return None
        side = -dx * math.sin(game.angle) + dy * math.cos(game.angle)
        sx = size[0] * (.5 + side / (depth * TAN_HALF) * .5)
        sy = size[1] * (.5 + game.pitch - .14 / depth)
        return int(sx), int(sy), depth

    def _world(self, game, now, reduce_flash):
        surface = self.layer
        w, h = self.size
        c = (154, 169, 130)
        scale = max(1, int(min(w, h) / 680))
        if game.cloak_clock > 0.:
            opacity = 16 if reduce_flash else 23
            surface.fill((16, 23, 21, opacity))
            for x in (int(w * .16), int(w * .84)):
                pygame.draw.line(surface, (*c, 52), (x, h // 3), (x, h * 2 // 3), 1)
            for i in range(3):
                yy = int(h * (.36 + i * .09))
                pygame.draw.line(surface, (*c, 22), (w // 2 - 44, yy), (w // 2 - 34, yy), 1)
                pygame.draw.line(surface, (*c, 22), (w // 2 + 34, yy), (w // 2 + 44, yy), 1)
        if game.listen_clock > 0. or self.listen_time > 0.:
            x = int(w * .5 + math.sin(game.listen_bearing) * min(w * .26, w * .22))
            y = int(h * .52)
            motion = int(now * 92)
            for n in range(3):
                radius = max(10, int(min(w, h) * (.018 + ((motion // 4 + n * 19) % 73) / 1900)))
                pygame.draw.arc(surface, (154, 171, 142, 45 + 18 * (2 - n)),
                                (x-radius*2, y-radius, radius*4, radius*2),
                                math.pi * .27, math.pi * .75, scale)
            pygame.draw.line(surface, (179, 186, 149, 140), (x-13,y), (x+13,y),1)
            pygame.draw.line(surface, (179, 186, 149, 130), (x,y-9), (x,y+9),1)
        if self.pulse_time > 0.:
            progress = 1. - self.pulse_time / .94
            radius = int(min(w, h) * (.045 + progress * .91))
            center = (w // 2, int(h * .57))
            color = (174, 191, 166, int((1.-progress) * (62 if reduce_flash else 128)))
            pygame.draw.ellipse(surface, color, (center[0] - radius, center[1] - radius // 2,
                                                 radius * 2, radius), max(1, scale*2))
            if not reduce_flash and progress < .13:
                pygame.draw.circle(surface, (201, 211, 169, int((.13-progress)*260)),
                                   center, max(3, int(radius*.32)))
        if game.echo_clock > 0. or self.echo_time > 0.:
            rate = (1. - self.echo_time / 1.7) if self.echo_time > 0. else (now * .15) % 1
            x = int(w * rate)
            pygame.draw.line(surface, (165, 172, 130, 66), (x, int(h*.15)), (x, int(h*.89)), 2)
            pygame.draw.line(surface, (165, 170, 129, 20), (x-15, int(h*.15)), (x-15, int(h*.89)), 14)
            for item in game.world.items:
                if not item['active'] or item['kind'] not in ('fragment', 'echo', 'note', 'relay', 'exit'):
                    continue
                point = self._project(game, item['x'], item['y'], self.size)
                if not point:
                    continue
                sx, sy, depth = point
                if -30 < sx < w + 30:
                    r = max(5, min(37, int(h * .12 / depth)))
                    a = 54 if game.world.visible(game.x, game.y, item['x'], item['y']) else 29
                    pygame.draw.rect(surface, (165, 168, 124, a), (sx-r,sy-r,r*2,r*2), max(1,scale))
        if self.hit_time > 0.:
            amount = self.hit_time / .28
            cx, cy = w//2, h//2
            dist = int(8 + 13*(1-amount))
            for dx,dy in ((-1,-1),(1,-1),(-1,1),(1,1)):
                pygame.draw.line(surface,(197,183,143,int(170*amount)),
                                 (cx+dx*dist,cy+dy*dist),(cx+dx*(dist+8),cy+dy*(dist+8)),2)
        if self.discover_time > 0.:
            p = self.discover_time / 1.25
            for side in (0,w-1):
                pygame.draw.line(surface,(151,147,107,int(60*p)),(side,h//4),(side,h*3//4),max(1,scale*2))

    def _atmosphere(self, game, now, reduce_flash):
        w,h=self.size
        if min(w,h)<260:
            return
        tension=max(0.,min(1.,game.horror.tension))
        dread=max(0.,min(1.,tension*.75+game.horror.shiver*.35+
                          max(0.,(52.-game.sanity)/120.)))
        for i in range(16):
            ratio=i/16.
            opacity=int((1.-ratio)**2 * (6.+37.*dread))
            band=max(1,int(w*.010))
            left=int(w*.013*i)
            pygame.draw.rect(self.layer,(3,9,9,opacity),(left,0,band,h))
            pygame.draw.rect(self.layer,(3,9,9,opacity),(w-left-band,0,band,h))
        if game.horror.phase in ('DOUBT','ANOMALY','APPROACH','AFTERSHOCK'):
            magnitude=(.14+.28*dread)*(1. if game.horror.phase=='APPROACH' else .63)
            for side in (-1,1):
                x=int(w*(.05 if side<0 else .95))
                for i in range(7):
                    yy=int(h*(.16+i*.112))
                    swing=int(math.sin(now*.41+side*2.+i*.76)*w*.006)
                    pygame.draw.arc(self.layer,(12,18,16,int(24*magnitude)),
                                    (x+side*swing-int(w*.049), yy-int(h*.08),
                                     int(w*.11),int(h*.23)),.3,2.5,1)
        if game.horror.kind in ('presence','breath','watch','reflection') and game.horror.duration>0.:
            power=min(1.,game.horror.duration/1.6)*(.28+.45*dread)
            if game.horror.sound_point:
                dx=game.horror.sound_point[0]-game.x
                dy=game.horror.sound_point[1]-game.y
                bearing=math.sin(math.atan2(dy,dx)-game.angle)
            else:
                bearing=math.sin(now*.27)
            cx=int(w*(.5+.49*bearing))
            for radius in range(2,7):
                offset=int(h*.041*radius)
                pygame.draw.arc(self.layer,(12,21,19,int(15*power)),
                                (cx-offset,int(h*.26)-offset//2,offset*2,int(h*.52)+offset),
                                .17,2.95,2)
        for i in range(26):
            u=(i*.61803398875+game.seed*.000011)%1.
            v=(i*.41421356237+game.seed*.000017)%1.
            x=int((u+math.sin(now*(.11+i%3*.025)+v*16.)*.007)*w)%w
            y=int((v+now*(.0018+(i%4)*.0009))%1.*h)
            strength=math.sin(now*.30+i*17.2)**2
            alpha=int((4.+18.*strength)*(1.-.55*dread))
            if alpha>5:
                pygame.draw.circle(self.layer,(178,178,147,alpha),(x,y),1)

    def _ballistics(self, game, now, reduce_flash):
        canvas = self.layer
        w, h = self.size
        for trace in game.tracers:
            alpha = max(0., min(1., trace['life'] / trace['duration']))
            x0, y0 = trace['x0'], trace['y0']
            x1, y1 = trace['x1'], trace['y1']
            other = self._project(game, x1, y1, self.size)
            start = (int(w * (.505 if game.aiming else .56)),
                     int(h * (.535 if game.aiming else .60)))
            end = (other[0], int(other[1] + h * .024)) if other else (w // 2, h // 2)
            travel = max(0., min(1., 1. - trace['life'] / trace['duration']))
            head = (int(start[0] + (end[0] - start[0]) * min(1., travel * 4.)),
                    int(start[1] + (end[1] - start[1]) * min(1., travel * 4.)))
            tail_ratio = max(0., travel * 4. - .48)
            tail = (int(start[0] + (end[0] - start[0]) * min(1., tail_ratio)),
                    int(start[1] + (end[1] - start[1]) * min(1., tail_ratio)))
            color = (141, 236, 188) if trace['weapon'] == 0 else (248, 174, 89)
            if not reduce_flash:
                pygame.draw.line(canvas, (*color, int(43 * alpha)), tail, head, max(4, int(13 * alpha)))
            pygame.draw.line(canvas, (*color, int(235 * alpha)), tail, head, max(1, int(3 * alpha)))
            if trace['hit'] and other:
                pygame.draw.circle(canvas, (*color, int(125 * alpha)), end, max(2, int(8 * alpha)))
        for projectile in game.projectiles:
            trail = []
            for x, y in projectile['tail']:
                point = self._project(game, x, y, self.size)
                if point is not None:
                    trail.append((point[0], int(point[1] + h * .017), point[2]))
            for i in range(1, len(trail)):
                a, b = trail[i - 1], trail[i]
                intensity = i / max(1, len(trail))
                pygame.draw.line(canvas, (235, 109, 49, int(160 * intensity)), a[:2], b[:2], max(1, int(5 * intensity)))
            if trail:
                sx, sy, depth = trail[-1]
                r = max(2, min(19, int(14 / max(.7, depth))))
                if not reduce_flash:
                    pygame.draw.circle(canvas, (255, 112, 54, 42), (sx, sy), r * 4)
                    pygame.draw.circle(canvas, (255, 169, 73, 87), (sx, sy), r * 2)
                pygame.draw.circle(canvas, (255, 222, 142, 248), (sx, sy), r)

    def _weapon(self, game, now, reduce_flash):
        phase = 1. - self.action_time / max(.001, self.action_length)
        self.meshes[game.weapon].render(self.layer, game, phase, self.action,
                                        self.action_time, min(self.flash_time, game.shot_flash), now,
                                        reduce_flash)

    def draw(self, screen, game, now, reduce_flash=False):
        self._layer(screen.get_size())
        self._world(game,now,reduce_flash)
        self._atmosphere(game,now,reduce_flash)
        self._ballistics(game, now, reduce_flash)
        self._weapon(game,now,reduce_flash)
        screen.blit(self.layer,(0,0))
