import argparse
import datetime
import collections
import ctypes
import faulthandler
import math
import os
from pathlib import Path

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
os.environ.setdefault('SDL_VIDEO_HIGHDPI', '1')

import pygame

from config import (AUTOSAVE_SECONDS, FPS_OPTIONS, WINDOW_MARGIN, WINDOW_MIN, WINDOW_TARGET,
                    WINDOW_FALLBACK_MIN, SESSION_HEARTBEAT_SECONDS, SIMULATION_HZ,
                    MAX_SIMULATION_STEPS, MAX_FRAME_SECONDS, RENDER_ADAPT_DOWN,
                    RENDER_ADAPT_UP, RENDER_ADAPT_DOWN_SECONDS, RENDER_ADAPT_UP_SECONDS,
                    BACKGROUND_FPS, BACKGROUND_RENDER_INTERVAL,
                    DEEP_SEED_MULTIPLIER, DEEP_SEED_INCREMENT, DEEP_SEED_DEPTH_SALT)
from controls import Controls, display_binding, token_for_key
from game import Game
from gpu import GPUBackend
from interface import Interface
from renderer import SceneRenderer
from procedural import art
from effects import VisualEffects
from sound import Soundscape
from storage import APP_VERSION, Storage, InstanceBusyError

class App:
    def __init__(self, root, safe_mode=False):
        self.storage = Storage(root)
        self.storage.acquire_instance()
        self.previous_crash = self.storage.start_session(safe_mode)
        self.safe_mode = bool(safe_mode or self.previous_crash)
        if self.safe_mode:
            self.storage.apply_session_settings({'gpu_scaling': False, 'quality': 'ECO',
                                                 'target_fps': min(45, self.storage.settings['target_fps'])})
        self.gpu = None
        self.gpu_blacklist = self.safe_mode
        self.gpu_error = ''
        pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
        pygame.init()
        pygame.display.set_caption('THE BACKROOMS — 低频回廊')
        try:
            pygame.display.set_icon(art('icon'))
        except (pygame.error, OSError):
            pass
        info = pygame.display.Info()
        width = max(WINDOW_FALLBACK_MIN[0],
                    min(max(WINDOW_MIN[0], int(info.current_w * WINDOW_TARGET[0])),
                        max(WINDOW_FALLBACK_MIN[0], info.current_w - WINDOW_MARGIN[0])))
        height = max(WINDOW_FALLBACK_MIN[1],
                     min(max(WINDOW_MIN[1], int(info.current_h * WINDOW_TARGET[1])),
                         max(WINDOW_FALLBACK_MIN[1], info.current_h - WINDOW_MARGIN[1])))
        self.window_size = (width, height)
        self.screen = self._create_display()
        self.clock = pygame.time.Clock()
        self.interface = Interface()
        self.interface.archive_count = self.storage.archive_count()
        self.interface.archive_stats = self.storage.archive_summary()
        self.controls = Controls(self.storage.settings)
        self.renderer = self.gpu or SceneRenderer(self.screen.get_size(), self.storage.settings['quality'])
        self.visual = VisualEffects()
        self.sound = Soundscape(self.storage.settings['volume'], on_warning=self.storage.log)
        saved = self.storage.load()
        self.has_save = bool(saved)
        self.has_previous = self.storage.previous_available()
        try:
            self.game = Game(saved=saved) if saved else Game(seed=20080326)
        except (ValueError, TypeError, KeyError):
            self.game = Game(seed=20080326)
        self._configure_game()
        self.state = 'MENU'
        self.settings_return = 'MENU'
        self.archive_return = 'MENU'
        self.diagnostics_return = 'MENU'
        self.settings_page = 0
        self.binding_wait = None
        self.running = True
        self.focused = True
        self.minimized = False
        self.save_clock = 0.
        self.heartbeat_clock = 0.
        self.resize_deadline = 0
        self.pause_reason = None
        self.quality_clock = 0.
        self.stable_clock = 0.
        self.fps_smoothed = 60.
        self.frame_times = []
        self.stall_events = collections.deque(maxlen=50)
        self.blocked_input_time = 0.
        self.simulation_accumulator = 0.
        self._mouse(False)
        self._initial_focus_handled = False
        self.storage.log(f'START v{APP_VERSION} window={width}x{height} gpu={bool(self.gpu)} safe={self.safe_mode}')
        if self.previous_crash:
            self.interface.notify('检测到上次意外退出：本次已启用兼容模式，可在设置中调整', 8.)
        elif self.safe_mode:
            self.interface.notify('兼容模式已启用 · 日志保存在游戏目录', 5.)
        elif self.gpu_error:
            self.interface.notify('显示驱动不支持当前 GPU 模式，已安全回退 CPU', 6.)

    def _focus_initial_window(self):
        if self._initial_focus_handled:
            return
        self._initial_focus_handled = True
        if os.name != 'nt':
            return
        try:
            info = pygame.display.get_wm_info()
            handle = int(info.get('window', 0) or 0)
            if not handle:
                self.storage.log('WINDOW_FIRST_FOCUS_MISSING_HANDLE')
                return
            user = ctypes.WinDLL('user32', use_last_error=True)
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            hwnd = ctypes.c_void_p(handle)
            user.ShowWindow.argtypes = (ctypes.c_void_p, ctypes.c_int)
            user.SetWindowPos.argtypes = (ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int,
                                          ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint)
            user.SetForegroundWindow.argtypes = (ctypes.c_void_p,)
            user.BringWindowToTop.argtypes = (ctypes.c_void_p,)
            user.GetForegroundWindow.restype = ctypes.c_void_p
            user.GetWindowThreadProcessId.argtypes = (ctypes.c_void_p, ctypes.c_void_p)
            user.GetWindowThreadProcessId.restype = ctypes.c_uint
            user.AttachThreadInput.argtypes = (ctypes.c_uint, ctypes.c_uint, ctypes.c_int)
            kernel.GetCurrentThreadId.restype = ctypes.c_uint
            user.FlashWindow.argtypes = (ctypes.c_void_p, ctypes.c_int)
            user.ShowWindow(hwnd, 9)
            flags = 0x0001 | 0x0002 | 0x0040
            user.SetWindowPos(hwnd, ctypes.c_void_p(-1), 0, 0, 0, 0, flags)
            previous = user.GetForegroundWindow()
            previous_thread = user.GetWindowThreadProcessId(previous, None) if previous else 0
            current_thread = kernel.GetCurrentThreadId()
            joined = bool(previous_thread and previous_thread != current_thread and
                          user.AttachThreadInput(previous_thread, current_thread, 1))
            try:
                user.BringWindowToTop(hwnd)
                user.SetForegroundWindow(hwnd)
            finally:
                user.SetWindowPos(hwnd, ctypes.c_void_p(-2), 0, 0, 0, 0, flags)
                if joined:
                    user.AttachThreadInput(previous_thread, current_thread, 0)
            visible = user.GetForegroundWindow() == handle
            if not visible:
                user.FlashWindow(hwnd, 1)
            self.storage.log('WINDOW_FIRST_FOCUS_' + ('VISIBLE' if visible else 'TASKBAR_FALLBACK'))
        except (OSError, ValueError, AttributeError, TypeError) as error:
            self.storage.log('WINDOW_FIRST_FOCUS_ERROR ' + type(error).__name__)

    def _configure_game(self):
        self.game.assist = self.storage.settings['assist']
        self.game.horror.intensity = self.storage.settings['horror_intensity'] * (1.16 if self.game.daily_rule == '警戒协议' else 1.)
        self.game.horror.preference = self.storage.archive_summary().get('profile', {})

    def _create_display(self):
        if self.gpu:
            try:
                self.gpu.close()
            except (OSError, RuntimeError, pygame.error) as error:
                self.storage.log(f'GPU_CLOSE_ERROR {type(error).__name__}')
        mode = self.storage.settings['display_mode']
        desktop = pygame.display.get_desktop_sizes()
        native = desktop[0] if desktop else (pygame.display.Info().current_w, pygame.display.Info().current_h)
        size = self.window_size if mode == 'windowed' else native
        flags = (pygame.RESIZABLE if mode == 'windowed' else
                 pygame.NOFRAME if mode == 'borderless' else pygame.FULLSCREEN) | pygame.DOUBLEBUF
        self.hardware_scaling = False
        self.gpu = None
        if self.storage.settings['gpu_scaling'] and not self.gpu_blacklist:
            try:
                pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 2)
                pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 1)
                pygame.display.set_mode(size, flags | pygame.OPENGL)
                actual_size = pygame.display.get_window_size()
                self.gpu = GPUBackend(actual_size, self.storage.settings['quality'])
                self.hardware_scaling = True
                self.gpu_error = ''
                self.storage.log('GPU_ACTIVE_OPENGL_SHADER ' + self.gpu.renderer_name)
                return pygame.Surface(actual_size, pygame.SRCALPHA)
            except (pygame.error, OSError, RuntimeError, AttributeError, ValueError, TypeError) as error:
                self.gpu_error = f'{type(error).__name__}: {str(error)[:180]}'
                self.gpu_blacklist = True
                self.storage.log('GPU_FALLBACK ' + self.gpu_error)
                self.gpu = None
        return pygame.display.set_mode(size, flags)

    def _reset_display(self):
        previous = self.renderer
        self.screen = self._create_display()
        if self.gpu:
            self.renderer = self.gpu
        elif isinstance(previous, SceneRenderer):
            self.renderer = previous
            previous.quality = self.storage.settings['quality']
            previous._resize(self.screen.get_size())
        else:
            self.renderer = SceneRenderer(self.screen.get_size(), self.storage.settings['quality'])
        self._mouse(self.state == 'PLAY' and self.focused and not self.minimized)
        self.storage.log(f'DISPLAY_MODE {self.storage.settings["display_mode"]} size={self.screen.get_size()} backend={"GPU" if self.gpu else "CPU"}')

    @staticmethod
    def _mouse(captured):
        pygame.event.set_grab(captured)
        pygame.mouse.set_visible(not captured)
        pygame.mouse.get_rel()

    def set_state(self, value):
        self.state = value
        self._mouse(value == 'PLAY' and self.focused and not self.minimized)

    def set_display_mode(self, mode):
        if mode not in ('windowed', 'borderless', 'exclusive'):
            return False
        previous = self.storage.settings['display_mode']
        if previous == mode:
            return True
        self.storage.settings['display_mode'] = mode
        self.storage.settings['fullscreen'] = mode != 'windowed'
        try:
            self._reset_display()
        except (pygame.error, RuntimeError, OSError, ValueError) as error:
            self.storage.log(f'DISPLAY_FAILED mode={mode} kind={type(error).__name__}')
            self.storage.settings['display_mode'] = previous
            self.storage.settings['fullscreen'] = previous != 'windowed'
            try:
                self.gpu_blacklist = True
                self._reset_display()
            except (pygame.error, RuntimeError, OSError, ValueError):
                self.running = False
                raise
            self.interface.notify('显示模式不兼容，已恢复窗口与兼容渲染。', 4.)
            return False
        self.storage.persist_settings()
        return True

    def toggle_fullscreen(self):
        current = self.storage.settings['display_mode']
        return self.set_display_mode('borderless' if current == 'windowed' else 'windowed')

    def start_new(self, daily=False):
        if self.has_save:
            if not self.storage.preserve_previous():
                self.interface.notify('无法安全备份当前调查，已取消新建。请检查存储空间。', 6.)
                self.storage.log('NEW_RUN_ABORTED_PREVIOUS_SAVE_UNSAFE')
                return
            self.has_previous = True
        if daily:
            date_code = int(datetime.date.today().strftime('%Y%m%d'))
            next_game = Game(seed=(date_code * 2654435761 + 0x42524C) & 0x7fffffff)
            next_game.mode = 'DAILY'
        else:
            next_game = Game()
        if not self.storage.save(next_game, durable=True):
            self.interface.notify('存档写入失败，新调查未启动。请检查游戏目录。', 6.)
            return
        self.game = next_game
        self.save_clock = 0.
        self.has_save = True
        self._configure_game()
        self.visual.reset()
        self.storage.log(f'NEW_RUN seed={self.game.seed} mode={self.game.mode}')
        self.interface.notify(('今日调查 · ' + self.game.daily_rule) if daily else '你已进入 LEVEL 0。')
        self.set_state('PLAY')
        self.sound.play('click', .65)

    def resume_save(self):
        data = self.storage.load()
        if not data:
            self.start_new()
            return
        try:
            self.game = Game(saved=data)
            self._configure_game()
            self.visual.reset()
            self.has_save = True
            self.storage.log(f'RESUMED seed={self.game.seed}')
            self.set_state('PLAY')
        except (ValueError, TypeError, KeyError) as error:
            self.storage.log_error(error)
            self.storage.preserve_previous()
            self.storage.clear_save()
            self.start_new()

    def resume_previous(self):
        if self.storage.restore_previous():
            self.has_previous = self.storage.previous_available()
            self.has_save = True
            self.resume_save()
            self.interface.notify('已恢复前一次调查，可继续探索。', 5.)
        else:
            self.interface.notify('未找到可恢复的前次存档。', 4.)

    def return_menu(self):
        if self.state in ('PAUSE', 'PLAY', 'MAP') and not self.game.won:
            if not self.storage.save(self.game, durable=True):
                self.interface.notify('调查未能安全保存，请检查磁盘空间或写入权限。', 6.)
                return
            self.has_save = True
        self.set_state('MENU')
        self.sound.play('click', .5)

    def blackbox(self):
        try:
            runtime = {'pygame': pygame.version.ver,
                       'sdl': '.'.join(str(p) for p in pygame.get_sdl_version()),
                       'display': list(self.screen.get_size()),
                       'video_driver': pygame.display.get_driver(),
                       'fps': round(self.fps_smoothed, 1),
                       'recent_frame_ms': [round(v * 1000, 1) for v in self.frame_times[-60:]],
                       'input_diagnostics': list(self.stall_events),
                       'render_width': self.renderer.view_size[0],
                       'rays': self.renderer.last_rays,
                       'audio_available': self.sound.enabled,
                       'quality': self.renderer.quality, 'hardware_scaling': self.hardware_scaling,
                       'focus': self.focused, 'backend': 'OPENGL_GPU_SHADER' if self.gpu else 'CPU_PYGAME',
                       'gpu_error': self.gpu_error, 'audio_error': self.sound.error,
                       'gpu_renderer': self.gpu.renderer_name if self.gpu else None,
                       'gpu_tier': self.renderer.auto_level if self.gpu else None,
                       'gpu_ui_upload_bytes': self.gpu.ui_upload_bytes if self.gpu else 0,
                       'storage_write_errors': self.storage._io_failed_total,
                       'audio_pending': self.sound._audio_queue.qsize()}
            target = self.storage.blackbox(self.game, runtime)
            self.interface.notify(f'黑匣子已存到桌面 · {target.name}', 5.)
            self.sound.play('pickup', .45)
        except OSError as error:
            self.interface.notify(f'黑匣子导出失败：{error}', 5.)
            self.storage.log(f'BLACKBOX_FAILED {type(error).__name__}')

    def set_gpu_mode(self, enabled):
        config = self.storage.settings
        previous = config['gpu_scaling']
        previous_approved = config['gpu_approved']
        config['gpu_scaling'] = bool(enabled)
        config['gpu_approved'] = True
        if enabled:
            self.gpu_blacklist = False
        try:
            self._reset_display()
            if enabled and not self.gpu:
                raise RuntimeError('requested GPU backend unavailable')
        except (pygame.error, RuntimeError, OSError, ValueError, AttributeError) as error:
            self.storage.log(f'GPU_SETTING_ROLLBACK {type(error).__name__}')
            config['gpu_scaling'] = previous
            config['gpu_approved'] = previous_approved
            try:
                self.gpu_blacklist = True
                self._reset_display()
            except (pygame.error, RuntimeError, OSError, ValueError, AttributeError):
                self.running = False
                raise
            if previous:
                config['gpu_scaling'] = False
                self.storage.commit_session_setting('gpu_scaling')
                self.storage.persist_settings()
            self.interface.notify('GPU 切换未成功，已启用稳定的兼容渲染。', 5.)
            return False
        self.storage.commit_session_setting('gpu_scaling')
        self.storage.commit_session_setting('gpu_approved')
        self.storage.persist_settings()
        self.interface.notify('已使用 GPU 加速画面' if enabled else '已切换兼容渲染', 3.)
        return True

    def change_setting(self, target):
        config = self.storage.settings
        if target == 'quality':
            values = ('AUTO', 'HIGH', 'ECO')
            config[target] = values[(values.index(config[target]) + 1) % len(values)]
            self.renderer.quality = config[target]
            if not self.gpu:
                self.renderer._resize(self.screen.get_size())
        elif target == 'volume':
            values = (0., .2, .4, .6, .8, 1.)
            current = min(range(len(values)), key=lambda i: abs(values[i] - config[target]))
            config[target] = values[(current + 1) % len(values)]
            self.sound.set_volume(config[target])
        elif target == 'sensitivity':
            values = (.0012, .0018, .0024, .0030, .0042)
            current = min(range(len(values)), key=lambda i: abs(values[i] - config[target]))
            config[target] = values[(current + 1) % len(values)]
        elif target == 'fullscreen':
            modes = ('windowed', 'borderless', 'exclusive')
            current = config['display_mode']
            self.set_display_mode(modes[(modes.index(current) + 1) % len(modes)])
            return
        elif target == 'reduce_flash':
            config[target] = not config[target]
        elif target == 'assist':
            config[target] = not config[target]
            self.game.assist = config[target]
        elif target == 'immersive_hud':
            config[target] = not config[target]
            self.game.hud_awake = 8.
        elif target == 'gpu_scaling':
            self.set_gpu_mode(not config[target])
            return
        elif target == 'horror_intensity':
            values = (.65, .85, 1.0, 1.25, 1.5)
            current = min(range(len(values)), key=lambda i: abs(values[i] - config[target]))
            config[target] = values[(current + 1) % len(values)]
            self.game.horror.intensity = config[target] * (1.16 if self.game.daily_rule == '警戒协议' else 1.)
        elif target == 'ui_scale':
            values = (.85, 1.0, 1.15, 1.30, 1.4)
            current = min(range(len(values)), key=lambda i: abs(values[i] - config[target]))
            config[target] = values[(current + 1) % len(values)]
        elif target == 'target_fps':
            index = FPS_OPTIONS.index(config[target]) if config[target] in FPS_OPTIONS else 2
            config[target] = FPS_OPTIONS[(index + 1) % len(FPS_OPTIONS)]
        else:
            return
        self.storage.commit_session_setting(target)
        self.storage.persist_settings()
        self.sound.play('click', .32)

    def action(self, value):
        if not value:
            return
        if value == 'quit':
            self.running = False
        elif value == 'continue':
            self.resume_save()
        elif value == 'new':
            self.start_new()
        elif value == 'previous':
            self.resume_previous()
        elif value == 'daily':
            self.start_new(daily=True)
        elif value == 'descend' and self.state == 'WON':
            previous_seed = self.game.seed
            depth = min(self.game.depth + 1, 999999)
            seed = (previous_seed * DEEP_SEED_MULTIPLIER + DEEP_SEED_INCREMENT
                    + depth * DEEP_SEED_DEPTH_SALT) & 0x7fffffff
            next_game = Game(seed=seed, depth=depth)
            if not self.storage.save(next_game, durable=True):
                self.interface.notify('无法保存下一层调查，请检查游戏文件夹。', 6.)
                return
            self.game = next_game
            self.has_save = True
            self._configure_game()
            self.visual.reset()
            self.storage.log(f'DESCEND depth={depth} seed={seed}')
            self.interface.notify(f'层级 {depth:02d} · {self.game.world.architecture}', 5.)
            self.set_state('PLAY')
        elif value == 'archive':
            self.archive_return = self.state
            self.interface.archive_stats = self.storage.archive_summary()
            self.set_state('ARCHIVE')
        elif value == 'archive_back':
            self.set_state(self.archive_return)
        elif value == 'resume':
            self.set_state('PLAY')
        elif value == 'menu':
            self.return_menu()
        elif value == 'settings':
            self.settings_return = self.state
            self.settings_page = 0
            self.interface.settings_offset = 0
            self.binding_wait = None
            self.set_state('SETTINGS')
        elif value == 'back':
            self.binding_wait = None
            self.set_state(self.settings_return)
        elif value == 'blackbox':
            self.blackbox()
        elif value == 'diagnostics':
            self.diagnostics_return = self.state
            self.interface.diagnostics = self.storage.blackbox_preview(self.game)
            self.set_state('DIAGNOSTICS')
        elif value == 'diagnostics_back':
            self.set_state(self.diagnostics_return)
        elif value.startswith('setting:'):
            self.change_setting(value[8:])
        elif value.startswith('page:'):
            self.settings_page = max(0, min(3, int(value[5:])))
            self.interface.settings_offset = 0
            self.binding_wait = None
            self.sound.play('click', .3)
        elif value.startswith('settings_scroll:'):
            self.interface.settings_offset = max(0, self.interface.settings_offset + int(value.rsplit(':', 1)[-1]))
        elif value.startswith('binding:'):
            self.binding_wait = value[8:]
            self.interface.notify('请按下要绑定的按键或鼠标按钮', 3.)
        elif value == 'reset_bindings':
            self.controls.reset()
            self.storage.persist_settings()
            self.interface.notify('已恢复所有默认按键')

    def _activate_game(self, action):
        if action == 'map':
            self.set_state('MAP')
            return
        if action == 'interact':
            result = self.game.interact()
            self.storage.log(f'INTERACT {result} fragments={self.game.fragments}')
            if result in ('fragment', 'cell', 'echo', 'note', 'relay'):
                self.sound.play('radio_distortion' if result == 'relay' else 'pickup', .55 if result == 'relay' else .72)
                self.visual.discovery()
                self.storage.save(self.game)
            elif result == 'won':
                completion = self.storage.record_completion(self.game)
                if completion is None:
                    self.game.won = False
                    self.interface.notify('调查结果尚未成功存档，暂不能离开。请检查存储空间。', 7.)
                    self.game.show_message('档案写入失败，出口暂时无法完成传输。', 6.)
                    return
                self.interface.archive_count = completion
                self.interface.archive_stats = self.storage.archive_summary()
                self.sound.play('door', .85)
                self.storage.log(f'WON seconds={int(self.game.elapsed)}')
                self.storage.clear_save()
                self.has_save = False
                self.set_state('WON')
        elif action == 'jump':
            if self.game.jump():
                self.sound.play('step', .15)
        elif action == 'switch':
            if self.game.switch_weapon() == 'switch':
                self.sound.play('click', .50)
                self.visual.weapon_action('switch', self.game.weapon)
        elif action == 'reload':
            if self.game.reload() == 'reload':
                self.sound.play('reload', .48)
                self.visual.weapon_action('reload', self.game.weapon)
        elif action in ('fire', 'heavy', 'melee'):
            before = self.game.ammo[self.game.weapon]
            result = self.game.attack('fire' if action == 'fire' else 'secondary' if action == 'heavy' else 'melee')
            if result != 'denied':
                kind = ('melee' if action == 'melee' else
                        'heavy' if action == 'heavy' and before == 0 else
                        'secondary' if action == 'heavy' else 'fire')
                if result != 'dry':
                    self.visual.weapon_action(kind, self.game.weapon, result == 'hit')
                if result == 'dry':
                    self.sound.play('click', .42)
                else:
                    self.sound.play('melee' if kind in ('melee', 'heavy') else
                                    'shot_emitter' if self.game.weapon == 0 else 'shot_flare',
                                    .41 if kind in ('melee', 'heavy') else .35 if self.game.weapon == 0 else .53)
                self.storage.log(f'ATTACK action={kind} result={result} ammo={self.game.ammo[self.game.weapon]}')
        elif action and action.startswith('skill'):
            result = self.game.skill(int(action[-1]) - 1)
            if result != 'denied':
                self.visual.skill(result)
                self.sound.play({'listen': 'skill_listen', 'pulse': 'skill_pulse',
                                 'cloak': 'skill_cloak', 'echo': 'skill_echo'}[result], .48)
                self.storage.log(f'SKILL effect={result}')

    def _events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.VIDEORESIZE and self.storage.settings['display_mode'] == 'windowed':
                info = pygame.display.Info()
                self.window_size = (max(WINDOW_FALLBACK_MIN[0], min(event.w, max(WINDOW_FALLBACK_MIN[0], info.current_w))),
                                    max(WINDOW_FALLBACK_MIN[1], min(event.h, max(WINDOW_FALLBACK_MIN[1], info.current_h))))
                self.resize_deadline = pygame.time.get_ticks() + 220
            elif event.type == pygame.WINDOWFOCUSLOST:
                self.focused = False
                self.sound.set_focus(False)
                if self.state == 'PLAY':
                    self.pause_reason = 'focus'
                self._mouse(False)
            elif event.type == pygame.WINDOWFOCUSGAINED:
                self.focused = True
                self.pause_reason = None
                self.sound.set_focus(True)
                self._mouse(self.state == 'PLAY' and not self.minimized)
                self.storage.log('FOCUS_RESTORED')
            elif event.type == pygame.WINDOWMINIMIZED:
                self.minimized = True
                self._mouse(False)
                self.sound.set_focus(False)
            elif event.type == pygame.WINDOWRESTORED:
                self.minimized = False
                self.sound.set_focus(self.focused)
                self._mouse(self.state == 'PLAY' and self.focused)
            elif event.type == pygame.KEYDOWN:
                if self.state == 'SETTINGS' and self.binding_wait:
                    if event.key == pygame.K_ESCAPE:
                        self.binding_wait = None
                        self.interface.notify('已取消按键修改', 2.)
                    elif not getattr(event, 'repeat', False):
                        self._rebind(token_for_key(event.key))
                    continue
                if event.key == pygame.K_F11 or (event.key == pygame.K_RETURN and event.mod & pygame.KMOD_ALT):
                    self.toggle_fullscreen()
                elif self.state == 'PLAY':
                    if event.key == pygame.K_ESCAPE:
                        self.storage.save(self.game)
                        self.set_state('PAUSE')
                    elif not getattr(event, 'repeat', False):
                        self._activate_game(self.controls.action_for_event(event))
                elif self.state == 'MAP':
                    if event.key == pygame.K_ESCAPE or self.controls.action_for_event(event) == 'map':
                        self.set_state('PLAY')
                elif self.state == 'PAUSE' and event.key == pygame.K_ESCAPE:
                    self.set_state('PLAY')
                elif self.state == 'SETTINGS' and event.key == pygame.K_ESCAPE:
                    self.set_state(self.settings_return)
                elif self.state == 'ARCHIVE' and event.key == pygame.K_ESCAPE:
                    self.set_state(self.archive_return)
                elif self.state == 'SETTINGS' and event.key in (pygame.K_DOWN, pygame.K_PAGEDOWN):
                    self.interface.settings_offset += 1 if event.key == pygame.K_DOWN else 4
                elif self.state == 'SETTINGS' and event.key in (pygame.K_UP, pygame.K_PAGEUP):
                    self.interface.settings_offset = max(0, self.interface.settings_offset - (1 if event.key == pygame.K_UP else 4))
                elif self.state == 'MENU' and event.key == pygame.K_RETURN:
                    self.action('continue' if self.has_save else 'new')
                elif self.state == 'WON' and event.key == pygame.K_RETURN:
                    self.start_new()
            elif event.type == pygame.MOUSEWHEEL and self.state == 'SETTINGS' and not self.binding_wait:
                self.interface.settings_offset = max(0, self.interface.settings_offset - event.y)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if self.state == 'SETTINGS' and self.binding_wait:
                    self._rebind(f'mouse{event.button}')
                elif self.state == 'PLAY':
                    self._activate_game(self.controls.action_for_event(event))
                elif event.button == 1:
                    self.action(self.interface.click(event.pos))
            elif event.type == pygame.MOUSEMOTION and self.state == 'PLAY' and self.focused:
                self.game.look(max(-110, min(110, event.rel[0])), self.storage.settings['sensitivity'],
                               max(-85, min(85, event.rel[1])))

    def _rebind(self, token):
        if self.controls.rebind(self.binding_wait, token):
            self.storage.persist_settings()
            self.interface.notify(f'已绑定为 {display_binding(token)}', 2.5)
            self.binding_wait = None
            self.sound.play('click', .45)
        else:
            self.interface.notify('此按键不可使用，请重试', 2.5)

    def _update(self, dt):
        if self.state == 'PLAY' and self.focused and not self.minimized:
            self.visual.update(dt)
        if self.resize_deadline and pygame.time.get_ticks() >= self.resize_deadline:
            self.resize_deadline = 0
            try:
                self._reset_display()
            except (pygame.error, RuntimeError, OSError, ValueError, AttributeError) as error:
                self.storage.log(f'RESIZE_FALLBACK {type(error).__name__}')
                self.gpu_blacklist = True
                self.storage.settings['gpu_scaling'] = False
                self.storage.settings['display_mode'] = 'windowed'
                self.storage.settings['fullscreen'] = False
                self._reset_display()
                self.storage.persist_settings()
                self.interface.notify('分辨率调整失败，已恢复兼容显示。', 5.)
        failures = self.storage.pop_io_errors()
        if failures:
            names = ', '.join(dict.fromkeys(name for name, reason in failures))
            self.interface.notify('存储写入失败：' + names + '。请检查磁盘空间或权限。', 7.)
        self.heartbeat_clock += dt
        if self.heartbeat_clock >= SESSION_HEARTBEAT_SECONDS:
            self.heartbeat_clock = 0.
            self.storage.heartbeat(self.game, 'OPENGL' if self.gpu else 'CPU', self.state)
        if self.state == 'PLAY' and self.focused and not self.minimized:
            keys = pygame.key.get_pressed()
            mouse = pygame.mouse.get_pressed(5)
            c = self.controls
            forward = int(c.pressed(keys, mouse, 'forward')) - int(c.pressed(keys, mouse, 'backward'))
            strafe = int(c.pressed(keys, mouse, 'right')) - int(c.pressed(keys, mouse, 'left'))
            running = c.pressed(keys, mouse, 'sprint')
            start_x, start_y = self.game.x, self.game.y
            events = self.game.update(dt, forward, strafe, running,
                                      crouch=c.pressed(keys, mouse, 'crouch'),
                                      aim=c.pressed(keys, mouse, 'aim'))
            movement = math.hypot(self.game.x - start_x, self.game.y - start_y)
            if (forward or strafe) and movement < .00001:
                self.blocked_input_time += dt
                if self.blocked_input_time >= .7:
                    self.stall_events.append({'time': round(self.game.elapsed, 2), 'type': 'collision_or_input',
                                              'position': [round(self.game.x, 2), round(self.game.y, 2)],
                                              'keys': [forward, strafe], 'focused': self.focused})
                    self.blocked_input_time = 0.
            else:
                self.blocked_input_time = 0.
            for value in events:
                if value == 'step':
                    self.sound.play('step', .28 if running else .17)
                elif value == 'spotted':
                    self.sound.play('stinger', .40)
                    self.storage.log('ENTITY_ALERT')
                elif value == 'presence':
                    self.sound.play('breath', .22)
                    self.storage.log('ENTITY_AWAKENED')
                elif value == 'caught':
                    self.sound.play('breath', .5)
                    self.storage.log(f'RECOVER checkpoint={self.game.recoveries}')
                elif value in ('pickup_fragment', 'pickup_cell', 'pickup_echo'):
                    self.sound.play('pickup', .65)
                    self.storage.save(self.game)
                    self.has_save = True
                elif value == 'auto_reload':
                    self.sound.play('reload', .35)
                    self.visual.weapon_action('reload', self.game.weapon)
                elif isinstance(value, dict) and value.get('type') == 'horror':
                    if value.get('sound'):
                        self.sound.play_at(value['sound'], value.get('intensity', .3),
                                           self.game, value.get('position'))
                    self.storage.log(f'HORROR {value.get("kind", "unknown")} consequence={value.get("consequence", "none")}')
            self.save_clock += dt
            if self.save_clock >= AUTOSAVE_SECONDS:
                self.storage.save(self.game)
                self.save_clock = 0.
        elif self.state == 'MENU' and self.focused:
            self.game.angle = (self.game.angle + dt * .09) % (2 * math.pi)
        self.sound.update(dt, self.game, self.state)
    def _measure_performance(self, real_dt):
        if real_dt <= 0 or not self.focused or self.minimized:
            return
        self.fps_smoothed = .94 * self.fps_smoothed + .06 * min(300., 1. / real_dt)
        if self.state == 'PLAY':
            if real_dt >= .14:
                if (real_dt >= .20 and self.storage.settings['quality'] == 'AUTO'
                        and self.renderer.auto_level > 0):
                    self.renderer.auto_level -= 1
                    if not self.gpu:
                        self.renderer._resize(self.screen.get_size())
                    self.quality_clock = 0.
                self.stall_events.append({'time': round(self.game.elapsed, 2), 'type': 'frame_stall',
                                          'frame_ms': round(real_dt * 1000, 1),
                                          'backend': 'gpu' if self.gpu else 'cpu', 'focused': self.focused})
            self.frame_times.append(real_dt)
            if len(self.frame_times) > 120:
                del self.frame_times[:len(self.frame_times) - 120]
        if self.storage.settings['quality'] != 'AUTO' or self.state != 'PLAY':
            self.quality_clock = 0.
            self.stable_clock = 0.
            return
        target = self.storage.settings['target_fps']
        if self.fps_smoothed < target * RENDER_ADAPT_DOWN:
            self.quality_clock += real_dt
            self.stable_clock = 0.
        elif self.fps_smoothed > target * RENDER_ADAPT_UP:
            self.stable_clock += real_dt
            self.quality_clock = 0.
        else:
            self.quality_clock = max(0., self.quality_clock - real_dt)
            self.stable_clock = max(0., self.stable_clock - real_dt)
        if self.quality_clock >= RENDER_ADAPT_DOWN_SECONDS:
            if self.renderer.auto_level > 0:
                self.renderer.auto_level -= 1
                if not self.gpu:
                    self.renderer._resize(self.screen.get_size())
            self.quality_clock = 0.
        elif self.stable_clock >= RENDER_ADAPT_UP_SECONDS:
            if self.renderer.auto_level < 4:
                self.renderer.auto_level += 1
                if not self.gpu:
                    self.renderer._resize(self.screen.get_size())
            self.stable_clock = 0.

    def render(self):
        now = pygame.time.get_ticks() / 1000
        try:
            self.renderer.draw(self.screen, self.game, now, self.storage.settings['reduce_flash'])
        except (pygame.error, RuntimeError, OSError, ValueError) as error:
            if not self.gpu:
                raise
            self.gpu_blacklist = True
            self.gpu_error = f'{type(error).__name__}: {str(error)[:180]}'
            self.storage.log('GPU_RUNTIME_FALLBACK ' + self.gpu_error)
            self._reset_display()
            self.renderer.draw(self.screen, self.game, now, self.storage.settings['reduce_flash'])
        if self.state == 'PLAY':
            self.visual.draw(self.screen, self.game, now, self.storage.settings['reduce_flash'])
        saved = self.has_save if self.state == 'MENU' else False
        self.interface.backend = 'GPU' if self.gpu else 'CPU'
        self.interface.has_previous = self.has_previous
        self.interface.draw(self.screen, self.game, self.state, saved, self.storage.settings,
                            self.fps_smoothed, self.controls, self.settings_page, self.binding_wait)
        if self.gpu:
            try:
                self.gpu.present(self.screen)
            except (pygame.error, RuntimeError, OSError, ValueError) as error:
                self.gpu_blacklist = True
                self.gpu_error = f'{type(error).__name__}: {str(error)[:180]}'
                self.storage.log('GPU_PRESENT_FALLBACK ' + self.gpu_error)
                self._reset_display()
                self.renderer.draw(self.screen, self.game, now, self.storage.settings['reduce_flash'])
                if self.state == 'PLAY':
                    self.visual.draw(self.screen, self.game, now, self.storage.settings['reduce_flash'])
                self.interface.draw(self.screen, self.game, self.state, saved, self.storage.settings,
                                    self.fps_smoothed, self.controls, self.settings_page, self.binding_wait)
                pygame.display.flip()
        else:
            pygame.display.flip()

    def run(self):
        fixed_step = 1. / SIMULATION_HZ
        normal_exit = False
        try:
            self.render()
            self._focus_initial_window()
            while self.running:
                cap = max(15, min(120, self.storage.settings['target_fps'])) if self.focused and not self.minimized else BACKGROUND_FPS
                wall_dt = max(0., self.clock.tick(cap) / 1000.)
                self._events()
                foreground = self.focused and not self.minimized
                self.simulation_accumulator += min(wall_dt, MAX_FRAME_SECONDS) if foreground else 0.
                updates = 0
                if not foreground:
                    self.simulation_accumulator = 0.
                    self._update(min(wall_dt, MAX_FRAME_SECONDS))
                else:
                    while self.simulation_accumulator >= fixed_step and updates < MAX_SIMULATION_STEPS:
                        self._update(fixed_step)
                        self.simulation_accumulator -= fixed_step
                        updates += 1
                if updates == MAX_SIMULATION_STEPS and self.simulation_accumulator >= fixed_step:
                    self.simulation_accumulator = min(self.simulation_accumulator, fixed_step)
                self._measure_performance(wall_dt)
                if not self.minimized and (self.focused or pygame.time.get_ticks() // int(BACKGROUND_RENDER_INTERVAL * 1000) != getattr(self, '_last_bg_frame', -1)):
                    self.render()
                    self._last_bg_frame = pygame.time.get_ticks() // int(BACKGROUND_RENDER_INTERVAL * 1000)
            normal_exit = True
        finally:
            if self.state in ('PLAY', 'PAUSE', 'MAP') and not self.game.won:
                self.storage.save(self.game)
            self.storage.persist_settings()
            self.storage.flush_writes()
            self.sound.close()
            if self.gpu:
                try:
                    self.gpu.close()
                except (OSError, RuntimeError, pygame.error):
                    pass
            if normal_exit:
                self.storage.end_session()
            pygame.quit()
            self.storage.release_instance()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default=str(Path(__file__).resolve().parent.parent))
    parser.add_argument('--smoke-test', action='store_true')
    parser.add_argument('--safe-mode', action='store_true')
    parser.add_argument('--gpu-test', action='store_true')
    parser.add_argument('--startup-probe', action='store_true')
    args = parser.parse_args()
    if args.smoke_test:
        from verify import check
        count = check(args.root)
        print('SMOKE_TEST_OK generated_art=%d generated_audio=%d' % (count[1],count[2]))
        return
    app = None
    crash_stream = None
    try:
        data = Path(args.root).resolve() / 'data'
        data.mkdir(parents=True, exist_ok=True)
        crash_path = data / 'crash.log'
        if crash_path.is_file() and crash_path.stat().st_size > 120_000:
            crash_path.write_bytes(crash_path.read_bytes()[-60_000:])
        crash_stream = crash_path.open('ab', buffering=0)
        faulthandler.enable(file=crash_stream, all_threads=True)
        app = App(args.root, safe_mode=args.safe_mode)
        if args.gpu_test or args.startup_probe:
            app.render()
            app.set_state('PLAY')
            app.render()
            print(('GPU_TEST_' if args.gpu_test else 'STARTUP_PROBE_') + ('GPU_OK' if app.gpu else 'CPU_OK'), flush=True)
            app.sound.close()
            if app.gpu:
                app.gpu.close()
            app.storage.end_session()
            pygame.quit()
            return
        app.run()
    except InstanceBusyError as error:
        if os.name == 'nt' and not args.smoke_test and not args.gpu_test:
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(None, str(error), 'THE BACKROOMS', 0x40)
            except (OSError, AttributeError):
                pass
        print('INSTANCE_ALREADY_RUNNING')
        return
    except BaseException as error:
        if app:
            app.storage.log_error(error)
        else:
            try:
                Storage(args.root).log_error(error)
            except OSError:
                pass
        try:
            pygame.quit()
        except Exception:
            pass
        if os.name == 'nt' and not args.smoke_test and not args.startup_probe and not args.gpu_test:
            try:
                import ctypes
                description = f'游戏遇到异常：{type(error).__name__}\n诊断日志位于游戏目录 data\\events.log。\n下次启动将自动尝试兼容模式。'
                ctypes.windll.user32.MessageBoxW(None, description, 'THE BACKROOMS · 异常恢复', 0x10)
            except (OSError, AttributeError):
                pass
        raise
    finally:
        if app is not None:
            app.storage.release_instance()
        if crash_stream:
            try:
                faulthandler.disable()
                crash_stream.close()
            except OSError:
                pass


if __name__ == '__main__':
    main()
