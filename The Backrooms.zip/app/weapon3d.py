import math
import random

import pygame


class WeaponMesh:
    def __init__(self, variant):
        self.variant = variant
        self.faces = []
        self.wires = []
        self.screws = []
        self.muzzle = (.25, -.12, 1.94) if variant == 0 else (.28, -.11, 2.12)
        self._assemble()

    def face(self, vertices, color, finish=.7):
        p, q, r = vertices[:3]
        a = (q[0] - p[0], q[1] - p[1], q[2] - p[2])
        b = (r[0] - p[0], r[1] - p[1], r[2] - p[2])
        normal = (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2],
                  a[0] * b[1] - a[1] * b[0])
        length = math.sqrt(sum(k * k for k in normal)) or 1.
        self.faces.append((vertices, color, tuple(k / length for k in normal), finish))

    def box(self, x, y, z, dx, dy, dz, color, finish=.72):
        a, b = x - dx * .5, x + dx * .5
        c, d = y - dy * .5, y + dy * .5
        e, f = z - dz * .5, z + dz * .5
        v = [(a, c, e), (b, c, e), (b, d, e), (a, d, e),
             (a, c, f), (b, c, f), (b, d, f), (a, d, f)]
        for ids in ((0, 3, 2, 1), (4, 5, 6, 7), (0, 4, 7, 3),
                    (1, 2, 6, 5), (3, 7, 6, 2), (0, 1, 5, 4)):
            self.face([v[i] for i in ids], color, finish)

    def beveled(self, x, y, z, dx, dy, dz, color, bevel=.045, finish=.82):
        a,b=x-dx*.5,x+dx*.5
        c,d=y-dy*.5,y+dy*.5
        edge=min(bevel,dx*.22,dy*.22)
        outline=((a+edge,c),(b-edge,c),(b,c+edge),(b,d-edge),
                 (b-edge,d),(a+edge,d),(a,d-edge),(a,c+edge))
        lower=[(xx,yy,z-dz*.5) for xx,yy in outline]
        upper=[(xx,yy,z+dz*.5) for xx,yy in outline]
        self.face(list(reversed(lower)),color,finish)
        self.face(upper,color,finish)
        for i in range(len(outline)):
            j=(i+1)%len(outline)
            self.face((lower[i],lower[j],upper[j],upper[i]),color,finish)

    def cylinder(self, x, y, start, end, radius, color, sides=12, finish=.8):
        rings = []
        for z in (start, end):
            rings.append([(x + math.cos(i * math.tau / sides) * radius,
                           y + math.sin(i * math.tau / sides) * radius, z) for i in range(sides)])
        self.face(list(reversed(rings[0])), color, finish)
        self.face(rings[1], color, finish)
        for i in range(sides):
            j = (i + 1) % sides
            self.face([rings[0][i], rings[0][j], rings[1][j], rings[1][i]], color, finish)

    def wire(self, points, color, radius=.012):
        self.wires.append((points, color, radius))

    def screw(self, x, y, z, radius=.010):
        self.screws.append((x, y, z, radius))

    def _assemble(self):
        dark = (47, 48, 44)
        gunmetal = (82, 84, 77)
        stainless = (130, 124, 108)
        black = (27, 30, 29)
        brass = (150, 112, 64)
        copper = (158, 88, 45)
        grime = (73, 62, 50)
        x = .27 if self.variant == 0 else .29
        self.beveled(x, -.19, .98, .31, .28, .65, gunmetal, .062, .91)
        self.beveled(x, -.16, .99, .282, .21, .59, (65,72,66), .045, .83)
        self.box(x, -.09, .85, .27, .035, .50, stainless, .91)
        self.box(x, -.30, .91, .33, .07, .61, black)
        self.box(x + .02, -.43, .77, .155, .38, .20, (59, 56, 48))
        self.box(x + .035, -.46, .70, .162, .30, .11, (32, 35, 33))
        self.box(x + .03, -.60, .76, .17, .046, .23, dark)
        self.box(x - .025, -.37, .95, .14, .026, .27, brass)
        self.box(x + .055, -.39, .96, .045, .10, .16, black)
        self.beveled(x + .03, -.24, .67, .27, .17, .21, (75, 69, 54), .043, .83)
        self.beveled(x + .03, -.24, .60, .22, .13, .09, (97, 83, 62), .025, .91)
        self.box(x, -.015, 1.00, .20, .028, .38, gunmetal)
        self.box(x, .018, .91, .04, .08, .03, stainless)
        self.box(x, -.015, 1.27, .11, .062, .04, black)
        self.box(x, .003, 1.45, .035, .042, .03, stainless)
        self.box(x - .166, -.188, 1.05, .026, .27, .26, grime)
        self.box(x + .168, -.184, 1.05, .027, .27, .26, grime)
        for i in range(7):
            z = .72 + i * .071
            self.box(x + .176, -.19, z, .009, .14, .024, (120, 118, 100))
            self.box(x - .176, -.19, z, .009, .14, .024, (107, 109, 94))
        self.cylinder(x, -.14, 1.17, 1.51, .092, dark, 12)
        if self.variant == 0:
            self.cylinder(x, -.14, 1.34, 1.90, .067, (71, 79, 71), 14)
            self.cylinder(x, -.14, 1.68, 1.94, .09, (36, 43, 42), 12)
            self.cylinder(x, -.14, 1.90, 1.965, .092, stainless, 12, .92)
            self.cylinder(x, -.14, 1.966, 1.981, .040, black, 12)
            for i in range(10):
                z = 1.30 + i * .057
                self.cylinder(x, -.14, z, z + .019, .117, copper if i % 2 else brass, 12, .87)
                self.cylinder(x, -.14, z + .005, z + .012, .08, black, 12)
            for yy in (-.28, -.18, -.08):
                self.box(x - .124, yy, 1.25, .038, .018, .44, stainless)
            self.box(x + .065, -.072, .83, .17, .11, .24, (53, 65, 57))
            self.box(x + .078, -.061, .825, .083, .012, .13, (142, 158, 127), 1.)
            self.wire([(x + .155, -.22, .78), (x + .20, -.24, 1.10),
                       (x + .15, -.19, 1.38), (x + .12, -.14, 1.75)], (154, 109, 54), .014)
            self.wire([(x - .15, -.23, .77), (x - .20, -.28, 1.12),
                       (x - .13, -.16, 1.61)], (74, 87, 75), .016)
        else:
            self.cylinder(x, -.13, 1.35, 2.105, .071, (47, 47, 44), 16, .9)
            self.cylinder(x, -.13, 1.62, 1.68, .087, brass, 16)
            self.cylinder(x, -.13, 2.075, 2.14, .099, stainless, 16)
            self.cylinder(x, -.13, 2.14, 2.16, .050, black, 16)
            self.box(x + .14, -.102, 1.4, .037, .06, .35, gunmetal)
            self.box(x - .145, -.102, 1.4, .039, .06, .35, gunmetal)
            self.box(x, -.13, .65, .35, .31, .11, (82, 71, 54))
            self.box(x, -.13, .60, .28, .25, .037, brass)
            self.box(x + .155, -.23, .82, .035, .20, .15, stainless)
            self.box(x - .17, -.20, 1.01, .04, .16, .24, stainless)
            for i in range(8):
                z = 1.13 + i * .058
                self.box(x, -.024, z, .13, .013, .019, gunmetal)
            self.wire([(x + .155, -.31, .91), (x + .14, -.39, .84), (x + .05, -.42, .81),
                       (x - .03, -.39, .85)], brass, .012)
        rnd = random.Random(1729 + self.variant)
        for _ in range(58):
            z = rnd.uniform(.67, 1.19)
            xx = x + rnd.choice((-1, 1)) * rnd.uniform(.157, .166)
            yy = rnd.uniform(-.285, -.07)
            self.box(xx, yy, z, .003, .003, rnd.uniform(.005, .014),
                     rnd.choice(((134, 127, 101), (34, 36, 32), (105, 72, 50))), .4)
        for z in (.76, 1.06, 1.14):
            self.cylinder(x + .175, -.22, z, z + .015, .012, black, 8)
        for side in (-1.,1.):
            xx=x+side*.176
            self.box(xx,-.175,.88,.016,.180,.42,(41,47,43),.91)
            for j in range(9):
                z=.690+j*.048
                self.box(xx+side*.010,-.150,z,.008,.075,.018,
                         (117,124,104) if j%3 else (38,42,39),.95)
            for z in (.71,.92,1.12):
                self.screw(xx+side*.011,-.222,z,.013)
        for j in range(6):
            z=.84+j*.057
            self.box(x,-.019,z,.19,.017,.017,(124,120,99),.98)
            self.box(x,.001,z,.12,.011,.009,(29,34,32),.70)
        self.cylinder(x,-.14,1.155,1.19,.132,(28,32,29),18)
        self.cylinder(x,-.14,1.188,1.219,.120,(130,123,98),18,.95)
        self.cylinder(x,-.14,1.22,1.24,.112,(44,47,42),18)
        for i in range(5):
            z=1.24+i*.12
            self.box(x+.138,-.142,z,.027,.057,.036,(113,110,91),.94)
            self.box(x-.139,-.142,z,.027,.057,.036,(86,91,78),.94)
            self.screw(x+.157,-.14,z,.007)
        self.box(x,.085,1.065,.10,.075,.29,(28,32,32),.92)
        self.box(x,.121,1.15,.065,.020,.12,(149,145,109),.97)
        self.box(x,.10,1.44,.034,.058,.045,(32,36,36),.94)
        self.box(x,.14,1.44,.010,.023,.012,(185,169,107),1.)
        for j in range(4):
            z=.77+j*.15
            self.box(x+.05,-.321,z,.132,.025,.023,(92,89,71),.76)
            self.box(x+.05,-.337,z,.105,.012,.015,(28,31,30),.91)
        self.wire(((x+.015,-.335,.81),(x+.062,-.417,.86),
                   (x+.078,-.446,.94),(x+.080,-.38,1.02)),(125,101,71),.014)
        self.box(x+.10,-.401,.87,.015,.09,.08,(20,23,22),.68)
        self.cylinder(x+.16,-.44,.41,.73,.092,(40,45,41),14,.62)
        self.cylinder(x+.15,-.44,.54,.70,.099,(73,75,64),14,.68)
        self.cylinder(x+.16,-.44,.66,.70,.103,(34,40,37),14,.60)
        self.beveled(x+.17,-.35,.64,.13,.044,.19,(95,91,75),.014,.83)
        for i in range(4):
            finger_x=x+.02+i*.067
            self.box(finger_x,-.55,.48,.048,.11,.28,(52,56,49),.57)
            self.cylinder(finger_x,-.56,.39,.56,.022,(58,62,55),8,.50)
            self.cylinder(finger_x,-.56,.49,.51,.023,(104,101,83),8,.85)
            self.box(finger_x,-.568,.62,.052,.045,.06,(36,40,35),.59)
        self.box(x+.035,-.432,.60,.10,.02,.20,(91,89,75),.88)
        for i in range(4):
            self.box(x-.128,-.43+i*.032,.55,.028,.007,.15,(94+i*7,92+i*5,76+i*3),.72)
        for j in range(20):
            z=.71+j*.026
            self.box(x+.165,-.31,z,.005,.009,.006,(20,24,21) if j%4 else (132,119,91),.6)

    @staticmethod
    def project(vertex, size, dx, dy, dz, pitch):
        x, y, z = vertex
        zz = z + dz
        if zz <= .12:
            return None
        sy = y + dy - .22 + z * .15 + (z - .8) * pitch
        scale = size[1] * .60 / zz
        return (int(size[0] * .5 + (x + dx + .30 - z*.19) * scale),
                int(size[1] * .60 - sy * scale), zz)

    def render(self, layer, game, phase, action, duration, flash, now, reduce_flash):
        w, h = layer.get_size()
        if w < 370 or h < 260:
            return
        bob = math.sin(game.walk_phase) * game.move_amount * .010
        sway = math.cos(game.walk_phase * .65) * game.move_amount * .009 + min(.018, game.turn_amount*.008)
        dx, dy, dz = sway, bob, 0.
        pitch = 0.
        if game.aiming:
            dx -= .24
            dy += .10
            dz += .10
        if duration > 0.:
            k = math.sin(math.pi * max(0., min(1., phase)))
            if action in ('fire', 'secondary'):
                dz -= (.24 if action == 'secondary' else .14) * math.sin(min(1., phase * 4.) * math.pi)
                pitch += .11 * k
            elif action == 'reload':
                dy -= .20 * k
                pitch -= .16 * k
            elif action in ('melee', 'heavy'):
                dy += .06 * k
                dz -= .13 * k
            elif action in ('switch', 'draw'):
                dy -= .24 * (1. - phase)
        darkness = 1.-min(.42,game.horror.blackout*.35)
        light = tuple(v*darkness for v in ((.86, .85, .73) if self.variant == 0 else (.97, .79, .62)))
        light_dir = (-.36, .82, -.38)
        projected = []
        for vertices, base, normal, finish in self.faces:
            points = [self.project(v, (w, h), dx, dy, dz, pitch) for v in vertices]
            if any(p is None for p in points):
                continue
            cx = sum(v[0] for v in vertices) / len(vertices) + dx
            cy = sum(v[1] for v in vertices) / len(vertices) + dy
            cz = sum(v[2] for v in vertices) / len(vertices) + dz
            facing = -(normal[0] * cx + normal[1] * cy + normal[2] * cz)
            if facing <= 0.:
                continue
            lambert = max(0., sum(normal[i] * light_dir[i] for i in range(3)))
            shine = max(0., -normal[2]) * .15
            specular = (lambert**6)*.24*finish
            amount = .54 + lambert * .74 + shine + specular + (flash * .40 if not reduce_flash else flash * .14)
            amount *= .92 + .08 * math.sin(now * .19)
            tint = tuple(min(255, max(0, int(channel * amount * light[i]))) for i, channel in enumerate(base))
            projected.append((sum(p[2] for p in points) / len(points), points, tint, finish))
        projected.sort(key=lambda item: item[0], reverse=True)
        for _, points, tint, finish in projected:
            pts = [(p[0], p[1]) for p in points]
            pygame.draw.polygon(layer, tint, pts)
            edge = tuple(max(0, int(channel * (.75 + finish * .12))) for channel in tint)
            if finish > .84 and len(pts) > 2:
                pygame.draw.aalines(layer, edge, True, pts)
        for points, color, width in self.wires:
            projected_points = [self.project(v, (w, h), dx, dy, dz, pitch) for v in points]
            if all(projected_points):
                coords = [(p[0], p[1]) for p in projected_points]
                px = max(1, int(width * h * .68 / max(.3, projected_points[0][2])))
                pygame.draw.lines(layer, (18, 18, 16), False, coords, px + 2)
                pygame.draw.lines(layer, color, False, coords, px)
        for xx,yy,zz,radius in self.screws:
            result=self.project((xx,yy,zz),(w,h),dx,dy,dz,pitch)
            if result:
                px,py,depth=result
                r=max(1,int(radius*h*.65/max(.2,depth)))
                pygame.draw.circle(layer,(18,21,20),(px,py),r+1)
                pygame.draw.circle(layer,(139,129,103),(px,py),r)
                pygame.draw.line(layer,(39,42,39),(px-r,py+r//2),(px+r,py-r//2),1)
        if duration>0. and action=='reload' and .16<phase<.91:
            magazine=self.project((.18,-.38,.72),(w,h),dx,dy-.10*phase,dz-.12*phase,pitch)
            if magazine:
                cx,cy,depth=magazine
                length=max(5,int(h*.16/max(.2,depth)))
                thick=max(3,int(length*.32))
                pygame.draw.polygon(layer,(19,23,22),((cx-thick,cy-length//2),
                                    (cx+thick,cy-length//2+3),(cx+thick+5,cy+length//2),
                                    (cx-thick,cy+length//2)))
                pygame.draw.line(layer,(120,108,84),(cx-thick,cy-length//3),
                                 (cx-thick,cy+length//3),2)
                pygame.draw.line(layer,(47,57,49),(cx,cy-length//2+4),
                                 (cx+3,cy+length//2-4),2)
        if duration>0. and action in ('fire','secondary') and .07<phase<.59:
            case=self.project((.43,-.09,1.13),(w,h),dx,dy,dz,pitch)
            if case:
                cx,cy,depth=case
                travel=(phase-.07)/.52
                cx+=int(w*.045*travel)
                cy-=int(h*(.085*travel-.06*travel*travel))
                radius=max(2,int(h*.013/max(.3,depth)))
                pygame.draw.ellipse(layer,(143,113,59),
                                    (cx-radius,cy-radius//2,radius*2,radius))
                pygame.draw.line(layer,(229,190,104),(cx-radius//2,cy-radius//2),
                                 (cx+radius//2,cy-radius//2),1)
        muzzle = self.project(self.muzzle, (w, h), dx, dy, dz, pitch)
        if muzzle and flash > .005:
            mx, my, _ = muzzle
            amount = min(1., flash / .14)
            color = (155, 228, 176) if self.variant == 0 else (255, 183, 93)
            radius = int(min(w, h) * .055 * amount)
            if not reduce_flash:
                pygame.draw.circle(layer, (*color, int(65 * amount)), (mx, my), radius * 3)
                pygame.draw.circle(layer, (*color, int(124 * amount)), (mx, my), radius * 2)
            pygame.draw.circle(layer, (*color, 255), (mx, my), max(2, radius // 2))
            for i in range(9):
                theta = math.tau * i / 9 + .23 * self.variant
                dxray = int(math.cos(theta) * radius * (1.4 + (i % 3) * .35))
                dyray = int(math.sin(theta) * radius * (1.2 + (i % 4) * .2))
                pygame.draw.line(layer, (*color, int(210 * amount)), (mx, my),
                                 (mx + dxray, my + dyray), 2)
