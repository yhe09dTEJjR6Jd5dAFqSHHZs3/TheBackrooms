import pygame

DEFAULT_BINDINGS = {
    'forward': 'w', 'backward': 's', 'left': 'a', 'right': 'd',
    'sprint': 'shift', 'crouch': 'ctrl', 'jump': 'space',
    'fire': 'mouse1', 'heavy': 'mouse2', 'aim': 'mouse3',
    'melee': 'e', 'reload': 'r', 'switch': 'f',
    'skill1': '1', 'skill2': '2', 'skill3': '3', 'skill4': '4',
    'interact': 'x', 'map': 'm',
}

BINDING_LABELS = {
    'forward': '前进', 'backward': '后退', 'left': '左移', 'right': '右移',
    'sprint': '冲刺', 'crouch': '蹲下', 'jump': '跳跃',
    'fire': '开火', 'heavy': '次要开火 / 重击', 'aim': '瞄准',
    'melee': '近战攻击', 'reload': '装弹', 'switch': '切换主 / 副武器',
    'skill1': '技能 1 · 倾听', 'skill2': '技能 2 · 脉冲',
    'skill3': '技能 3 · 静默', 'skill4': '技能 4 · 回声',
    'interact': '交互', 'map': '地图',
}

BINDING_PAGES = (
    ('移动', ('forward', 'backward', 'left', 'right', 'sprint', 'crouch', 'jump')),
    ('战斗', ('fire', 'heavy', 'aim', 'melee', 'reload', 'switch')),
    ('技能及探索', ('skill1', 'skill2', 'skill3', 'skill4', 'interact', 'map')),
)

RESERVED = {'escape', 'f11'}
SPECIAL = {
    'shift': (pygame.K_LSHIFT, pygame.K_RSHIFT),
    'ctrl': (pygame.K_LCTRL, pygame.K_RCTRL),
}


def display_binding(token):
    if token.startswith('mouse'):
        return {'mouse1': '鼠标左键', 'mouse2': '鼠标中键', 'mouse3': '鼠标右键',
                'mouse4': '鼠标侧键 1', 'mouse5': '鼠标侧键 2'}.get(token, token)
    return {'shift': 'Shift', 'ctrl': 'Ctrl', 'space': 'Space', 'tab': 'Tab',
            'return': 'Enter', 'backspace': 'Backspace'}.get(token, token.upper())


def token_for_key(key):
    if key in SPECIAL['shift']:
        return 'shift'
    if key in SPECIAL['ctrl']:
        return 'ctrl'
    return pygame.key.name(key).lower()


def valid_token(token):
    if not isinstance(token, str) or token in RESERVED:
        return False
    if token.startswith('mouse'):
        return token in ('mouse1', 'mouse2', 'mouse3', 'mouse4', 'mouse5')
    if token in SPECIAL:
        return True
    try:
        return pygame.key.key_code(token) > 0
    except (ValueError, pygame.error, TypeError):
        return False


class Controls:
    def __init__(self, settings):
        self.settings = settings
        incoming = settings.get('bindings', {})
        if not isinstance(incoming, dict):
            incoming = {}
        self.bindings = DEFAULT_BINDINGS.copy()
        for action, token in incoming.items():
            if action in DEFAULT_BINDINGS and valid_token(token) and token != self.bindings[action]:
                previous = self.bindings[action]
                other = next((name for name, bind in self.bindings.items() if bind == token and name != action), None)
                if other:
                    self.bindings[other] = previous
                self.bindings[action] = token
        self._sync()

    def _sync(self):
        self.settings['bindings'] = self.bindings.copy()

    def rebind(self, action, token):
        if action not in self.bindings or not valid_token(token):
            return False
        old = self.bindings[action]
        other = next((name for name, value in self.bindings.items() if value == token and name != action), None)
        if other:
            self.bindings[other] = old
        self.bindings[action] = token
        self._sync()
        return True

    def reset(self):
        self.bindings = DEFAULT_BINDINGS.copy()
        self._sync()

    def action_for_event(self, event):
        if event.type == pygame.KEYDOWN:
            token = token_for_key(event.key)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            token = f'mouse{event.button}'
        else:
            return None
        return next((action for action, value in self.bindings.items() if value == token), None)

    def pressed(self, keys, mouse, action):
        token = self.bindings[action]
        if token.startswith('mouse'):
            index = int(token[-1]) - 1
            return index < len(mouse) and bool(mouse[index])
        if token in SPECIAL:
            return any(keys[code] for code in SPECIAL[token])
        try:
            return bool(keys[pygame.key.key_code(token)])
        except (ValueError, pygame.error, IndexError):
            return False
