import collections
import math
import os
import random

import pygame

from config import (FOV, TAN_HALF, RAY_STEP_LIMIT, RENDER_MAX_WIDTH, RENDER_MIN_SIZE,
                    RENDER_SCALES, WALL_TINTS, RENDER_STRIP_CACHE_BYTES, RENDER_STRIP_CACHE_ENTRIES)

MEDIA = os.path.join(os.path.dirname(__file__), 'media')


class SceneRenderer:
    def __init__(self, screen_size, quality='AUTO'):
        self.textures = [pygame.image.load(os.path.join(MEDIA, name)).convert() for name in
                         ('wall.png', 'wall_stained.png', 'wall_aged.png', 'wall_damp.png', 'wall_faded.png')]
        self.items = {name: pygame.image.load(os.path.join(MEDIA, f'{name}.png')).convert_alpha()
                      for name in ('fragment', 'cell', 'echo', 'creature', 'exit', 'light', 'apparition', 'false_door')}
        self.masks = {name: pygame.image.load(os.path.join(MEDIA, f'mask_{name}.png')).convert_alpha()
                      for name in ('on', 'danger')}
        self.quality = quality
        self.auto_level = 2
        self.texture_size = self.textures[0].get_width()
        self.wall_tints = []
        for tex in self.textures:
            variants = []
            for level in range(WALL_TINTS):
                modified = tex.copy()
                luminance = int(38 + level * 18)
                modified.fill((min(255, luminance + 6), luminance, max(20, luminance - 17)),
                              special_flags=pygame.BLEND_RGB_MULT)
                variants.append(modified)
            self.wall_tints.append(variants)
        self.strips = collections.OrderedDict()
        self.strip_bytes = 0
        self._lamp_key = None
        self._floor_key = None
        self._floor_points = []
        self.size = (0, 0)
        self._resize(screen_size)
        self.last_rays = 0

    def _resize(self, screen_size):
        if (self.size == screen_size and self.quality == getattr(self, '_cached_quality', None)
                and self.auto_level == getattr(self, '_cached_level', None)):
            return
        self.size = screen_size
        self._cached_quality = self.quality
        width, height = screen_size
        self._cached_level = self.auto_level
        tier = 4 if self.quality == 'HIGH' else 0 if self.quality == 'ECO' else self.auto_level
        scene_width = max(RENDER_MIN_SIZE[0], min(RENDER_MAX_WIDTH, int(width * RENDER_SCALES[tier])))
        scene_width = min(width, scene_width)
        scene_height = max(RENDER_MIN_SIZE[1], int(scene_width * height / max(1, width)))
        scene_height = min(height, scene_height)
        self.view_size = scene_width, scene_height
        self.canvas = pygame.Surface(self.view_size).convert()
        self.depth = [1e5] * (scene_width // 2 + 2)
        self.halos = pygame.Surface(self.view_size, pygame.SRCALPHA)
        self.strips.clear()
        self.strip_bytes = 0
        self._lamp_key = None
        self._floor_key = None
        self.mask_scaled = {key: pygame.transform.smoothscale(surface, self.view_size)
                            for key, surface in self.masks.items()}
        self._create_grain()

    def _create_grain(self):
        rng = random.Random(338)
        w, h = self.view_size
        self.grains = []
        for _ in range(4):
            layer = pygame.Surface((w, h), pygame.SRCALPHA)
            for _ in range(int(w * h * .008)):
                v = rng.randint(13, 41)
                pygame.draw.rect(layer, (229, 220, 166, v), (rng.randrange(w), rng.randrange(h), 1, 1))
            self.grains.append(layer)

    def _project(self, game, x, y, z, horizon):
        dx = x - game.x
        dy = y - game.y
        forward = dx * math.cos(game.angle) + dy * math.sin(game.angle)
        sideways = -dx * math.sin(game.angle) + dy * math.cos(game.angle)
        if forward <= .15:
            return None
        w, h = self.view_size
        scale = h / forward
        px = int(w * .5 + sideways / (forward * TAN_HALF) * w * .5)
        py = int(horizon + (.52 - z) * scale)
        return px, py, forward

    def _fill_backdrop(self, game, now, horizon, reduce_flash=False):
        w, h = self.view_size
        zone = game.world.region(game.x, game.y)
        ceilings = ((59, 57, 40), (52, 60, 52), (49, 61, 58), (63, 58, 44), (43, 49, 43))
        carpets = ((56, 49, 28), (51, 48, 32), (38, 50, 46), (53, 48, 33), (39, 43, 34))
        flicker = 1. if reduce_flash else .965 + .035 * math.sin(now * 1.3 + game.seed % 10)
        if not reduce_flash and game.horror.flicker > 0:
            flicker *= 1. - .20 * game.horror.flicker
        for y in range(0, horizon, 3):
            ratio = y / max(1, horizon)
            v = (1.0 - ratio * .48) * flicker
            c = tuple(int(channel * v) for channel in ceilings[zone])
            pygame.draw.rect(self.canvas, c, (0, y, w, 3))
        for y in range(horizon, h, 3):
            ratio = (y - horizon) / max(1, h - horizon)
            v = (.6 + ratio * .21) * flicker
            pygame.draw.rect(self.canvas, tuple(int(channel * v) for channel in carpets[zone]), (0, y, w, 3))

    def _floor_grid(self, game, horizon):
        w, h = self.view_size
        x0 = int(game.x)
        y0 = int(game.y)
        for gy in range(y0 - 10, y0 + 11):
            for gx in range(x0 - 10, x0 + 11):
                if not game.world.is_floor(gx + .5, gy + .5):
                    continue
                for ax, ay, bx, by in ((gx, gy, gx + 1, gy), (gx, gy, gx, gy + 1)):
                    p = self._project(game, ax, ay, 0, horizon)
                    q = self._project(game, bx, by, 0, horizon)
                    if p and q and min(p[2], q[2]) < 9:
                        shade = max(10, int(43 - min(p[2], q[2]) * 3.4))
                        pygame.draw.line(self.canvas, (shade, max(0, shade - 5), max(0, shade - 18)), p[:2], q[:2], 1)
                    p = self._project(game, ax, ay, 1, horizon)
                    q = self._project(game, bx, by, 1, horizon)
                    if p and q and min(p[2], q[2]) < 10:
                        shade = max(10, int(73 - min(p[2], q[2]) * 5))
                        pygame.draw.line(self.canvas, (shade, shade, int(shade * .70)), p[:2], q[:2], 1)

    def _near_lamps(self, game):
        key = (int(game.x * 2), int(game.y * 2), game.seed, game.world.generation)
        if key != self._lamp_key:
            self._lamp_key = key
            self._lamps = [(x, y) for x, y in game.world.lights
                           if (x - game.x) ** 2 + (y - game.y) ** 2 < 121.
                           and game.world.visible(game.x, game.y, x, y)]
        return self._lamps

    def _floor_details(self, game, horizon):
        h = self.view_size[1]
        key = (int(game.x * 2), int(game.y * 2), game.seed, game.world.generation, game.world.revision)
        if self._floor_key != key:
            self._floor_key = key
            self._floor_points = []
            cx, cy = int(game.x), int(game.y)
            for iy in range(cy - 7, cy + 8):
                for ix in range(cx - 7, cx + 8):
                    if not game.world.is_floor(ix + .5, iy + .5):
                        continue
                    signature = (ix * 92821 + iy * 68917 + game.seed * 7919) & 0xffff
                    if signature % 13 > 2 or not game.world.visible(game.x, game.y, ix + .5, iy + .5):
                        continue
                    self._floor_points.append((ix + .5, iy + .5, signature))
        for x, y, signature in self._floor_points:
            hit = self._project(game, x, y, .02, horizon)
            if not hit:
                continue
            px, py, depth = hit
            if depth > 8.:
                continue
            radius_x = max(2, min(int(h * .16 / depth), int(h * .19)))
            radius_y = max(1, int(radius_x * .24))
            color = (27, 33, 24) if signature % 2 else (34, 37, 26)
            pygame.draw.ellipse(self.canvas, color,
                               (px - radius_x, py - radius_y, radius_x * 2, radius_y * 2))
            if signature % 5 == 0 and depth < 5.:
                pygame.draw.line(self.canvas, (57, 61, 39),
                                 (px - radius_x // 2, py), (px + radius_x // 3, py), 1)

    def _walls(self, game, now, horizon, reduce_flash=False):
        w, h = self.view_size
        px, py = game.x, game.y
        angle = game.angle
        cell_x, cell_y = int(px), int(py)
        grid = game.world.grid
        visible_lamps = self._near_lamps(game)
        column_width = 2
        cols = (w + column_width - 1) // column_width
        depth = self.depth
        if len(depth) < cols:
            depth = [1e5] * cols
            self.depth = depth
        for col in range(cols):
            column = col * column_width
            camera_x = (2 * (column + .5) / w - 1) * TAN_HALF
            ray_x = math.cos(angle) - math.sin(angle) * camera_x
            ray_y = math.sin(angle) + math.cos(angle) * camera_x
            map_x, map_y = cell_x, cell_y
            delta_x = abs(1 / ray_x) if abs(ray_x) > 1e-9 else 1e9
            delta_y = abs(1 / ray_y) if abs(ray_y) > 1e-9 else 1e9
            if ray_x < 0:
                step_x = -1
                side_x = (px - map_x) * delta_x
            else:
                step_x = 1
                side_x = (map_x + 1 - px) * delta_x
            if ray_y < 0:
                step_y = -1
                side_y = (py - map_y) * delta_y
            else:
                step_y = 1
                side_y = (map_y + 1 - py) * delta_y
            side = 0
            for _ in range(RAY_STEP_LIMIT):
                if side_x < side_y:
                    side_x += delta_x
                    map_x += step_x
                    side = 0
                else:
                    side_y += delta_y
                    map_y += step_y
                    side = 1
                if map_x < 0 or map_y < 0 or map_x >= game.world.width or map_y >= game.world.height or not grid[map_y][map_x]:
                    break
            perp = max(.08, (map_x - px + (1 - step_x) / 2) / ray_x if not side else
                       (map_y - py + (1 - step_y) / 2) / ray_y)
            depth[col] = perp
            projected_h = min(h * 5, max(1, int(h * 1.08 / perp)))
            top = int(horizon - projected_h * .48)
            wall_x = py + perp * ray_y if side == 0 else px + perp * ray_x
            wall_x -= math.floor(wall_x)
            texture_x = max(0, min(self.texture_size - 1, int(wall_x * self.texture_size)))
            if (side == 0 and ray_x > 0) or (side == 1 and ray_y < 0):
                texture_x = self.texture_size - texture_x - 1
            focus_width = .33 if game.aiming else .65
            flashlight_cone = max(0., 1. - (abs(camera_x) / focus_width) ** 1.65) ** .95
            flashlight_reach = 1. / (1. + (perp / (8.5 if game.aiming else 6.7)) ** 1.7)
            flashlight = .93 * flashlight_cone * flashlight_reach
            hit_x, hit_y = px + perp * ray_x, py + perp * ray_y
            lamp_light = 0.
            for lx, ly in visible_lamps:
                d2 = (lx - hit_x) ** 2 + (ly - hit_y) ** 2
                if d2 < 48.:
                    lamp_light += .32 / (1. + d2 * .32)
            lamp_light = min(.46, lamp_light)
            glow = 1. if reduce_flash else .975 + .025 * math.sin(now * .87 + map_x * .9 + map_y)
            if not reduce_flash and game.horror.flicker > 0.:
                glow *= 1. - game.horror.flicker * (.10 + .08 * abs(math.sin(now * 1.6)))
            glow *= 1. - game.horror.blackout * .58
            base_light = (.17 + flashlight + lamp_light * glow) * (.79 if side else 1.)
            level = max(0, min(WALL_TINTS - 1, int(base_light * (WALL_TINTS - 1))))
            texture_type = game.world.wall_style(map_x, map_y, len(self.wall_tints))
            if game.horror.warp > .2 and (map_x * 19 + map_y * 23 + game.seed) % 13 < game.horror.warp * 6.:
                texture_type = (texture_type + 1) % len(self.wall_tints)
            texture = self.wall_tints[texture_type][level]
            cache_key = (texture_type, level, texture_x, projected_h)
            wall_part = self.strips.get(cache_key)
            if wall_part is None:
                strip = texture.subsurface((texture_x, 0, 1, self.texture_size))
                wall_part = pygame.transform.scale(strip, (column_width, projected_h))
                allocation = wall_part.get_width() * wall_part.get_height() * wall_part.get_bytesize()
                if allocation <= RENDER_STRIP_CACHE_BYTES // 8:
                    while self.strips and (len(self.strips) >= RENDER_STRIP_CACHE_ENTRIES or
                                           self.strip_bytes + allocation > RENDER_STRIP_CACHE_BYTES):
                        _, previous = self.strips.popitem(last=False)
                        self.strip_bytes -= previous.get_width() * previous.get_height() * previous.get_bytesize()
                    self.strips[cache_key] = wall_part
                    self.strip_bytes += allocation
            else:
                self.strips.move_to_end(cache_key)
            self.canvas.blit(wall_part, (column, top))
        self.last_rays = cols

    def _billboard(self, game, surface, x, y, z, size, horizon, pulse=1.0):
        point = self._project(game, x, y, z, horizon)
        if not point:
            return
        px, py, forward = point
        w, h = self.view_size
        if forward > 20:
            return
        size_px = max(1, min(h * 3, int(h * size * pulse / forward)))
        size_x = max(1, int(size_px * surface.get_width() / surface.get_height()))
        if px + size_x < 0 or px - size_x > w:
            return
        if not game.world.visible(game.x, game.y, x, y) and forward > 1:
            return
        target = pygame.transform.scale(surface, (size_x, size_px))
        left = px - size_x // 2
        top = py - size_px // 2
        col_start = max(0, left // 2)
        col_end = min(len(self.depth), (left + size_x + 1) // 2)
        valid = [self.depth[i] > forward - .35 for i in range(col_start, col_end)]
        if not any(valid):
            return
        if all(valid):
            self.canvas.blit(target, (left, top))
            return
        for i in range(col_start, col_end):
            if not self.depth[i] > forward - .35:
                continue
            screen_x = i * 2
            source_x = max(0, screen_x - left)
            span = min(2, size_x - source_x)
            if span > 0:
                self.canvas.blit(target, (screen_x, top), (source_x, 0, span, size_px))

    def _entities(self, game, now, horizon, reduce_flash=False):
        sprites = []
        for x, y in game.world.lights:
            dist = math.hypot(x - game.x, y - game.y)
            if dist < 11:
                sprites.append((dist, self.items['light'], x, y, .95, .32, 1. if reduce_flash else 1. + .05 * math.sin(now * 1.2 + x)))
        for item in game.world.items:
            if not item['active']:
                continue
            dist = math.hypot(item['x'] - game.x, item['y'] - game.y)
            if dist < 16:
                sprites.append((dist, self.items[item['kind']], item['x'], item['y'], .33, .39,
                                .96 + .06 * math.sin(now * 3 + item['x'])))
        if game.exit_ready:
            dist = math.hypot(game.world.exit[0] - game.x, game.world.exit[1] - game.y)
            if dist < 18:
                sprites.append((dist, self.items['exit'], *game.world.exit, .5, 1.0, 1.0))
        if game.enemy_active:
            dist = math.hypot(game.enemy_x - game.x, game.enemy_y - game.y)
            if dist < 22:
                sprites.append((dist, self.items['creature'], game.enemy_x, game.enemy_y, .51, 1.06,
                                1 + .045 * math.sin(now * 7)))
        if game.shadow_active:
            dist = math.hypot(game.shadow_x - game.x, game.shadow_y - game.y)
            if dist < 16:
                shadow = self.items['apparition'].copy()
                shadow.set_alpha(135)
                sprites.append((dist, shadow, game.shadow_x, game.shadow_y, .53, 1.15, 1.))
        sprites.sort(reverse=True, key=lambda obj: obj[0])
        for distance, texture, x, y, z, size, pulse in sprites:
            self._billboard(game, texture, x, y, z, size, horizon, pulse)

    def _anomalies(self, game, now, horizon):
        anomaly = game.horror
        if anomaly.false_door and anomaly.duration > 0:
            self._billboard(game, self.items['false_door'], *anomaly.false_door,
                            .51, 1.3, horizon, 1.)
        if anomaly.ghost and anomaly.ghost_alpha > 0:
            phantom = self.items['apparition'].copy()
            phantom.set_alpha(int(230 * anomaly.ghost_alpha))
            self._billboard(game, phantom, *anomaly.ghost, .53, 1.3, horizon,
                            1. + .012 * math.sin(now * 8.))

    def _light_halos(self, game, now, horizon, reduce_flash=False):
        w, h = self.view_size
        fog = self.halos
        fog.fill((0, 0, 0, 0))
        for lx, ly in self._near_lamps(game):
            dist = math.hypot(lx - game.x, ly - game.y)
            if not .8 < dist < 10.:
                continue
            position = self._project(game, lx, ly, .94, horizon)
            if position is None:
                continue
            sx, sy, _ = position
            if sx < -50 or sx > w + 50 or sy < -50 or sy > h + 50:
                continue
            jitter = 1. if reduce_flash else .965 + .035 * math.sin(now * .93 + lx * 7)
            radius = max(4, min(int(53 / dist), 46))
            for scale, opacity in ((2.3, 8), (1.45, 14), (.75, 27)):
                pygame.draw.circle(fog, (204, 204, 137, int(opacity * jitter)),
                                   (sx, sy), max(2, int(radius * scale)))
        self.canvas.blit(fog, (0, 0))

    def _distortion(self, game, now, reduce_flash=False):
        w, h = self.view_size
        danger = game.enemy_distance if game.enemy_active else 1000
        intensity = min(1., max(0., (5 - danger) / 5) + max(0., (28 - game.sanity) / 75)
                        + max(0., game.anomaly - .26) * .36)
        if intensity < (.40 if reduce_flash else .17):
            return
        rng = random.Random(int(now * 14) + game.seed)
        for _ in range(int(1 + intensity * (2 if reduce_flash else 9))):
            y = rng.randrange(h)
            length = rng.randint(10, int(w * .6))
            x = rng.randrange(w)
            offset = rng.randint(-2, 2) if reduce_flash else rng.randint(-5, 5)
            if rng.random() > .75:
                pygame.draw.line(self.canvas, (84, 29, 28), (0, y), (w, y), 1)
            elif 0 <= x + offset < w:
                patch = self.canvas.subsurface(pygame.Rect(x, y, min(length, w-x, w-x-offset if offset > 0 else w-x), 1)).copy()
                self.canvas.blit(patch, (x + offset, y))

    def draw(self, screen, game, now, reduce_flash=False):
        current_size = screen.get_size()
        self._resize(current_size)
        w, h = self.view_size
        horizon = int(h * (.50 + game.pitch + .014 * math.sin(game.walk_phase) * min(1, game.move_amount)
                             + .014 * game.jump_height - (.025 if game.crouching else 0.)))
        self._fill_backdrop(game, now, horizon, reduce_flash)
        self._floor_grid(game, horizon)
        self._floor_details(game, horizon)
        self._walls(game, now, horizon, reduce_flash)
        self._entities(game, now, horizon, reduce_flash)
        self._anomalies(game, now, horizon)
        self._light_halos(game, now, horizon, reduce_flash)
        self.canvas.blit(self.mask_scaled['on'], (0, 0))
        if game.enemy_distance < 3 and game.enemy_active:
            danger = self.mask_scaled['danger'].copy()
            danger.set_alpha(min(145, int(200 / (game.enemy_distance + .5))))
            self.canvas.blit(danger, (0, 0))
        self._distortion(game, now, reduce_flash)
        if game.horror.blackout > 0.:
            shade = pygame.Surface(self.view_size, pygame.SRCALPHA)
            shade.fill((2, 4, 4, int(game.horror.blackout * 112)))
            self.canvas.blit(shade, (0, 0))
        self.canvas.blit(self.grains[0 if reduce_flash else int(now * 6) % len(self.grains)], (0, 0))
        if self.view_size != current_size:
            screen.blit(pygame.transform.scale(self.canvas, current_size), (0, 0))
        else:
            screen.blit(self.canvas, (0, 0))
