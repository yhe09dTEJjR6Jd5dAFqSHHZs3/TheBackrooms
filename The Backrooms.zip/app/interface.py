import math

import pygame

from controls import BINDING_LABELS, BINDING_PAGES, display_binding
from config import SETTINGS_MIN_ROW, SETTINGS_ROW_GAP

GOLD = (224, 202, 142)
WHITE = (236, 232, 207)
MUTED = (153, 164, 151)
MINT = (108, 226, 188)
RED = (235, 111, 101)
NIGHT = (14, 24, 24)


class Interface:
    def __init__(self):
        self.fonts = {}
        self.buttons = []
        self.toast = ''
        self.toast_until = 0.
        self.ui_clock = 0.
        self.panels = {}
        self.panel_bytes = 0
        self.shades = {}
        self.settings_offset = 0
        self.archive_stats = {}
        self.backend = 'CPU'
        self.ui_scale = 1.

    def font(self, pixels, bold=False):
        pixels = max(10, int(pixels))
        key = pixels, bool(bold)
        if key not in self.fonts:
            if len(self.fonts) >= 75:
                self.fonts.clear()
            self.fonts[key] = pygame.font.SysFont('microsoftyahei,segoeui,arialunicodems,arial', pixels, bold=bold)
        return self.fonts[key]

    def text(self, screen, content, x, y, pixels=18, color=WHITE, bold=False, align='left', shadow=False, max_width=None):
        if content is None or content == '':
            return None
        value = str(content)
        f = self.font(pixels, bold)
        if max_width and f.size(value)[0] > max_width:
            while value and f.size(value + '…')[0] > max_width:
                value = value[:-1]
            value += '…'
        bitmap = f.render(value, True, color)
        rect = bitmap.get_rect()
        if align == 'center':
            rect.midtop = (int(x), int(y))
        elif align == 'right':
            rect.topright = (int(x), int(y))
        else:
            rect.topleft = (int(x), int(y))
        if shadow:
            shade = f.render(value, True, (5, 8, 7))
            screen.blit(shade, rect.move(2, 2))
        screen.blit(bitmap, rect)
        return rect

    def panel(self, screen, rect, fill=(8, 16, 16, 208), line=(146, 152, 115, 80), radius=12):
        rect = pygame.Rect(rect)
        if rect.w < 2 or rect.h < 2:
            return
        radius = min(radius, rect.w // 2, rect.h // 2)
        key = (rect.w, rect.h, fill, line, radius)
        surf = self.panels.get(key)
        if surf is None:
            surf = pygame.Surface(rect.size, pygame.SRCALPHA)
            pygame.draw.rect(surf, fill, surf.get_rect(), border_radius=radius)
            if line:
                pygame.draw.rect(surf, line, surf.get_rect().inflate(-2, -2), 1, border_radius=radius)
            cost = rect.w * rect.h * 4
            if len(self.panels) >= 90 or self.panel_bytes + cost > 8 * 1024 * 1024:
                self.panels.clear()
                self.panel_bytes = 0
            if cost <= 8 * 1024 * 1024:
                self.panels[key] = surf
                self.panel_bytes += cost
        screen.blit(surf, rect.topleft)

    def button(self, screen, rect, label, action, secondary='', active=False, danger=False):
        rect = pygame.Rect(rect)
        if rect.w < 10 or rect.h < 10:
            return
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        accent = RED if danger else MINT if active else GOLD
        fill = (34, 53, 48, 235) if hovered or active else (12, 25, 24, 223)
        self.panel(screen, rect, fill, (*accent, 155 if hovered or active else 72), 8)
        pygame.draw.line(screen, accent, (rect.x + 2, rect.y + 8), (rect.x + 2, rect.bottom - 8), 2)
        fs = max(12, int(min(rect.h * .35, 19 * self.ui_scale)))
        self.text(screen, label, rect.x + 15, rect.y + (rect.h - fs) // 2 - 3,
                  fs, WHITE, bool(hovered or active), max_width=rect.w - 27 - (95 if secondary else 0))
        if secondary and rect.w >= 180:
            self.text(screen, secondary, rect.right - 10, rect.y + (rect.h - 11) // 2,
                      11, MINT if active else MUTED, align='right', max_width=105)
        self.buttons.append((rect, action))

    def click(self, position):
        for rect, action in reversed(self.buttons):
            if rect.collidepoint(position):
                return action
        return None

    def notify(self, message, seconds=4):
        self.toast = str(message)
        self.toast_until = pygame.time.get_ticks() / 1000 + seconds

    @staticmethod
    def line(screen, start, end, color=GOLD, width=1):
        pygame.draw.line(screen, color, tuple(int(a) for a in start), tuple(int(a) for a in end), width)

    def _shade(self, screen, alpha=206):
        key = (*screen.get_size(), alpha)
        shade = self.shades.get(key)
        if shade is None:
            shade = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
            shade.fill((5, 12, 13, alpha))
            if len(self.shades) > 12:
                self.shades.clear()
            self.shades[key] = shade
        screen.blit(shade, (0, 0))

    def _chrome(self, screen, w, h, s, title='LEVEL 0  /  LOCAL'):
        pad = max(16, int(w * .042))
        self.text(screen, 'B / R', pad, max(10, int(h * .025)), 19 * s, GOLD, True)
        if w > 740:
            self.line(screen, (pad + 70 * s, 35 * s), (w - pad, 35 * s), (105, 122, 98))
            self.text(screen, title, w - pad, 11 * s, 11 * s, MUTED, align='right')
        self.line(screen, (pad, h - 17 * s), (w - pad, h - 17 * s), (92, 108, 86))

    def _menu(self, screen, game, saved, s):
        w, h = screen.get_size()
        compact = h < 475
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(shade, (4, 10, 11, 217), (0, 0, int(w * .75), h))
        pygame.draw.rect(shade, (6, 14, 13, 118), (int(w * .75), 0, w, h))
        screen.blit(shade, (0, 0))
        self._chrome(screen, w, h, s, 'LEVEL 0  /  RECORDER IDLE')
        x = max(16, int(w * .065))
        y = max(22, int(h * (.105 if compact else .14)))
        fs = min((34 if compact else 49) * s, (w - 2 * x) / 14.8)
        self.text(screen, 'THE BACKROOMS', x, y, fs, WHITE, True, shadow=True)
        self.text(screen, '低 频 回 廊', x, y + (32 if compact else 60) * s,
                  (20 if compact else 30) * s, GOLD, True)
        if not compact:
            self.line(screen, (x, y + 111 * s), (x + 91 * s, y + 111 * s), MINT, 3)
            self.text(screen, '找回四段遗失录音，离开这层楼。', x, y + 134 * s, 16 * s, WHITE)
            self.text(screen, (f'已归档 {getattr(self, "archive_count", 0)} 次调查 · 每次空间都不相同'
                               if getattr(self, 'archive_count', 0) else
                               '录音缺失。无人回应。灯还亮着。'),
                      x, y + 161 * s, 13 * s, MUTED)
        else:
            self.text(screen, 'LEVEL 0  /  ' + game.investigation, x, y + 61 * s,
                      11 * s, MUTED, max_width=w - 2 * x)
        rows = [('继续调查', 'continue', 'RESUME'), ('新的调查', 'new', 'NEW RUN'),
                ('今日调查', 'daily', 'OFFLINE'), ('调查归档', 'archive', 'ARCHIVE'),
                ('画面与按键', 'settings', 'OPTIONS'), ('导出黑匣子', 'blackbox', 'ZIP'),
                ('离开设施', 'quit', 'EXIT')]
        if not saved:
            rows.pop(0)
        if getattr(self, 'has_previous', False):
            rows.insert(1 if saved else 0, ('找回上次调查', 'previous', 'RESTORE'))
        col_count = 2 if compact or (w >= 1160 and h < 700) else 1
        pad_right = max(12, int(w * .06))
        gap_x = max(7, 13 * s)
        left_width = (min((w - x - pad_right - gap_x) / 2, 430 * s)
                      if col_count == 2 else min(w * .69, 430 * s))
        count = (len(rows) + col_count - 1) // col_count
        top = max(y + (83 if compact else 190) * s, h * (.39 if compact else .50))
        row_gap = max(4, 7 * s)
        usable = max(60, h - top - (24 if compact else 37 * s))
        height = min(45 * s if compact else 54 * s,
                     max(23, (usable - (count - 1) * row_gap) / count))
        for i, (label, action, hint) in enumerate(rows):
            col, row = i // count, i % count
            bx = x + col * (left_width + gap_x)
            self.button(screen, (bx, top + row * (height + row_gap), left_width, height),
                        label, action, '' if compact else hint, active=(i == 0 and saved))
        if w > 1070 and not compact:
            rx = int(w * .72)
            self.panel(screen, (rx, h * .25, int(w * .21), h * .41),
                       (10, 24, 23, 180), (132, 170, 135, 84), 13)
            self.text(screen, f'RECOVERED / {game.fragments:02d}', rx + 17 * s, h * .28, 13 * s, MINT, True)
            for n in range(15):
                yy = h * .35 + n * 9.2 * s
                length = (51 + 37 * math.sin(n * 1.9 + self.ui_clock * .36)) * s
                self.line(screen, (rx + 20 * s, yy), (rx + 20 * s + length, yy),
                          MINT if n % 6 == 0 else (57, 109, 91), 2)
            self.text(screen, 'TRANSMISSION / ACTIVE', rx + 17 * s, h * .602, 11 * s, GOLD)

    def _hud(self, screen, game, s, settings, controls):
        w, h = screen.get_size()
        pad = max(12, int(w * .026))
        compact = (w < 580 or h < 410 or
                   (settings.get('immersive_hud', True) and game.elapsed > 18.
                    and game.hud_awake <= 0. and not game.near_item
                    and game.horror.tension < .42 and game.threat < .28))
        if compact:
            self.text(screen, f'REC · {game.fragments}/{game.total_fragments}', pad, pad, 12 * s,
                      (179, 178, 148), shadow=True)
        if game.fragments >= game.total_fragments and not game.exit_ready and game.message_time <= 0.:
            self.text(screen, game.mission_summary(), w / 2, h * .15,
                      12 * s, GOLD, True, 'center', True, w * .78)
        if not compact:
            self.panel(screen, (pad, pad, min(w * .35, 221 * s), 62 * s),
                       (8, 17, 17, 164), (142, 162, 124, 65))
            self.text(screen, f'RECORD   {game.fragments} / {game.total_fragments}',
                      pad + 12 * s, pad + 8 * s, 18 * s, GOLD, True)
            self.text(screen, f'{game.world.zone_name(game.x, game.y)}  ·  {int(game.elapsed // 60):02d}:{int(game.elapsed % 60):02d}',
                      pad + 12 * s, pad + 36 * s, 11 * s, MUTED)
        if not compact:
            bottom = h - 20 * s
            bar_w = min(255 * s, w * .31)
            bar_h = 87 * s
            self.panel(screen, (pad, bottom - bar_h, bar_w, bar_h), (7, 18, 18, 174), (111, 128, 96, 72))
            for i, (label, value, color) in enumerate((('能量', game.battery, GOLD),
                                                       ('体力', game.stamina, MINT),
                                                       ('意识', game.sanity, RED if game.sanity < 26 else WHITE))):
                yy = bottom - bar_h + (11 + i * 24) * s
                self.text(screen, label, pad + 11 * s, yy, 11 * s, WHITE)
                self.text(screen, f'{value:.0f}', pad + 61 * s, yy, 10 * s, color)
                rect = pygame.Rect(int(pad + 89 * s), int(yy + 4 * s), max(3, int(bar_w - 102 * s)), max(3, int(5 * s)))
                pygame.draw.rect(screen, (46, 57, 49), rect)
                if value > 0:
                    pygame.draw.rect(screen, color, (rect.x, rect.y, int(rect.w * min(100, value) / 100), rect.h))
            ammo = f'{game.ammo[game.weapon]:02d} / {game.reserve[game.weapon]:02d}'
            title = '干扰发射器' if game.weapon == 0 else '应急信号枪'
            bw = min(235 * s, w * .30)
            wx = w - pad - bw
            self.panel(screen, (wx, bottom - bar_h, bw, bar_h), (7, 18, 18, 172), (111, 128, 96, 72))
            self.text(screen, title, wx + 12 * s, bottom - bar_h + 9 * s, 13 * s, GOLD, True)
            self.text(screen, ammo, wx + 12 * s, bottom - bar_h + 36 * s, 18 * s, WHITE, True)
            if game.reload_clock > 0:
                self.text(screen, '装弹中…', wx + bw - 9 * s, bottom - bar_h + 36 * s,
                          11 * s, MINT, align='right')
            else:
                self.text(screen, f'{display_binding(controls.bindings["reload"])} 装弹 · {display_binding(controls.bindings["switch"])} 切换',
                          wx + 12 * s, bottom - bar_h + 65 * s, 10 * s, MUTED, max_width=bw - 22 * s)
            available = wx - (pad + bar_w) - 12 * s
            if available > 178 * s:
                skill_w = min(66 * s, (available - 15 * s) / 4)
                group_w = skill_w * 4 + 3 * 5 * s
                sx = pad + bar_w + (available - group_w) / 2
                for i, (name, left) in enumerate(zip(('倾听', '脉冲', '静默', '回声'), game.skill_cooldowns)):
                    xx = sx + i * (skill_w + 5 * s)
                    ready = left <= .01
                    self.panel(screen, (xx, bottom - 51 * s, skill_w, 51 * s),
                               (11, 32, 28, 188) if ready else (13, 22, 23, 161),
                               (108, 226, 188, 110) if ready else (90, 99, 91, 51), 6)
                    self.text(screen, f'{i + 1}', xx + 7 * s, bottom - 46 * s, 13 * s,
                              MINT if ready else MUTED, True)
                    self.text(screen, name if ready else f'{math.ceil(left)}s',
                              xx + skill_w / 2, bottom - 23 * s, 10 * s,
                              WHITE if ready else MUTED, align='center')
        cx, cy = w // 2, h // 2
        gap = 6 if game.aiming else 10
        for x0, y0, x1, y1 in ((-gap-7, 0, -gap, 0), (gap+7, 0, gap, 0),
                              (0, -gap-7, 0, -gap), (0, gap+7, 0, gap)):
            self.line(screen, (cx + x0 * s, cy + y0 * s), (cx + x1 * s, cy + y1 * s),
                      MINT if game.near_item or game.target_lock else (195, 202, 176), 2 if game.target_lock else 1)
        if game.target_lock:
            pygame.draw.circle(screen, (128, 216, 168), (cx, cy), max(7, int(13 * s)), 1)
        if game.near_item:
            label = {'fragment': '恢复录音', 'cell': '获取补给', 'echo': '记录异常', 'exit': '打开出口'}[game.near_item['kind']]
            pw = min(310 * s, w * .7)
            self.panel(screen, ((w - pw) / 2, h * .70, pw, 43 * s),
                       (8, 26, 23, 222), (101, 214, 164, 154))
            self.text(screen, f'[{display_binding(controls.bindings["interact"])}]  {label}',
                      cx, h * .709, 17 * s, MINT, True, 'center')
        bearing, strength, _ = game.signal()
        if w > 670:
            sx, sy = int(w - 59 * s), int(h - 166 * s)
            pygame.draw.circle(screen, (101, 134, 105), (sx, sy), max(23, int(31 * s)), 1)
            ux, uy = math.sin(bearing), -math.cos(bearing)
            self.line(screen, (sx, sy), (sx + ux * 23 * s, sy + uy * 23 * s),
                      MINT if strength > .40 else GOLD, 2)
            self.text(screen, f'{int(strength * 100)}%', sx, sy + 33 * s, 10 * s, MINT, align='center')
        if game.listen_clock > 0:
            r = max(22, int(30 * s))
            bx, by = int(w * .5), int(h * .61)
            self.panel(screen, (bx - 93 * s, by - 22 * s, 186 * s, 58 * s),
                       (8, 21, 21, 187), (123, 209, 165, 98), 10)
            self.text(screen, '方向监听', bx - 77 * s, by - 14 * s, 11 * s, MINT, True)
            self.text(screen, '近' if game.listen_distance < 7 else '中' if game.listen_distance < 15 else '远',
                      bx + 77 * s, by - 14 * s, 11 * s, MINT, align='right')
            cx2, cy2 = bx, by + 12 * s
            pygame.draw.circle(screen, (53, 99, 78), (int(cx2), int(cy2)), int(14 * s), 1)
            self.line(screen, (cx2, cy2),
                      (cx2 + 14 * s * math.sin(game.listen_bearing),
                       cy2 - 14 * s * math.cos(game.listen_bearing)), MINT, 2)
        if game.message_time > 0:
            self.text(screen, game.message, cx, h * .15, 15 * s, WHITE, True, 'center', True, w * .83)
        if game.tutorial > 0:
            direction = '/'.join(display_binding(controls.bindings[name]) for name in
                                 ('forward', 'left', 'backward', 'right'))
            self.text(screen, f'{direction} 移动 · {display_binding(controls.bindings["sprint"])} 冲刺 · '
                  f'{display_binding(controls.bindings["interact"])} 交互 · '
                  f'{display_binding(controls.bindings["map"])} 地图 · 鼠标操作武器',
                      cx, h * .90, 11 * s, WHITE, align='center', shadow=True, max_width=w - 30)
        if game.enemy_active and game.enemy_distance < 5 and game.horror.kind != 'silence':
            self.text(screen, '附近有东西正在移动', cx, h * .10, 12 * s, RED, True, 'center', True)
        if game.cloak_clock > 0 or game.listen_clock > 0 or game.echo_clock > 0:
            active = ' / '.join(name for name, active in (('倾听', game.listen_clock), ('静默', game.cloak_clock), ('回声', game.echo_clock)) if active)
            self.text(screen, active, w - pad, pad + 9 * s, 12 * s, MINT, align='right')

    def _map(self, screen, game, s, controls):
        self._shade(screen, 220)
        w, h = screen.get_size()
        self._chrome(screen, w, h, s, 'POSITION / RECONSTRUCTED')
        square = min(int((h - 108 * s) * .90), int(w * .63))
        cell = max(1, square // game.world.width)
        square = cell * game.world.width
        sx = (w - square) // 2
        sy = max(53, (h - square) // 2)
        self.panel(screen, (sx - 12, sy - 12, square + 24, square + 24),
                   (6, 18, 16, 241), (135, 174, 130, 120))
        for index in game.seen:
            x, y = index % game.world.width, index // game.world.width
            if 0 <= y < game.world.height:
                color = (54, 72, 60) if game.world.grid[y][x] else (21, 33, 27)
                pygame.draw.rect(screen, color, (sx + x * cell, sy + y * cell, cell, cell))
        for item in game.world.items:
            if item['active'] and int(item['y']) * game.world.width + int(item['x']) in game.seen:
                pygame.draw.circle(screen, MINT if item['kind'] == 'fragment' else (171, 149, 231) if item['kind'] == 'echo' else GOLD,
                                   (sx + int(item['x'] * cell), sy + int(item['y'] * cell)), max(2, cell // 3))
        if game.assist:
            game.signal()
            route = game._signal_cache[1] if game._signal_cache else []
            if route:
                every = max(1, len(route) // 140)
                for ix, iy in route[::every]:
                    pygame.draw.circle(screen, (84, 168, 134),
                                       (sx + int(ix * cell), sy + int(iy * cell)),
                                       max(1, cell // 5))
        if game.fragments == game.total_fragments:
            ex, ey = game.world.exit
            if int(ey) * game.world.width + int(ex) in game.seen:
                pygame.draw.circle(screen, MINT, (sx + int(ex * cell), sy + int(ey * cell)), max(3, cell), 2)
        px, py = sx + int(game.x * cell), sy + int(game.y * cell)
        rad = max(4, cell)
        pygame.draw.polygon(screen, WHITE,
                            [(px + math.cos(game.angle + da) * rad, py + math.sin(game.angle + da) * rad)
                             for da in (0, 2.5, -2.5)])
        self.text(screen, '测绘记录', max(16, w * .05), 63 * s, 23 * s, WHITE, True)
        self.text(screen, f'{len(game.seen)} 个已探索单元' + ('  ·  信号路径已显示' if game.assist else ''),
                  max(16, w * .05), 97 * s, 12 * s, MUTED)
        self.text(screen, (game.daily_rule + '  ·  ' if game.daily_rule else '') + game.mission_summary(), max(16, w * .05), 120 * s,
                  11 * s, GOLD, max_width=w * .88)
        self.text(screen, f'[{display_binding(controls.bindings["map"])} / ESC] 返回',
                  max(16, w * .05), h - 53 * s, 13 * s, MINT, True)

    def _modal(self, screen, title, description, rows, s, footer='', danger=False):
        w, h = screen.get_size()
        compact = h < 445
        self._shade(screen, 220)
        self._chrome(screen, w, h, s)
        cw = min(w * .88, 580 * s)
        x = (w - cw) / 2
        y = max(20 if compact else 47 * s, h * (.075 if compact else .12))
        panel_h = min(h - y - 14 * s, h * (.84 if compact else .78))
        self.panel(screen, (x, y, cw, panel_h), (11, 25, 23, 243), (140, 175, 135, 102), 15)
        self.text(screen, title, w / 2, y + (11 if compact else 28) * s,
                  (23 if compact else 29) * s, RED if danger else WHITE, True, 'center')
        self.text(screen, description, w / 2, y + (43 if compact else 80) * s,
                  12 * s if compact else 13 * s, MUTED, align='center', max_width=cw - 22 * s)
        start = y + (68 if compact else 129) * s
        reserve = (18 if compact else 39) * s
        gap = (4 if compact else 7) * s
        available = max(1, y + panel_h - start - reserve)
        bh = min(49 * s if compact else 54 * s,
                 max(21, (available - (len(rows) - 1) * gap) / max(1, len(rows))))
        for i, (label, action, hint) in enumerate(rows):
            self.button(screen, (x + 18 * s, start + i * (bh + gap), cw - 36 * s, bh),
                        label, action, '' if compact else hint,
                        active=i == 0, danger=danger and i == 0)
        if footer and not compact:
            self.text(screen, footer, w / 2, y + panel_h - 24 * s, 11 * s, MUTED, align='center')

    def _settings(self, screen, s, settings, fps, controls, page=0, binding_wait=None):
        w, h = screen.get_size()
        compact = w < 660 or h < 540
        self._shade(screen, 227)
        self._chrome(screen, w, h, s, 'SYSTEM / LOCAL OPTIONS')
        x = max(13, int(w * (.055 if compact else .10)))
        right = w - x
        title_y = max(22, h * (.085 if compact else .105))
        self.text(screen, '画面与控制', x, title_y, (25 if compact else 32) * s, WHITE, True)
        if w >= 560:
            self.text(screen, f'{fps:.0f} FPS  ·  立即应用', right, title_y + 10 * s,
                      11 * s, MINT, align='right')
        tab_y = max(50, h * (.19 if compact else .225))
        pages = ('画面', '移动', '战斗', '技能') if compact else ('画面与声音',) + tuple(group[0] for group in BINDING_PAGES)
        gap = max(3, 5 * s)
        tab_h = max(24, int(37 * s))
        tab_width = (right - x - gap * 3) / 4
        for i, title in enumerate(pages):
            self.button(screen, (x + i * (tab_width + gap), tab_y, tab_width, tab_h),
                        title, f'page:{i}', active=(page == i))
        top = tab_y + tab_h + max(5, 10 * s)
        footer_h = max(48, int(65 * s))
        bottom = h - footer_h
        if page == 0:
            entries = [('动态渲染', 'quality', {'AUTO': '智能', 'HIGH': '高画质', 'ECO': '省电'}[settings['quality']]),
                       ('音量', 'volume', f'{int(settings["volume"] * 100)}%'),
                       ('鼠标灵敏度', 'sensitivity', f'{settings["sensitivity"] / .0024:.1f}×'),
                       ('显示模式', 'fullscreen', '全屏' if settings['fullscreen'] else '窗口'),
                       ('舒适光效', 'reduce_flash', '开启' if settings['reduce_flash'] else '关闭'),
                       ('GPU 加速', 'gpu_scaling', ('GPU 运行中' if self.backend == 'GPU' else '回退 CPU') if settings['gpu_scaling'] else '仅 CPU'),
                       ('探索辅助', 'assist', '自动拾取 · 路线' if settings['assist'] else '手动探索'),
                       ('沉浸式 HUD', 'immersive_hud', '动态精简' if settings['immersive_hud'] else '完整显示'),
                       ('帧率上限', 'target_fps', f'{settings["target_fps"]} FPS'),
                       ('恐怖强度', 'horror_intensity', f'{settings["horror_intensity"]:.2f}×'),
                       ('界面比例', 'ui_scale', f'{settings["ui_scale"]:.2f}×'),
                       ('诊断预览', 'diagnostics', '查看脱敏内容')]
            actions = [(a, b if b == 'diagnostics' else f'setting:{b}', c) for a, b, c in entries]
        else:
            actions = [(BINDING_LABELS[key], f'binding:{key}',
                        '等待按键…' if binding_wait == key else display_binding(controls.bindings[key]))
                       for key in BINDING_PAGES[page - 1][1]]
            actions.append(('恢复默认按键', 'reset_bindings', '重置'))
        row_gap = max(3, int(SETTINGS_ROW_GAP * s))
        available = max(1, bottom - top)
        row_h = max(SETTINGS_MIN_ROW, min(int(46 * s), max(SETTINGS_MIN_ROW, int((available - 2 * row_gap) / 3))))
        visible = max(1, int((available + row_gap) // (row_h + row_gap)))
        last_offset = max(0, len(actions) - visible)
        self.settings_offset = max(0, min(self.settings_offset, last_offset))
        for local, (label, action, value) in enumerate(actions[self.settings_offset:self.settings_offset + visible]):
            y = top + local * (row_h + row_gap)
            self.text(screen, label, x + 2 * s, y + (row_h - 15 * s) / 2,
                      13 * s if compact else 14 * s, WHITE, max_width=(right - x) * .46)
            bx = x + (right - x) * .49
            self.button(screen, (bx, y, right - bx, row_h), value, action,
                        active=(binding_wait is not None and action == f'binding:{binding_wait}'))
        nav_y = h - max(41, 48 * s)
        nav_w = (right - x - 2 * gap) / 3
        if self.settings_offset > 0:
            self.button(screen, (x, nav_y, nav_w, max(27, 36 * s)), '上一组', 'settings_scroll:-1')
        if self.settings_offset < last_offset:
            self.button(screen, (x + nav_w + gap, nav_y, nav_w, max(27, 36 * s)),
                        '下一组', 'settings_scroll:+1')
        self.button(screen, (right - nav_w, nav_y, nav_w, max(27, 36 * s)),
                    '返回', 'back', '' if compact else 'ESC')
        if binding_wait and not compact:
            self.text(screen, '按下新按键或鼠标按钮 · Esc 取消', x, nav_y - 20 * s, 11 * s, MINT)

    def _archive(self, screen, s):
        self._shade(screen, 230)
        w, h = screen.get_size()
        self._chrome(screen, w, h, s, 'ARCHIVE / LOCAL')
        x = max(18, int(w * .09))
        width = w - 2 * x
        stats = self.archive_stats or {}
        compact = h < 500
        self.text(screen, '调查归档', x, max(27, int(h * .095)), 28 * s, WHITE, True)
        total = int(stats.get('total_runs', 0))
        endings = stats.get('endings', {})
        self.text(screen, f'累计调查 {total} 次   /   已发现结局 {len(endings)} 种',
                  x, max(68, int(h * .195)), 15 * s, MINT, True, max_width=width)
        best = stats.get('best_seconds')
        best_text = f'{int(best // 60)}分{int(best % 60)}秒' if isinstance(best, (float, int)) else '暂无记录'
        self.text(screen, f'最佳通关  {best_text}   ·   离线今日调查 {int(stats.get("daily_runs", 0))} 次',
                  x, max(93, int(h * .255)), 12 * s, MUTED, max_width=width)
        missions = stats.get('missions') or {}
        if missions and not compact:
            label = '  /  '.join(f'{name} {missions.get(key, 0)}' for key, name in
                                 (('TAPES', '录音'), ('ECHO', '旁证'), ('SURVEY', '测绘'),
                                  ('SIGNAL', '校准'), ('MIXED', '交叉')) if missions.get(key, 0))
            self.text(screen, label, x, max(120, int(h * .303)), 10 * s, GOLD, max_width=width)
        records = stats.get('runs', [])
        heading_y = max(120, int(h * .35))
        self.line(screen, (x, heading_y - 9 * s), (w - x, heading_y - 9 * s), GOLD, 1)
        self.text(screen, '最近记录', x, heading_y, 15 * s, WHITE, True)
        row_y = heading_y + 33 * s
        row_h = max(27, 33 * s)
        max_rows = max(0, int((h - 79 * s - row_y) // row_h))
        for i, record in enumerate(reversed(records[-max_rows:]) if max_rows else ()):
            label = str(record.get('ending', '未知'))[:14]
            timestamp = str(record.get('date', ''))[:10]
            try:
                seconds = float(record.get('seconds', 0))
                seconds = seconds if math.isfinite(seconds) and seconds >= 0 else 0.
            except (ValueError, TypeError, OverflowError):
                seconds = 0.
            text = f'{timestamp}  ·  {label}  ·  {int(seconds // 60)}m'
            self.text(screen, text, x + 8 * s, row_y + i * row_h,
                      12 * s, GOLD if i % 2 == 0 else MUTED, max_width=width - 15 * s)
        if not records:
            self.text(screen, '没有找到已完成的调查。', x + 8 * s, row_y, 13 * s, MUTED)
        self.button(screen, (w - x - max(105, 135 * s), h - max(48, 57 * s),
                             max(105, 135 * s), max(28, 38 * s)), '返回', 'archive_back')

    def _diagnostics(self, screen, s):
        self._shade(screen, 231)
        w, h = screen.get_size()
        self._chrome(screen, w, h, s, 'DIAGNOSTICS / REDACTED')
        x = max(16, int(w * .085))
        info = getattr(self, 'diagnostics', {})
        self.text(screen, '黑匣子预览', x, h * .12, 29 * s, WHITE, True)
        files = info.get('files', [])
        self.text(screen, f'将打包 {len(files)} 项诊断内容 · {int(info.get("estimated_bytes", 0) / 1024)} KB 未压缩文本',
                  x, h * .25, 13 * s, MINT, max_width=w - 2 * x)
        self.text(screen, '配置、渲染状态、事件与崩溃记录已进行敏感字段遮盖',
                  x, h * .31, 12 * s, MUTED, max_width=w - 2 * x)
        panel_y = h * .40
        panel_h = max(54, min(h * .29, 155 * s))
        self.panel(screen, (x, panel_y, w - 2 * x, panel_h), (7, 18, 19, 201), (110, 151, 129, 89), 7)
        recent = info.get('recent', [])
        if recent:
            row_h = min(27 * s, panel_h / max(1, len(recent)))
            for index, line in enumerate(recent[-4:]):
                self.text(screen, str(line)[:145], x + 13 * s, panel_y + 9 * s + index * row_h,
                          11 * s, MUTED, max_width=w - 2 * x - 24 * s)
        else:
            self.text(screen, '尚无最近事件记录', x + 13 * s, panel_y + 15 * s, 12 * s, MUTED)
        bw = min(245 * s, (w - 2 * x - 12 * s) / 2)
        bottom = h - max(66, 77 * s)
        self.button(screen, (x, bottom, bw, max(35, 45 * s)), '导出到桌面', 'blackbox', active=True)
        self.button(screen, (x + bw + 12 * s, bottom, bw, max(35, 45 * s)),
                    '返回', 'diagnostics_back')

    def draw(self, screen, game, state, saved, settings, fps, controls, settings_page=0, binding_wait=None):
        self.buttons = []
        w, h = screen.get_size()
        s = max(.59, min(2.2, min(w / 1200, h / 720) * settings.get('ui_scale', 1.)))
        self.ui_scale = s
        self.ui_clock = pygame.time.get_ticks() / 1000
        if state == 'MENU':
            self._menu(screen, game, saved, s)
        elif state == 'PLAY':
            self._hud(screen, game, s, settings, controls)
        elif state == 'MAP':
            self._map(screen, game, s, controls)
        elif state == 'PAUSE':
            self._modal(screen, '已 暂 停', '周围的灯光仍然在运作。',
                        [('返回现场', 'resume', 'ESC'), ('保存并返回主界面', 'menu', 'SAVE'),
                         ('画面与按键', 'settings', 'OPTIONS'), ('导出黑匣子', 'blackbox', '< 1 MB')], s)
        elif state == 'ARCHIVE':
            self._archive(screen, s)
        elif state == 'DIAGNOSTICS':
            self._diagnostics(screen, s)
        elif state == 'SETTINGS':
            self._settings(screen, s, settings, fps, controls, settings_page, binding_wait)
        elif state == 'WON':
            self._modal(screen, f'结 局 / {game.ending}', f'四段录音已归档 · 耗时 {int(game.elapsed // 60)} 分钟',
                        [('再次进入', 'new', 'NEW RUN'), ('返回主界面', 'menu', 'ARCHIVE'),
                         ('导出黑匣子', 'blackbox', 'DIAGNOSTICS')], s,
                        '你无法确定自己是否真的离开。')
        if self.toast and self.ui_clock < self.toast_until:
            cw = min(w - 28, self.font(13 * s).size(self.toast)[0] + 36 * s)
            self.panel(screen, ((w - cw) / 2, 43 * s, cw, 37 * s),
                       (13, 35, 28, 236), (113, 225, 178, 150))
            self.text(screen, self.toast, w / 2, 52 * s, 13 * s, MINT, True, 'center', max_width=cw - 16 * s)
