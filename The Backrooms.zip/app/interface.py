import math

import pygame

from controls import BINDING_LABELS, BINDING_PAGES, display_binding
from config import SETTINGS_MIN_ROW, SETTINGS_ROW_GAP, GUIDANCE_DELAY, DIALOG_SAFE_MARGIN

GOLD = (171, 154, 109)
WHITE = (213, 208, 181)
MUTED = (138, 138, 119)
MINT = (164, 164, 130)
RED = (158, 86, 73)
NIGHT = (19, 23, 21)


class Interface:
    def __init__(self):
        self.fonts = {}
        self.buttons = []
        self.toast = ''
        self.toast_until = 0.
        self.ui_clock = 0.
        self.panels = {}
        self.panel_bytes = 0
        self.shades = {}
        self.settings_offset = 0
        self.archive_stats = {}
        self.backend = 'CPU'
        self.ui_scale = 1.
        self.depth = 0

    def font(self, pixels, bold=False):
        pixels = max(10, int(pixels))
        key = pixels, bool(bold)
        if key not in self.fonts:
            if len(self.fonts) >= 75:
                self.fonts.clear()
            self.fonts[key] = pygame.font.SysFont('microsoftyahei,segoeui,arialunicodems,arial', pixels, bold=bold)
        return self.fonts[key]

    def text(self, screen, content, x, y, pixels=18, color=WHITE, bold=False, align='left', shadow=False, max_width=None):
        if content is None or content == '':
            return None
        value = str(content)
        f = self.font(pixels, bold)
        if max_width and f.size(value)[0] > max_width:
            while value and f.size(value + '…')[0] > max_width:
                value = value[:-1]
            value += '…'
        bitmap = f.render(value, True, color)
        rect = bitmap.get_rect()
        if align == 'center':
            rect.midtop = (int(x), int(y))
        elif align == 'right':
            rect.topright = (int(x), int(y))
        else:
            rect.topleft = (int(x), int(y))
        if shadow:
            shade = f.render(value, True, (5, 8, 7))
            screen.blit(shade, rect.move(2, 2))
        screen.blit(bitmap, rect)
        return rect

    def panel(self, screen, rect, fill=(18, 22, 21, 202), line=(140, 138, 111, 73), radius=1):
        rect = pygame.Rect(rect)
        if rect.w < 2 or rect.h < 2:
            return
        radius = min(2, radius, rect.w // 2, rect.h // 2)
        key = (rect.w, rect.h, fill, line, radius)
        surf = self.panels.get(key)
        if surf is None:
            surf = pygame.Surface(rect.size, pygame.SRCALPHA)
            pygame.draw.rect(surf, fill, surf.get_rect(), border_radius=radius)
            if line:
                pygame.draw.rect(surf, line, surf.get_rect().inflate(-2, -2), 1, border_radius=radius)
            cost = rect.w * rect.h * 4
            if len(self.panels) >= 90 or self.panel_bytes + cost > 8 * 1024 * 1024:
                self.panels.clear()
                self.panel_bytes = 0
            if cost <= 8 * 1024 * 1024:
                self.panels[key] = surf
                self.panel_bytes += cost
        screen.blit(surf, rect.topleft)

    def button(self, screen, rect, label, action, secondary='', active=False, danger=False):
        rect = pygame.Rect(rect)
        if rect.w < 10 or rect.h < 10:
            return
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        if hovered or active:
            self.panel(screen, rect, (43, 43, 35, 231) if hovered else (34, 36, 31, 207), None, 0)
        else:
            self.panel(screen, rect, (18, 22, 20, 137), None, 0)
        accent = RED if danger else WHITE if hovered else GOLD if active else MUTED
        pygame.draw.line(screen, (87, 86, 72), (rect.left + 9, rect.bottom - 1), (rect.right - 9, rect.bottom - 1), 1)
        if hovered or active:
            pygame.draw.line(screen, accent, (rect.left + 4, rect.top + 6), (rect.left + 4, rect.bottom - 6), 2)
        fs = max(12, int(min(rect.h * .37, 19 * self.ui_scale)))
        self.text(screen, label, rect.x + 17, rect.y + (rect.h - fs) // 2 - 3,
                  fs, WHITE if hovered or active else (183, 181, 156), bool(active),
                  max_width=rect.w - 28 - (93 if secondary else 0))
        if secondary and rect.w >= 210:
            self.text(screen, secondary, rect.right - 14, rect.y + (rect.h - 11) // 2,
                      11, MUTED, align='right', max_width=88)
        self.buttons.append((rect, action))

    def click(self, position):
        for rect, action in reversed(self.buttons):
            if rect.collidepoint(position):
                return action
        return None

    def notify(self, message, seconds=4):
        self.toast = str(message)
        self.toast_until = pygame.time.get_ticks() / 1000 + seconds

    @staticmethod
    def line(screen, start, end, color=GOLD, width=1):
        pygame.draw.line(screen, color, tuple(int(a) for a in start), tuple(int(a) for a in end), width)

    def _shade(self, screen, alpha=206):
        key = (*screen.get_size(), alpha)
        shade = self.shades.get(key)
        if shade is None:
            shade = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
            shade.fill((5, 12, 13, alpha))
            if len(self.shades) > 12:
                self.shades.clear()
            self.shades[key] = shade
        screen.blit(shade, (0, 0))

    def _chrome(self, screen, w, h, s, title='LEVEL 0'):
        inset = max(13, int(w * .045))
        self.text(screen, f'LEVEL {self.depth:02d}', inset, max(8, int(h * .024)), max(11, int(14 * s)),
                  WHITE, True)
        pygame.draw.line(screen, (91, 92, 74), (inset, 34 * s), (w - inset, 34 * s), 1)
        if w >= 670:
            self.text(screen, title, w - inset, max(8, int(h * .024)), max(10, int(12 * s)),
                      MUTED, align='right', max_width=(w - inset * 2) * .65)

    def _menu(self, screen, game, saved, s):
        w, h = screen.get_size()
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((12, 13, 11, 104))
        for column in range(0, max(1, int(w * .80)), 12):
            strength = max(0., .96 - column / max(1., w * .9))
            pygame.draw.rect(overlay, (9, 12, 11, int(180 * strength)), (column, 0, 12, h))
        screen.blit(overlay, (0, 0))
        self._chrome(screen, w, h, s, 'PERSONAL RECORDING  /  UNDATED')
        x = max(14, int(w * .068))
        title_y = max(40, int(h * .095))
        compact = h < 480
        title_size = min(48 * s, max(21., w / 16.))
        self.text(screen, 'THE BACKROOMS', x, title_y, title_size, WHITE, True, shadow=True)
        lower_y = title_y + max(29, int(title_size * 1.36))
        self.text(screen, '低 频 回 廊', x + 2, lower_y, (17 if compact else 22) * s, GOLD, False)
        if not compact:
            pygame.draw.line(screen, GOLD, (x, int(lower_y + 42 * s)), (x + int(37 * s), int(lower_y + 42 * s)), 2)
            self.text(screen, '灯光一直亮着。', x, lower_y + 55 * s, 13 * s, WHITE)
        rows = [('继续', 'continue', 'ENTER'), ('开始新的调查', 'new', ''),
                ('今日空间', 'daily', ''), ('调查档案', 'archive', ''),
                ('设置', 'settings', ''), ('黑匣子', 'blackbox', ''),
                ('退出', 'quit', '')]
        if not saved:
            rows.pop(0)
        if getattr(self, 'has_previous', False):
            rows.insert(1 if saved else 0, ('上一次调查', 'previous', ''))
        available_top = lower_y + (35 * s if compact else 86 * s)
        top = max(available_top, h * (.31 if compact else .45))
        columns = 2 if h < 480 and w >= 300 else 1
        count = (len(rows) + columns - 1) // columns
        gap = max(4, 6 * s)
        height = max(23, min(49 * s, (h - top - 21 - (count - 1) * gap) / count))
        width = min(w * (.39 if columns == 2 else .58), 372 * s)
        if columns == 2:
            width = min(width, (w - 2 * x - gap) / 2)
        for i, (label, action, hint) in enumerate(rows):
            column = i // count
            row = i % count
            bx = x + column * (width + 10 * s)
            by = top + row * (height + gap)
            self.button(screen, (bx, by, width, height), label, action,
                        hint if saved and action == 'continue' else '', active=(i == 0 and saved))
        if w >= 1080 and not compact:
            right = int(w * .77)
            self.text(screen, 'ARCHIVE  /  000', right, h * .70, 11 * s, MUTED)
            self.text(screen, f'{getattr(self, "archive_count", 0):04d}', right, h * .74, 24 * s, WHITE)
            pygame.draw.line(screen, (83, 80, 66), (right, int(h * .8)), (w - x, int(h * .8)))

    def _hud(self, screen, game, s, settings, controls):
        w, h = screen.get_size()
        pad = max(13, int(w * .026))
        quiet = settings.get('immersive_hud', True) and game.hud_awake <= 0. and game.elapsed > 12.
        if not quiet:
            self.text(screen, f'{game.fragments:02d}/{game.total_fragments:02d}', pad, pad,
                      16 * s, WHITE, True, shadow=True)
            self.text(screen, f'{int(game.elapsed // 60):02d}:{int(game.elapsed % 60):02d}',
                      pad, pad + 24 * s, 11 * s, MUTED, shadow=True)
            if h >= 410:
                bar_y = h - 39 * s
                for i, (value, color) in enumerate(((game.battery, GOLD),
                                                    (game.stamina, MUTED),
                                                    (game.sanity, RED if game.sanity < 30 else WHITE))):
                    yy = int(bar_y + i * 9 * s)
                    pygame.draw.rect(screen, (49, 49, 43), (pad, yy, max(10, int(82 * s)), 3))
                    pygame.draw.rect(screen, color, (pad, yy, max(0, int(82 * s * value / 100)), 3))
            self.text(screen, f'{game.ammo[game.weapon]:02d} / {game.reserve[game.weapon]:02d}',
                      w - pad, h - 40 * s, 19 * s, WHITE, True, 'right', True)
            if game.reload_clock > 0:
                self.text(screen, '装填', w - pad, h - 61 * s, 10 * s, MUTED, align='right')
            if game.assist and game.elapsed - game.last_progress > GUIDANCE_DELAY and game.message_time <= 0.:
                bearing, strength, kind = game.signal()
                if kind != 'NONE':
                    direction = ('正前方' if abs(bearing) < .48 else '后方' if abs(bearing) > 2.5 else
                                 '偏右' if bearing > 0 else '偏左')
                    objective = {'EXIT': '出口', 'TAPE': '录音', 'ECHO': '异常',
                                 'SURVEY': '尚未测绘区域', 'CALIBRATE': '未校准区域'}.get(kind, '信号')
                    self.text(screen, f'{objective} / {direction} · 信号 {int(strength * 100)}%',
                              w / 2, h - max(22, 26 * s), 11 * s, MINT,
                              align='center', shadow=True, max_width=w - 2 * pad)
            if game.listen_clock > 0:
                bx, by = w - pad - int(35 * s), int(69 * s)
                pygame.draw.circle(screen, GOLD, (bx, by), max(19, int(25 * s)), 1)
                self.line(screen, (bx, by),
                          (bx + math.sin(game.listen_bearing) * 20 * s,
                           by - math.cos(game.listen_bearing) * 20 * s), WHITE, 2)
            active = [(str(i + 1), left) for i, left in enumerate(game.skill_cooldowns) if left > 0]
            if active:
                self.text(screen, '     '.join(f'{label}:{math.ceil(left)}' for label, left in active),
                          w / 2, h - 33 * s, 10 * s, MUTED, align='center')
        cx, cy = w // 2, h // 2
        tone = (173, 171, 143) if not game.target_lock else (203, 199, 160)
        if game.aiming:
            pygame.draw.circle(screen, tone, (cx, cy), max(1, int(2 * s)))
        else:
            self.line(screen, (cx - 8 * s, cy), (cx - 3 * s, cy), tone)
            self.line(screen, (cx + 3 * s, cy), (cx + 8 * s, cy), tone)
            self.line(screen, (cx, cy - 8 * s), (cx, cy - 3 * s), tone)
            self.line(screen, (cx, cy + 3 * s), (cx, cy + 8 * s), tone)
        if game.near_item:
            labels = {'fragment': '恢复录音', 'cell': '拾取物资', 'echo': '记录异常',
                      'exit': '开启出口', 'note': '查看纸张', 'relay': '恢复频段'}
            self.text(screen, f'{display_binding(controls.bindings["interact"])}   {labels[game.near_item["kind"]]}',
                      cx, h * .72, 16 * s, WHITE, True, 'center', True)
        if game.message_time > 0:
            self.text(screen, game.message, cx, h * .17, 13 * s, WHITE, False, 'center', True, w * .82)

    def _map(self, screen, game, s, controls):
        self._shade(screen, 220)
        w, h = screen.get_size()
        self._chrome(screen, w, h, s, 'POSITION / RECONSTRUCTED')
        square = min(int((h - 108 * s) * .90), int(w * .63))
        cell = max(1, square // game.world.width)
        square = cell * game.world.width
        sx = (w - square) // 2
        sy = max(53, (h - square) // 2)
        self.panel(screen, (sx - 12, sy - 12, square + 24, square + 24),
                   (6, 18, 16, 241), (135, 174, 130, 120))
        for index in game.seen:
            x, y = index % game.world.width, index // game.world.width
            if 0 <= y < game.world.height:
                color = (54, 72, 60) if game.world.grid[y][x] else (21, 33, 27)
                pygame.draw.rect(screen, color, (sx + x * cell, sy + y * cell, cell, cell))
        for item in game.world.items:
            if item['active'] and int(item['y']) * game.world.width + int(item['x']) in game.seen:
                pygame.draw.circle(screen, MINT if item['kind'] == 'fragment' else (171, 149, 231) if item['kind'] == 'echo' else GOLD,
                                   (sx + int(item['x'] * cell), sy + int(item['y'] * cell)), max(2, cell // 3))
        if game.assist:
            game.signal()
            route = game._signal_cache[1] if game._signal_cache else []
            if route:
                every = max(1, len(route) // 140)
                for ix, iy in route[::every]:
                    pygame.draw.circle(screen, (84, 168, 134),
                                       (sx + int(ix * cell), sy + int(iy * cell)),
                                       max(1, cell // 5))
        if game.fragments == game.total_fragments:
            ex, ey = game.world.exit
            if int(ey) * game.world.width + int(ex) in game.seen:
                pygame.draw.circle(screen, MINT, (sx + int(ex * cell), sy + int(ey * cell)), max(3, cell), 2)
        px, py = sx + int(game.x * cell), sy + int(game.y * cell)
        rad = max(4, cell)
        pygame.draw.polygon(screen, WHITE,
                            [(px + math.cos(game.angle + da) * rad, py + math.sin(game.angle + da) * rad)
                             for da in (0, 2.5, -2.5)])
        self.text(screen, '测绘记录', max(16, w * .05), 63 * s, 23 * s, WHITE, True)
        self.text(screen, f'{game.world.architecture}  ·  {len(game.seen)} 个已探索单元' + ('  ·  信号路径已显示' if game.assist else ''),
                  max(16, w * .05), 97 * s, 12 * s, MUTED)
        self.text(screen, (game.daily_rule + '  ·  ' if game.daily_rule else '') + game.mission_summary(), max(16, w * .05), 120 * s,
                  11 * s, GOLD, max_width=w * .88)
        self.text(screen, f'[{display_binding(controls.bindings["map"])} / ESC] 返回',
                  max(16, w * .05), h - 53 * s, 13 * s, MINT, True)

    def _modal(self, screen, title, description, rows, s, footer='', danger=False):
        w, h = screen.get_size()
        compact = h < 445
        self._shade(screen, 220)
        self._chrome(screen, w, h, s)
        cw = min(w * .88, 580 * s)
        x = (w - cw) / 2
        y = max(20 if compact else 47 * s, h * (.075 if compact else .12))
        panel_h = min(h - y - 14 * s, h * (.84 if compact else .78))
        self.panel(screen, (x, y, cw, panel_h), (11, 25, 23, 243), (140, 175, 135, 102), 15)
        self.text(screen, title, w / 2, y + (11 if compact else 28) * s,
                  (23 if compact else 29) * s, RED if danger else WHITE, True, 'center')
        self.text(screen, description, w / 2, y + (43 if compact else 80) * s,
                  12 * s if compact else 13 * s, MUTED, align='center', max_width=cw - 22 * s)
        start = y + (68 if compact else 129) * s
        reserve = (18 if compact else 39) * s
        gap = (4 if compact else 7) * s
        available = max(1, y + panel_h - start - reserve)
        bh = min(49 * s if compact else 54 * s,
                 max(21, (available - (len(rows) - 1) * gap) / max(1, len(rows))))
        for i, (label, action, hint) in enumerate(rows):
            self.button(screen, (x + 18 * s, start + i * (bh + gap), cw - 36 * s, bh),
                        label, action, '' if compact else hint,
                        active=i == 0, danger=danger and i == 0)
        if footer and not compact:
            self.text(screen, footer, w / 2, y + panel_h - 24 * s, 11 * s, MUTED, align='center')

    def _settings(self, screen, s, settings, fps, controls, page=0, binding_wait=None):
        w, h = screen.get_size()
        compact = w < 660 or h < 540
        self._shade(screen, 227)
        self._chrome(screen, w, h, s, 'SYSTEM / LOCAL OPTIONS')
        x = max(13, int(w * (.055 if compact else .10)))
        right = w - x
        title_y = max(22, h * (.085 if compact else .105))
        self.text(screen, '画面与控制', x, title_y, (25 if compact else 32) * s, WHITE, True)
        if w >= 560:
            self.text(screen, f'{fps:.0f} FPS  ·  立即应用', right, title_y + 10 * s,
                      11 * s, MINT, align='right')
        tab_y = max(50, h * (.19 if compact else .225))
        pages = ('画面', '移动', '战斗', '技能') if compact else ('画面与声音',) + tuple(group[0] for group in BINDING_PAGES)
        gap = max(3, 5 * s)
        tab_h = max(24, int(37 * s))
        tab_width = (right - x - gap * 3) / 4
        for i, title in enumerate(pages):
            self.button(screen, (x + i * (tab_width + gap), tab_y, tab_width, tab_h),
                        title, f'page:{i}', active=(page == i))
        top = tab_y + tab_h + max(5, 10 * s)
        footer_h = max(48, int(65 * s))
        bottom = h - footer_h
        if page == 0:
            entries = [('动态渲染', 'quality', {'AUTO': '智能', 'HIGH': '高画质', 'ECO': '省电'}[settings['quality']]),
                       ('音量', 'volume', f'{int(settings["volume"] * 100)}%'),
                       ('鼠标灵敏度', 'sensitivity', f'{settings["sensitivity"] / .0024:.1f}×'),
                       ('显示模式', 'fullscreen', {'windowed': '可调整窗口', 'borderless': '无边框全屏', 'exclusive': '独占全屏'}[settings['display_mode']]),
                       ('舒适光效', 'reduce_flash', '开启' if settings['reduce_flash'] else '关闭'),
                       ('GPU 加速', 'gpu_scaling', ('GPU 运行中' if self.backend == 'GPU' else '回退 CPU') if settings['gpu_scaling'] else '仅 CPU'),
                       ('探索辅助', 'assist', '自动拾取 · 路线' if settings['assist'] else '手动探索'),
                       ('沉浸式 HUD', 'immersive_hud', '动态精简' if settings['immersive_hud'] else '完整显示'),
                       ('帧率上限', 'target_fps', f'{settings["target_fps"]} FPS'),
                       ('恐怖强度', 'horror_intensity', f'{settings["horror_intensity"]:.2f}×'),
                       ('界面比例', 'ui_scale', f'{settings["ui_scale"]:.2f}×'),
                       ('诊断预览', 'diagnostics', '查看脱敏内容')]
            actions = [(a, b if b == 'diagnostics' else f'setting:{b}', c) for a, b, c in entries]
        else:
            actions = [(BINDING_LABELS[key], f'binding:{key}',
                        '等待按键…' if binding_wait == key else display_binding(controls.bindings[key]))
                       for key in BINDING_PAGES[page - 1][1]]
            actions.append(('恢复默认按键', 'reset_bindings', '重置'))
        row_gap = max(3, int(SETTINGS_ROW_GAP * s))
        available = max(1, bottom - top)
        row_h = max(SETTINGS_MIN_ROW, min(int(46 * s), max(SETTINGS_MIN_ROW, int((available - 2 * row_gap) / 3))))
        visible = max(1, int((available + row_gap) // (row_h + row_gap)))
        last_offset = max(0, len(actions) - visible)
        self.settings_offset = max(0, min(self.settings_offset, last_offset))
        for local, (label, action, value) in enumerate(actions[self.settings_offset:self.settings_offset + visible]):
            y = top + local * (row_h + row_gap)
            self.text(screen, label, x + 2 * s, y + (row_h - 15 * s) / 2,
                      13 * s if compact else 14 * s, WHITE, max_width=(right - x) * .46)
            bx = x + (right - x) * .49
            self.button(screen, (bx, y, right - bx, row_h), value, action,
                        active=(binding_wait is not None and action == f'binding:{binding_wait}'))
        nav_y = h - max(41, 48 * s)
        nav_w = (right - x - 2 * gap) / 3
        if self.settings_offset > 0:
            self.button(screen, (x, nav_y, nav_w, max(27, 36 * s)), '上一组', 'settings_scroll:-1')
        if self.settings_offset < last_offset:
            self.button(screen, (x + nav_w + gap, nav_y, nav_w, max(27, 36 * s)),
                        '下一组', 'settings_scroll:+1')
        self.button(screen, (right - nav_w, nav_y, nav_w, max(27, 36 * s)),
                    '返回', 'back', '' if compact else 'ESC')
        if binding_wait and not compact:
            self.text(screen, '按下新按键或鼠标按钮 · Esc 取消', x, nav_y - 20 * s, 11 * s, MINT)

    def _archive(self, screen, s):
        self._shade(screen, 230)
        w, h = screen.get_size()
        self._chrome(screen, w, h, s, 'ARCHIVE / LOCAL')
        x = max(18, int(w * .09))
        width = w - 2 * x
        stats = self.archive_stats or {}
        compact = h < 500
        self.text(screen, '调查归档', x, max(27, int(h * .095)), 28 * s, WHITE, True)
        total = int(stats.get('total_runs', 0))
        endings = stats.get('endings', {})
        self.text(screen, f'累计调查 {total} 次   /   已发现结局 {len(endings)} 种',
                  x, max(68, int(h * .195)), 15 * s, MINT, True, max_width=width)
        best = stats.get('best_seconds')
        best_text = f'{int(best // 60)}分{int(best % 60)}秒' if isinstance(best, (float, int)) else '暂无记录'
        self.text(screen, f'最佳通关  {best_text}   ·   离线今日调查 {int(stats.get("daily_runs", 0))} 次',
                  x, max(93, int(h * .255)), 12 * s, MUTED, max_width=width)
        self.text(screen, f'最深记录  LEVEL {stats.get("deepest_depth", 0):02d}   ·   空间异变 {stats.get("discoveries", 0)} 处',
                  x, max(112, int(h * .30)), 11 * s, GOLD, max_width=width)
        missions = stats.get('missions') or {}
        if missions and not compact:
            label = '  /  '.join(f'{name} {missions.get(key, 0)}' for key, name in
                                 (('TAPES', '录音'), ('ECHO', '旁证'), ('SURVEY', '测绘'),
                                  ('SIGNAL', '校准'), ('MIXED', '交叉')) if missions.get(key, 0))
            self.text(screen, label, x, max(135, int(h * .337)), 10 * s, MUTED, max_width=width)
        records = stats.get('runs', [])
        heading_y = max(151, int(h * .40))
        self.line(screen, (x, heading_y - 9 * s), (w - x, heading_y - 9 * s), GOLD, 1)
        self.text(screen, '最近记录', x, heading_y, 15 * s, WHITE, True)
        row_y = heading_y + 33 * s
        row_h = max(27, 33 * s)
        max_rows = max(0, int((h - 79 * s - row_y) // row_h))
        for i, record in enumerate(reversed(records[-max_rows:]) if max_rows else ()):
            label = str(record.get('ending', '未知'))[:14]
            timestamp = str(record.get('date', ''))[:10]
            try:
                seconds = float(record.get('seconds', 0))
                seconds = seconds if math.isfinite(seconds) and seconds >= 0 else 0.
            except (ValueError, TypeError, OverflowError):
                seconds = 0.
            text = f'{timestamp}  ·  L{record.get("depth", 0)}  ·  {label}  ·  {int(seconds // 60)}m'
            self.text(screen, text, x + 8 * s, row_y + i * row_h,
                      12 * s, GOLD if i % 2 == 0 else MUTED, max_width=width - 15 * s)
        if not records:
            self.text(screen, '没有找到已完成的调查。', x + 8 * s, row_y, 13 * s, MUTED)
        self.button(screen, (w - x - max(105, 135 * s), h - max(48, 57 * s),
                             max(105, 135 * s), max(28, 38 * s)), '返回', 'archive_back')

    def _diagnostics(self, screen, s):
        self._shade(screen, 231)
        w, h = screen.get_size()
        self._chrome(screen, w, h, s, 'DIAGNOSTICS / REDACTED')
        x = max(16, int(w * .085))
        info = getattr(self, 'diagnostics', {})
        self.text(screen, '黑匣子预览', x, h * .12, 29 * s, WHITE, True)
        files = info.get('files', [])
        self.text(screen, f'将打包 {len(files)} 项诊断内容 · {int(info.get("estimated_bytes", 0) / 1024)} KB 未压缩文本',
                  x, h * .25, 13 * s, MINT, max_width=w - 2 * x)
        self.text(screen, '配置、渲染状态、事件与崩溃记录已进行敏感字段遮盖',
                  x, h * .31, 12 * s, MUTED, max_width=w - 2 * x)
        panel_y = h * .40
        panel_h = max(54, min(h * .29, 155 * s))
        self.panel(screen, (x, panel_y, w - 2 * x, panel_h), (7, 18, 19, 201), (110, 151, 129, 89), 7)
        recent = info.get('recent', [])
        if recent:
            row_h = min(27 * s, panel_h / max(1, len(recent)))
            for index, line in enumerate(recent[-4:]):
                self.text(screen, str(line)[:145], x + 13 * s, panel_y + 9 * s + index * row_h,
                          11 * s, MUTED, max_width=w - 2 * x - 24 * s)
        else:
            self.text(screen, '尚无最近事件记录', x + 13 * s, panel_y + 15 * s, 12 * s, MUTED)
        bw = min(245 * s, (w - 2 * x - 12 * s) / 2)
        bottom = h - max(66, 77 * s)
        self.button(screen, (x, bottom, bw, max(35, 45 * s)), '导出到桌面', 'blackbox', active=True)
        self.button(screen, (x + bw + 12 * s, bottom, bw, max(35, 45 * s)),
                    '返回', 'diagnostics_back')

    def draw(self, screen, game, state, saved, settings, fps, controls, settings_page=0, binding_wait=None):
        self.buttons = []
        w, h = screen.get_size()
        s = max(.59, min(2.2, min(w / 1200, h / 720) * settings.get('ui_scale', 1.)))
        self.ui_scale = s
        self.depth = getattr(game, 'depth', 0)
        self.ui_clock = pygame.time.get_ticks() / 1000
        if state == 'MENU':
            self._menu(screen, game, saved, s)
        elif state == 'PLAY':
            self._hud(screen, game, s, settings, controls)
        elif state == 'MAP':
            self._map(screen, game, s, controls)
        elif state == 'PAUSE':
            self._modal(screen, '已 暂 停', '周围的灯光仍然在运作。',
                        [('返回现场', 'resume', 'ESC'), ('保存并返回主界面', 'menu', 'SAVE'),
                         ('画面与按键', 'settings', 'OPTIONS'), ('导出黑匣子', 'blackbox', '< 1 MB')], s)
        elif state == 'ARCHIVE':
            self._archive(screen, s)
        elif state == 'DIAGNOSTICS':
            self._diagnostics(screen, s)
        elif state == 'SETTINGS':
            self._settings(screen, s, settings, fps, controls, settings_page, binding_wait)
        elif state == 'WON':
            self._modal(screen, f'结 局 / {game.ending}', f'录音已归档 · 卷宗 {len(game.evidence)}/5 · 频段 {len(game.relays)}/3 · 耗时 {int(game.elapsed // 60)} 分钟',
                        [('深入下一层', 'descend', f'LEVEL {game.depth + 1:02d}'),
                         ('再次进入', 'new', 'NEW RUN'), ('返回主界面', 'menu', 'ARCHIVE'),
                         ('导出黑匣子', 'blackbox', 'DIAGNOSTICS')], s,
                        '你无法确定自己是否真的离开。')
        if self.toast and self.ui_clock < self.toast_until:
            cw = max(80, min(w - DIALOG_SAFE_MARGIN * 2,
                             self.font(13 * s).size(self.toast)[0] + 36 * s))
            self.panel(screen, ((w - cw) / 2, 43 * s, cw, 37 * s),
                       (13, 35, 28, 236), (113, 225, 178, 150))
            self.text(screen, self.toast, w / 2, 52 * s, 13 * s, MINT, True, 'center', max_width=cw - 16 * s)
