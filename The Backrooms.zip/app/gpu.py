import ctypes
import math
import sys

import pygame

from config import (RAY_STEP_LIMIT, TAN_HALF, GPU_SCALES,
                    GPU_MIN_VIEW, GPU_MAX_SCENE_PIXELS, WORLD_REGION_SIZE, WALL_TEXTURE_SIZE, GPU_UI_TILE_SIZE, GPU_UI_FULL_UPLOAD_RATIO,
                    GPU_MAX_OVERLAY_PIXELS)

from procedural import art, WALL_NAMES, SPRITE_NAMES

VERTEX = '''#version 120
varying vec2 coord;
void main() {
    gl_Position = gl_Vertex;
    coord = gl_MultiTexCoord0.xy;
}
'''
FRAGMENT = '''#version 120
varying vec2 coord;
uniform sampler2D gridTex;
uniform sampler2D wallTex;
uniform vec2 player;
uniform vec2 direction;
uniform vec2 resolution;
uniform vec2 lamps[12];
uniform vec2 flarePos;
uniform float flareIntensity;
uniform float muzzlePower;
uniform int lampCount;
uniform float pitch;
uniform float elapsed;
uniform float seed;
uniform float aim;
uniform float lightFault;
uniform float anomaly;
uniform float blackout;
uniform float warp;
uniform float reduced;
uniform float tanHalf;
uniform float viewSteps;
uniform float worldSize;
uniform float regionSize;
uniform float wallMaterials;
uniform float seed13;
uniform float tension;
uniform float sanity;
float hash1(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
float solid(vec2 p){
    if(p.x < 0. || p.y < 0. || p.x >= worldSize || p.y >= worldSize) return 0.;
    vec2 uv = (floor(p) + vec2(.5)) / worldSize;
    return texture2D(gridTex, vec2(uv.x,1.-uv.y)).r;
}
float shadow(vec2 p, vec2 source) {
    vec2 delta = source-p;
    float distance = length(delta);
    if(distance < .38) return 1.;
    for(int j=1;j<=7;j++) {
        float ratio = float(j)/8.;
        if(solid(p + delta * ratio) < .5) return .12;
    }
    return 1.;
}
float lighting(vec2 p) {
    float v = 0.;
    for(int i=0;i<12;i++) {
        if(i >= lampCount) break;
        vec2 diff = lamps[i]-p;
        float d2=dot(diff,diff);
        if(d2>95.) continue;
        float reach=1./(1.+d2*.26);
        v += .46*reach*shadow(p,lamps[i]);
    }
    vec2 delta=flarePos-p;
    float distance=dot(delta,delta);
    if(flareIntensity>.001 && distance<45.)
        v += flareIntensity * .93/(1.+distance*.65)*shadow(p,flarePos);
    return min(.83,v);
}
void main() {
    float sy = 1. - coord.y;
    float horizon = clamp(.50 + pitch,.12,.88);
    float cx = (coord.x*2. - 1.) * tanHalf;
    vec2 ray = direction + vec2(-direction.y,direction.x)*cx;
    vec2 mapxy = floor(player);
    vec2 delta = 1. / max(abs(ray),vec2(.000001));
    vec2 stepv = vec2(ray.x < 0. ? -1. : 1.,ray.y < 0. ? -1. : 1.);
    vec2 sideDist = vec2(ray.x < 0. ? (player.x-mapxy.x)*delta.x : (mapxy.x+1.-player.x)*delta.x,
                         ray.y < 0. ? (player.y-mapxy.y)*delta.y : (mapxy.y+1.-player.y)*delta.y);
    float side = 0.;
    for(int i=0;i<__RAY_STEP_LIMIT__;i++){
        if(float(i)>=viewSteps) break;
        if(sideDist.x<sideDist.y){ sideDist.x+=delta.x;mapxy.x+=stepv.x;side=0.; }
        else {sideDist.y+=delta.y;mapxy.y+=stepv.y;side=1.;}
        if(solid(mapxy)<.5)break;
    }
    float dist = side < .5 ? (mapxy.x-player.x+(1.-stepv.x)*.5)/ray.x:
                               (mapxy.y-player.y+(1.-stepv.y)*.5)/ray.y;
    dist = max(.08,dist);
    float height = min(5.,1.08/dist);
    float top = horizon-height*.48;
    vec3 result;
    float fault = (reduced>.5)?1.:(1. - lightFault*.18);
    if(sy >= top && sy <= top+height) {
        float wallX = side < .5 ? player.y+dist*ray.y : player.x+dist*ray.x;
        wallX = fract(wallX);
        if((side < .5 && ray.x>0.) || (side>.5 && ray.y<0.))wallX=1.-wallX;
        vec2 worldUV = (mapxy + vec2(.5)) / worldSize;
        float material = floor(texture2D(gridTex, vec2(worldUV.x,1.-worldUV.y)).g * 255. / 40. + .5);
        if(warp>.2 && mod(mapxy.x*19.+mapxy.y*23.+seed13,13.)<warp*6.) material=mod(material+1.,wallMaterials);
        vec2 uv = vec2((material+wallX)/wallMaterials, clamp((sy-top)/height,0.,1.));
        vec3 tex = texture2D(wallTex,vec2(uv.x,1.-uv.y)).rgb;
        float wallV=clamp((sy-top)/height,0.,1.);
        float seam = min(fract(wallX*2.),1.-fract(wallX*2.));
        float adhesive=1.-smoothstep(.002,.013,seam);
        float verticalFiber=hash1(floor(vec2(wallX*450.,wallV*500.)))*.045;
        float texB = texture2D(wallTex,vec2(uv.x+.0013,1.-uv.y+.002)).r;
        float bump = clamp((tex.r-texB)*1.8,-.24,.24);
        float glue=sin((uv.y+hash1(mapxy)*.27)*87.)*.018;
        float cone = pow(max(0.,1.-pow(abs(cx)/mix(.65,.33,aim),1.65)),.95);
        float reach = 1./(1.+pow(dist/mix(6.7,8.5,aim),1.7));
        vec2 contactPoint = player + ray * max(.05, dist-.055);
        float wallLight=lighting(contactPoint)*fault;
        float value=(.095 + .86*cone*reach + wallLight + muzzlePower*.32*exp(-dist*.38))*
                    (side>.5?.78:1.);
        result=tex * (.19+1.30*clamp(value,0.,1.8))*(1.+bump*.48+glue+verticalFiber);
        result*=1.-adhesive*.12;
        float molding = 1.-smoothstep(.035,.07,wallV);
        float chairRail=1.-smoothstep(.004,.014,abs(wallV-.72));
        result=mix(result,result*vec3(.60,.62,.51),molding*.67);
        result*=1.-chairRail*.085;
        float baseboard=smoothstep(.905,.922,wallV);
        vec3 baseColor=vec3(.17,.16,.125)*(.40+1.14*clamp(value,0.,1.4));
        baseColor*=1.-.35*smoothstep(.972,.989,wallV);
        result=mix(result,baseColor,baseboard*.91);
        float bevel=1.-smoothstep(.003,.010,abs(wallV-.915));
        result+=vec3(.12,.115,.077)*bevel*clamp(value,0.,1.);
        float edgeAO=1.-smoothstep(.00,.08,wallV);
        result*=1.-edgeAO*.34;
        float damp = smoothstep(.7,.95,hash1(floor(mapxy*3.+floor(vec2(wallX,uv.y)*8.))))*.16;
        result*=1.-damp;
        float fog=clamp((dist-7.)/28.,0.,.56);
        result=mix(result,vec3(.065,.071,.048),fog);
    } else if(sy>horizon) {
        float d=.52/max(.008,sy-horizon);
        vec2 p=player+ray*d;
        float threads=hash1(floor(p*135.))*.058;
        float pile=hash1(floor(p*280.))*.027;
        float stain=hash1(floor(p*1.5));
        float carpet = .12 + .11*exp(-d*.060) + threads - .072*smoothstep(.71,.93,stain);
        carpet+=.015*sin(p.x*22.)*sin(p.y*29.)+pile;
        float footprint=hash1(floor(p*1.8+vec2(18.3,-9.1)));
        carpet-=.049*smoothstep(.80,.94,footprint);
        float puddle=smoothstep(.75,.97,hash1(floor(p*2.7)))*.06;
        carpet-=puddle;
        float gridA = min(fract(p.x),1.-fract(p.x));
        float gridB = min(fract(p.y),1.-fract(p.y));
        carpet-=.012*(1.-smoothstep(.008,.022,min(gridA,gridB)))*step(.68,hash1(floor(p*.34)));
        float room=mod(floor(p.x/regionSize)*3.+floor(p.y/regionSize)*7.+seed,5.);
        vec3 carpetColor=mix(vec3(.77,.70,.49),vec3(.45,.58,.54),step(1.5,room)*step(room,2.5)*.42);
        result=carpetColor*carpet;
        float floorLight=lighting(p)*fault;
        result+=vec3(.32,.31,.23)*floorLight*.59;
        result*=.90+.1*clamp(floorLight,0.,1.);
        float contact=smoothstep(.12,.7,fract(p.x))*smoothstep(.12,.7,fract(p.y));
        result*=.94+.06*contact;
    } else {
        float d=.48/max(.008,horizon-sy);
        vec2 p=player+ray*d;
        float seam = min(min(fract(p.x),1.-fract(p.x)),min(fract(p.y),1.-fract(p.y)));
        float tile = 1.-.13*(1.-smoothstep(.005,.024,seam));
        float v=(.18+.13*exp(-d*.070))*tile;
        float stains=smoothstep(.77,.93,hash1(floor(p*1.6)))*.045;
        v-=stains;
        result=vec3(.70,.71,.54)*v;
        result*=1.-.13*clamp(d/24.,0.,1.);
        float nearLight=0.;
        float fixture=0.;
        for(int i=0;i<12;i++) {
            if(i>=lampCount)break;
            vec2 diff=p-lamps[i];
            nearLight=max(nearLight,(1.-smoothstep(.14,.54,length(diff))));
            float fixtureX=1.-smoothstep(.35,.44,abs(diff.x));
            float fixtureY=1.-smoothstep(.065,.125,abs(diff.y));
            fixture=max(fixture,fixtureX*fixtureY);
        }
        result+=vec3(.59,.56,.35)*nearLight*fault;
        result+=vec3(.23,.23,.16)*min(.55,lighting(p))*.38;
        result=mix(result,vec3(.75,.73,.53)*(.42+.55*fault),fixture*.91);
        float frameX=1.-smoothstep(.009,.027,abs(abs(fract(p.x)-.5)-.44));
        float frameY=1.-smoothstep(.007,.020,abs(abs(fract(p.y)-.5)-.12));
        result*=1.-.11*fixture*(frameX+frameY);
    }
    float grain=(hash1(gl_FragCoord.xy + floor(elapsed*11.)*17.)-.5)*(.020+.025*tension);
    float stripe=step(.997,hash1(vec2(floor(sy*resolution.y*.33),floor(elapsed*6.))))*
                 smoothstep(.58,.94,tension)*.065;
    result*=1.-stripe;
    result += (reduced>.5?grain*.3:grain);
    float vignette=1.-(.30+.17*tension)*pow(length((coord-.5)*vec2(1.3,1.)),2.);
    result*=vignette*(1.-.46*clamp(blackout,0.,1.));
    result=mix(result,vec3(.06,.10,.085),clamp(anomaly*.12,0.,.20));
    result=mix(result,result*vec3(.78,.93,.87),clamp((1.-sanity)*.22+tension*.085,0.,.24));
    result=pow(max(result,vec3(0.)),vec3(.95));
    gl_FragColor=vec4(clamp(result,0.,1.),1.);
}
'''


class OpenGLFunctions:
    def __init__(self):
        if sys.platform != 'win32':
            raise RuntimeError('GPU backend requires Windows OpenGL')
        self.lib = ctypes.WinDLL('opengl32.dll')
        get = self.lib.wglGetProcAddress
        get.argtypes = [ctypes.c_char_p]
        get.restype = ctypes.c_void_p
        self.getproc = get
        self.cache = {}

    def fn(self, name, result=None, args=()):
        if name in self.cache:
            return self.cache[name]
        addr = self.getproc(name.encode('ascii'))
        if addr in (None, 0, 1, 2, 3, ctypes.c_void_p(-1).value):
            try:
                func = getattr(self.lib, name)
            except AttributeError as error:
                raise RuntimeError('OpenGL entry unavailable: ' + name) from error
        else:
            func = ctypes.WINFUNCTYPE(result, *args)(addr)
        func.restype = result
        func.argtypes = list(args)
        self.cache[name] = func
        return func


class GPUBackend:
    GL_TEXTURE_2D = 0x0DE1
    GL_TEXTURE0 = 0x84C0
    GL_TEXTURE1 = 0x84C1
    GL_RGBA = 0x1908
    GL_UNSIGNED_BYTE = 0x1401
    GL_TEXTURE_MIN_FILTER = 0x2801
    GL_TEXTURE_MAG_FILTER = 0x2800
    GL_TEXTURE_WRAP_S = 0x2802
    GL_TEXTURE_WRAP_T = 0x2803
    GL_LINEAR = 0x2601
    GL_NEAREST = 0x2600
    GL_CLAMP_TO_EDGE = 0x812F
    GL_VERTEX_SHADER = 0x8B31
    GL_FRAGMENT_SHADER = 0x8B30
    GL_COMPILE_STATUS = 0x8B81
    GL_LINK_STATUS = 0x8B82
    GL_COLOR_BUFFER_BIT = 0x00004000
    GL_BLEND = 0x0BE2
    GL_SRC_ALPHA = 0x0302
    GL_ONE_MINUS_SRC_ALPHA = 0x0303
    GL_DEPTH_TEST = 0x0B71
    GL_QUADS = 0x0007
    GL_FRAMEBUFFER = 0x8D40
    GL_COLOR_ATTACHMENT0 = 0x8CE0
    GL_FRAMEBUFFER_COMPLETE = 0x8CD5

    def __init__(self, size, quality='AUTO'):
        if size[0] * size[1] > GPU_MAX_OVERLAY_PIXELS:
            raise RuntimeError('GPU display surface exceeds safe allocation budget')
        self.gl = OpenGLFunctions()
        self._link_calls()
        self.quality = quality
        self.closed = False
        self.allocated_textures = set()
        self.size = tuple(size)
        self.view_size = self.size
        self.last_rays = self.size[0]
        self.auto_level = 2
        self.renderer_name = 'OpenGL'
        try:
            vendor = self.gl.fn('glGetString', ctypes.c_char_p, (ctypes.c_uint,))
            value = vendor(0x1F01)
            if value:
                self.renderer_name = value.decode('utf-8', 'replace')[:90]
        except (RuntimeError, ValueError, AttributeError, OSError):
            pass
        self.program = self._program(VERTEX, FRAGMENT.replace('__RAY_STEP_LIMIT__', str(RAY_STEP_LIMIT)))
        self.uniforms = {key: self.glGetUniformLocation(self.program, (key + '[0]' if key == 'lamps' else key).encode('ascii')) for key in
                         ('gridTex', 'wallTex', 'player', 'direction', 'resolution', 'lamps', 'lampCount',
                          'flarePos', 'flareIntensity', 'muzzlePower',
                          'pitch', 'elapsed', 'seed', 'aim', 'lightFault', 'anomaly', 'blackout', 'warp', 'reduced',
                          'tanHalf', 'viewSteps', 'worldSize', 'regionSize', 'wallMaterials', 'seed13', 'tension', 'sanity')}
        wall_files = WALL_NAMES
        self.wall_materials = len(wall_files)
        atlas = pygame.Surface((WALL_TEXTURE_SIZE * len(wall_files), WALL_TEXTURE_SIZE), pygame.SRCALPHA)
        for i, name in enumerate(wall_files):
            surface = art(name).convert_alpha()
            if surface.get_size() != (WALL_TEXTURE_SIZE,WALL_TEXTURE_SIZE):
                surface = pygame.transform.smoothscale(surface,(WALL_TEXTURE_SIZE,WALL_TEXTURE_SIZE))
            atlas.blit(surface, (WALL_TEXTURE_SIZE*i,0))
        self.wall_id = self._texture(atlas)
        self.grid_id = None
        self.grid_seed = None
        self.overlay_id = self._texture(None, self.size)
        self.ui_upload_bytes = 0
        self._overlay_tiles = set()
        self._overlay_full = True
        self.use_fbo = False
        self.framebuffer = None
        self.scene_id = None
        if self.glGenFramebuffers:
            try:
                value = ctypes.c_uint()
                self.glGenFramebuffers(1, ctypes.byref(value))
                self.framebuffer = value.value
                self.scene_id = self._texture(None, self.size)
                self.use_fbo = True
            except (RuntimeError, OSError, ValueError, TypeError):
                self.use_fbo = False
        self.sprites = {name: (self._texture(art(name).convert_alpha()), art(name).get_size())
                        for name in SPRITE_NAMES}
        self._resize(self.size)

    def _link_calls(self):
        g = self.gl.fn
        ui = ctypes.c_uint
        ii = ctypes.c_int
        fl = ctypes.c_float
        ptr = ctypes.c_void_p
        self.glCreateShader = g('glCreateShader',ui,(ui,))
        self.glShaderSource = g('glShaderSource',None,(ui,ii,ctypes.POINTER(ctypes.c_char_p),ptr))
        self.glCompileShader = g('glCompileShader',None,(ui,))
        self.glGetShaderiv = g('glGetShaderiv',None,(ui,ui,ctypes.POINTER(ii)))
        self.glGetShaderInfoLog = g('glGetShaderInfoLog',None,(ui,ii,ctypes.POINTER(ii),ptr))
        self.glCreateProgram = g('glCreateProgram',ui,())
        self.glAttachShader = g('glAttachShader',None,(ui,ui))
        self.glLinkProgram = g('glLinkProgram',None,(ui,))
        self.glGetProgramiv = g('glGetProgramiv',None,(ui,ui,ctypes.POINTER(ii)))
        self.glGetProgramInfoLog = g('glGetProgramInfoLog',None,(ui,ii,ctypes.POINTER(ii),ptr))
        self.glGetUniformLocation = g('glGetUniformLocation',ii,(ui,ctypes.c_char_p))
        self.glUseProgram = g('glUseProgram',None,(ui,))
        self.glUniform1i = g('glUniform1i',None,(ii,ii))
        self.glUniform1f = g('glUniform1f',None,(ii,fl))
        self.glUniform2f = g('glUniform2f',None,(ii,fl,fl))
        self.glUniform2fv = g('glUniform2fv',None,(ii,ii,ptr))
        self.glActiveTexture = g('glActiveTexture',None,(ui,))
        self.glGenTextures = g('glGenTextures',None,(ii,ctypes.POINTER(ui)))
        self.glDeleteTextures = g('glDeleteTextures',None,(ii,ctypes.POINTER(ui)))
        self.glDeleteProgram = g('glDeleteProgram',None,(ui,))
        self.glDeleteShader = g('glDeleteShader',None,(ui,))
        self.glPixelStorei = g('glPixelStorei',None,(ui,ii))
        self.glBindTexture = g('glBindTexture',None,(ui,ui))
        self.glTexParameteri = g('glTexParameteri',None,(ui,ui,ii))
        self.glTexImage2D = g('glTexImage2D',None,(ui,ii,ii,ii,ii,ii,ui,ui,ptr))
        self.glTexSubImage2D = g('glTexSubImage2D',None,(ui,ii,ii,ii,ii,ii,ui,ui,ptr))
        self.glViewport = g('glViewport',None,(ii,ii,ii,ii))
        self.glClearColor = g('glClearColor',None,(fl,fl,fl,fl))
        self.glClear = g('glClear',None,(ui,))
        self.glEnable = g('glEnable',None,(ui,))
        self.glDisable = g('glDisable',None,(ui,))
        self.glBlendFunc = g('glBlendFunc',None,(ui,ui))
        self.glBegin = g('glBegin',None,(ui,))
        self.glEnd = g('glEnd',None,())
        self.glTexCoord2f = g('glTexCoord2f',None,(fl,fl))
        self.glVertex2f = g('glVertex2f',None,(fl,fl))
        self.glColor4f = g('glColor4f',None,(fl,fl,fl,fl))
        try:
            self.glGenFramebuffers = g('glGenFramebuffers',None,(ii,ctypes.POINTER(ui)))
            self.glBindFramebuffer = g('glBindFramebuffer',None,(ui,ui))
            self.glFramebufferTexture2D = g('glFramebufferTexture2D',None,(ui,ui,ui,ui,ii))
            self.glCheckFramebufferStatus = g('glCheckFramebufferStatus',ui,(ui,))
            self.glDeleteFramebuffers = g('glDeleteFramebuffers',None,(ii,ctypes.POINTER(ui)))
        except RuntimeError:
            self.glGenFramebuffers = None
            self.glDeleteFramebuffers = None

    def _compile(self, shader_type, source):
        shader = self.glCreateShader(shader_type)
        inputs = (ctypes.c_char_p*1)(source.encode('utf-8'))
        self.glShaderSource(shader,1,inputs,None)
        self.glCompileShader(shader)
        ok=ctypes.c_int()
        self.glGetShaderiv(shader,self.GL_COMPILE_STATUS,ctypes.byref(ok))
        if not ok.value:
            buffer = ctypes.create_string_buffer(4096)
            self.glGetShaderInfoLog(shader,4096,None,buffer)
            raise RuntimeError('GPU shader compilation failed: ' + buffer.value.decode('utf-8','replace')[:350])
        return shader

    def _program(self, vertex, fragment):
        v = self._compile(self.GL_VERTEX_SHADER,vertex)
        f = self._compile(self.GL_FRAGMENT_SHADER,fragment)
        program = self.glCreateProgram()
        self.glAttachShader(program,v)
        self.glAttachShader(program,f)
        self.glLinkProgram(program)
        ok=ctypes.c_int()
        self.glGetProgramiv(program,self.GL_LINK_STATUS,ctypes.byref(ok))
        if not ok.value:
            buffer = ctypes.create_string_buffer(4096)
            self.glGetProgramInfoLog(program,4096,None,buffer)
            raise RuntimeError('GPU shader linking failed: ' + buffer.value.decode('utf-8','replace')[:350])
        self.glDeleteShader(v)
        self.glDeleteShader(f)
        return program

    def _texture(self, surface=None, size=None, nearest=False):
        w,h = surface.get_size() if surface is not None else size
        texture = ctypes.c_uint()
        self.glGenTextures(1,ctypes.byref(texture))
        if not texture.value:
            raise RuntimeError('OpenGL texture allocation failed')
        self.allocated_textures.add(texture.value)
        self.glPixelStorei(0x0CF5,1)
        self.glBindTexture(self.GL_TEXTURE_2D,texture.value)
        for axis in (self.GL_TEXTURE_WRAP_S,self.GL_TEXTURE_WRAP_T):
            self.glTexParameteri(self.GL_TEXTURE_2D,axis,self.GL_CLAMP_TO_EDGE)
        filter_value = self.GL_NEAREST if nearest else self.GL_LINEAR
        self.glTexParameteri(self.GL_TEXTURE_2D,self.GL_TEXTURE_MIN_FILTER,filter_value)
        self.glTexParameteri(self.GL_TEXTURE_2D,self.GL_TEXTURE_MAG_FILTER,filter_value)
        pixels = pygame.image.tobytes(surface, 'RGBA', True) if surface else None
        pointer = ctypes.cast(ctypes.c_char_p(pixels), ctypes.c_void_p) if pixels is not None else None
        self.glTexImage2D(self.GL_TEXTURE_2D,0,self.GL_RGBA,w,h,0,
                          self.GL_RGBA,self.GL_UNSIGNED_BYTE,pointer)
        return texture.value

    def _scene_size(self, size):
        if not self.use_fbo:
            return tuple(size)
        tier = 4 if self.quality == 'HIGH' else 0 if self.quality == 'ECO' else self.auto_level
        width = min(size[0], max(GPU_MIN_VIEW[0], int(size[0] * GPU_SCALES[tier])))
        height = min(size[1], max(GPU_MIN_VIEW[1], int(size[1] * GPU_SCALES[tier])))
        if width * height > GPU_MAX_SCENE_PIXELS:
            ratio = math.sqrt(GPU_MAX_SCENE_PIXELS / (width * height))
            width, height = max(1, int(width * ratio)), max(1, int(height * ratio))
        return width, height

    def _resize(self, size):
        if size[0] * size[1] > GPU_MAX_OVERLAY_PIXELS:
            raise RuntimeError('GPU display surface exceeds safe allocation budget')
        self.size = tuple(size)
        self._overlay_tiles = set()
        self._overlay_full = True
        self.view_size = self._scene_size(self.size)
        self.last_rays = self.view_size[0]
        self.glViewport(0,0,*self.size)
        if hasattr(self,'overlay_id'):
            self.glBindTexture(self.GL_TEXTURE_2D,self.overlay_id)
            self.glTexImage2D(self.GL_TEXTURE_2D,0,self.GL_RGBA,*self.size,0,
                              self.GL_RGBA,self.GL_UNSIGNED_BYTE,None)
        if self.use_fbo:
            self.glBindTexture(self.GL_TEXTURE_2D,self.scene_id)
            self.glTexImage2D(self.GL_TEXTURE_2D,0,self.GL_RGBA,*self.view_size,0,
                              self.GL_RGBA,self.GL_UNSIGNED_BYTE,None)
            self.glBindFramebuffer(self.GL_FRAMEBUFFER,self.framebuffer)
            self.glFramebufferTexture2D(self.GL_FRAMEBUFFER,self.GL_COLOR_ATTACHMENT0,
                                        self.GL_TEXTURE_2D,self.scene_id,0)
            status = self.glCheckFramebufferStatus(self.GL_FRAMEBUFFER)
            self.glBindFramebuffer(self.GL_FRAMEBUFFER,0)
            if status != self.GL_FRAMEBUFFER_COMPLETE:
                self.use_fbo = False
                self.view_size = self.size
                self.last_rays = self.size[0]

    def _set_world(self, game):
        signature = (game.seed, game.world.generation, game.world.revision)
        if self.grid_seed == signature:
            return
        surface=pygame.Surface((game.world.width,game.world.height),pygame.SRCALPHA)
        for y,row in enumerate(game.world.grid):
            for x,walkable in enumerate(row):
                material = game.world.wall_style(x, y, self.wall_materials)
                surface.set_at((x,y),(255 if walkable else 0, material * 40, 0, 255))
        if self.grid_id:
            old = ctypes.c_uint(self.grid_id)
            self.glDeleteTextures(1, ctypes.byref(old))
            self.allocated_textures.discard(self.grid_id)
        self.grid_id = self._texture(surface,nearest=True)
        self.grid_seed = signature

    def _quad(self,x1,y1,x2,y2):
        self.glBegin(self.GL_QUADS)
        for x,y,u,v in ((x1,y1,0.,0.),(x2,y1,1.,0.),(x2,y2,1.,1.),(x1,y2,0.,1.)):
            self.glTexCoord2f(u,v)
            self.glVertex2f(x,y)
        self.glEnd()

    def _project(self,game,x,y,z,size,pulse=1.):
        dx,dy=x-game.x,y-game.y
        forward = dx*math.cos(game.angle)+dy*math.sin(game.angle)
        sideways = -dx*math.sin(game.angle)+dy*math.cos(game.angle)
        if forward<=.15 or forward>22.: return None
        w,h=self.view_size
        center_x=w*.5+sideways/(forward*TAN_HALF)*w*.5
        horizon=h*(.50+game.pitch)
        center_y=horizon+(.52-z)*h/forward
        height=h*size*pulse/forward
        return center_x,center_y,forward,height

    def _sprites(self, game, now):
        objects=[]
        for prop in game.world.decor:
            d=math.hypot(prop['x']-game.x,prop['y']-game.y)
            if d<10.:
                kind=prop['kind']
                objects.append((d,kind,prop['x'],prop['y'],.35 if kind=='chair' else .58,.58,1.,1.))
        for x,y in game.world.lights:
            d=math.hypot(x-game.x,y-game.y)
            if d<11.:objects.append((d,'light',x,y,.95,.32,1.,1.))
        for item in game.world.items:
            if item['active']:
                d=math.hypot(item['x']-game.x,item['y']-game.y)
                if d<16.:objects.append((d,item['kind'],item['x'],item['y'],.51 if item['kind'] in ('note','relay') else .33,.58 if item['kind'] in ('note','relay') else .39,1.,1.))
        if game.exit_ready:
            x,y=game.world.exit
            objects.append((math.hypot(x-game.x,y-game.y),'exit',x,y,.50,1.,1.,1.))
        if game.enemy_active:
            x,y=game.enemy_x,game.enemy_y
            pose = ('creature_stride' if int(now * (5. if game.enemy_state == 'CHASE' else 2.)) % 2 else 'creature') if game.enemy_state in ('CHASE', 'WANDER', 'SEARCH') else ('creature_lurk' if game.enemy_state == 'OBSERVE' else 'creature_still')
            objects.append((math.hypot(x-game.x,y-game.y),pose,x,y,.51,1.12,1.+.012*math.sin(now*2.5),1.))
        if game.shadow_active:
            x,y=game.shadow_x,game.shadow_y
            objects.append((math.hypot(x-game.x,y-game.y),'apparition',x,y,.53,1.11,1.,.50))
        if game.horror.false_door:
            x,y=game.horror.false_door
            objects.append((math.hypot(x-game.x,y-game.y),'false_door',x,y,.51,1.3,1.,.82))
        if game.horror.ghost:
            x,y=game.horror.ghost
            objects.append((math.hypot(x-game.x,y-game.y),'apparition',x,y,.53,1.3,1.,game.horror.ghost_alpha))
        objects.sort(reverse=True)
        self.glUseProgram(0)
        self.glActiveTexture(self.GL_TEXTURE0)
        self.glEnable(self.GL_TEXTURE_2D)
        self.glEnable(self.GL_BLEND)
        self.glBlendFunc(self.GL_SRC_ALPHA,self.GL_ONE_MINUS_SRC_ALPHA)
        w,h=self.view_size
        for distance,name,x,y,z,size,pulse,alpha in objects:
            if distance>1.5 and not game.world.visible(game.x,game.y,x,y):continue
            projection=self._project(game,x,y,z,size,pulse)
            if projection is None:continue
            sx,sy,depth,height=projection
            if name=='apparition':
                alpha=min(alpha,.65)
            tex,dimensions=self.sprites[name]
            width=height*dimensions[0]/dimensions[1]
            if sx+width*.5<0 or sx-width*.5>w:continue
            self.glBindTexture(self.GL_TEXTURE_2D,tex)
            shade=max(.29,1.-distance*.032-game.horror.blackout*.18)
            self.glColor4f(shade,shade,shade,alpha)
            x1=(sx-width*.5)/w*2.-1.
            x2=(sx+width*.5)/w*2.-1.
            y1=1.-(sy+height*.5)/h*2.
            y2=1.-(sy-height*.5)/h*2.
            self._quad(x1,y1,x2,y2)
        self.glColor4f(1.,1.,1.,1.)

    def draw(self, overlay, game, now, reduce_flash=False):
        self._set_world(game)
        desired = self._scene_size(self.size)
        if desired != self.view_size:
            self._resize(self.size)
        if self.use_fbo:
            self.glBindFramebuffer(self.GL_FRAMEBUFFER,self.framebuffer)
        self.glViewport(0,0,*self.view_size)
        self.glDisable(self.GL_DEPTH_TEST)
        self.glClearColor(.01,.02,.02,1.)
        self.glClear(self.GL_COLOR_BUFFER_BIT)
        self.glDisable(self.GL_BLEND)
        self.glUseProgram(self.program)
        self.glActiveTexture(self.GL_TEXTURE0)
        self.glBindTexture(self.GL_TEXTURE_2D,self.grid_id)
        self.glActiveTexture(self.GL_TEXTURE1)
        self.glBindTexture(self.GL_TEXTURE_2D,self.wall_id)
        u=self.uniforms
        self.glUniform1i(u['gridTex'],0)
        self.glUniform1i(u['wallTex'],1)
        self.glUniform2f(u['player'],game.x,game.y)
        self.glUniform2f(u['direction'],math.cos(game.angle),math.sin(game.angle))
        self.glUniform2f(u['resolution'],*self.view_size)
        light_limit = 3 if self.quality == 'ECO' else min(10, 3 + 2 * self.auto_level) if self.quality == 'AUTO' else 10
        visible_lights=sorted(game.world.lights,key=lambda p:(p[0]-game.x)**2+(p[1]-game.y)**2)[:light_limit]
        self.glUniform1i(u['lampCount'],len(visible_lights))
        lights=[number for pair in visible_lights for number in pair]
        if lights:
            buf=(ctypes.c_float*len(lights))(*lights)
            self.glUniform2fv(u['lamps'],len(visible_lights),ctypes.cast(buf,ctypes.c_void_p))
        source = min(game.projectiles, key=lambda p:(p['x']-game.x)**2+(p['y']-game.y)**2) if game.projectiles else None
        self.glUniform2f(u['flarePos'], source['x'] if source else game.x,
                         source['y'] if source else game.y)
        self.glUniform1f(u['flareIntensity'], 1. if source else 0.)
        self.glUniform1f(u['muzzlePower'], min(1., game.shot_flash * 6.))
        values={'pitch': game.pitch + .014*math.sin(game.walk_phase)*game.move_amount +
                         .014*game.jump_height - (.025 if game.crouching else 0.),
                'elapsed':now,'seed':float(game.seed%5),'seed13':float(game.seed%13),'aim':float(game.aiming),
                'lightFault':max(game.horror.flicker, game.horror.blackout * 2.5),'anomaly':game.anomaly + game.horror.blackout * .8,
                'blackout':game.horror.blackout, 'warp':game.horror.warp,
                'reduced':float(reduce_flash),'tanHalf':TAN_HALF,
                'viewSteps':float(34 if self.quality=='ECO' else min(RAY_STEP_LIMIT, 34 + 10 * self.auto_level) if self.quality=='AUTO' else RAY_STEP_LIMIT),
                'worldSize':float(game.world.width),'regionSize':float(WORLD_REGION_SIZE),
                'wallMaterials':float(self.wall_materials),
                'tension':float(game.horror.tension),'sanity':float(game.sanity/100.)}
        for name,value in values.items():
            self.glUniform1f(u[name],value)
        self.glColor4f(1.,1.,1.,1.)
        self._quad(-1.,-1.,1.,1.)
        self._sprites(game,now)
        if self.use_fbo:
            self.glBindFramebuffer(self.GL_FRAMEBUFFER,0)
            self.glViewport(0,0,*self.size)
            self.glUseProgram(0)
            self.glActiveTexture(self.GL_TEXTURE0)
            self.glEnable(self.GL_TEXTURE_2D)
            self.glDisable(self.GL_BLEND)
            self.glBindTexture(self.GL_TEXTURE_2D,self.scene_id)
            self.glColor4f(1.,1.,1.,1.)
            self._quad(-1.,-1.,1.,1.)
        overlay.fill((0,0,0,0))

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.allocated_textures:
            textures = (ctypes.c_uint * len(self.allocated_textures))(*self.allocated_textures)
            self.glDeleteTextures(len(textures), textures)
            self.allocated_textures.clear()
        if self.framebuffer and self.glDeleteFramebuffers:
            frame = ctypes.c_uint(self.framebuffer)
            self.glDeleteFramebuffers(1, ctypes.byref(frame))
            self.framebuffer = None
        if self.program:
            self.glDeleteProgram(self.program)
            self.program = None

    def present(self, overlay):
        if overlay.get_size() != self.size:
            raise RuntimeError('GPU overlay size changed without display reset')
        self.glUseProgram(0)
        self.glActiveTexture(self.GL_TEXTURE0)
        self.glEnable(self.GL_TEXTURE_2D)
        self.glEnable(self.GL_BLEND)
        self.glBlendFunc(self.GL_SRC_ALPHA, self.GL_ONE_MINUS_SRC_ALPHA)
        self.glBindTexture(self.GL_TEXTURE_2D, self.overlay_id)
        self.glPixelStorei(0x0CF5, 1)
        width, height = self.size
        tile = GPU_UI_TILE_SIZE
        current = set()
        for y in range(0, height, tile):
            for x in range(0, width, tile):
                rect = pygame.Rect(x, y, min(tile, width - x), min(tile, height - y))
                if overlay.subsurface(rect).get_bounding_rect(min_alpha=1).width:
                    current.add((x, y))
        tiles_total = ((width + tile - 1) // tile) * ((height + tile - 1) // tile)
        full = self._overlay_full or len(current) >= tiles_total * GPU_UI_FULL_UPLOAD_RATIO
        self.ui_upload_bytes = 0
        if full:
            pixels = pygame.image.tobytes(overlay, 'RGBA', True)
            pointer = ctypes.cast(ctypes.c_char_p(pixels), ctypes.c_void_p)
            self.glTexSubImage2D(self.GL_TEXTURE_2D, 0, 0, 0, width, height,
                                 self.GL_RGBA, self.GL_UNSIGNED_BYTE, pointer)
            self.ui_upload_bytes = len(pixels)
        else:
            for x, y in current | self._overlay_tiles:
                rect = pygame.Rect(x, y, min(tile, width - x), min(tile, height - y))
                pixels = pygame.image.tobytes(overlay.subsurface(rect), 'RGBA', True)
                pointer = ctypes.cast(ctypes.c_char_p(pixels), ctypes.c_void_p)
                self.glTexSubImage2D(self.GL_TEXTURE_2D, 0, x, height - y - rect.height,
                                     rect.width, rect.height, self.GL_RGBA, self.GL_UNSIGNED_BYTE, pointer)
                self.ui_upload_bytes += len(pixels)
        self._overlay_full = len(current) >= tiles_total * GPU_UI_FULL_UPLOAD_RATIO
        self._overlay_tiles = current
        if current:
            self.glColor4f(1., 1., 1., 1.)
            self._quad(-1., -1., 1., 1.)
        pygame.display.flip()
